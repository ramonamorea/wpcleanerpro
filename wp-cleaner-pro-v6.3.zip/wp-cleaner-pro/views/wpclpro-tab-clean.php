<?php
/**
 * Holds the data displayed on the Clean tab.
 *
 * @package    wp-cleaner-pro
 * @author     hevada <support@hevada.com>
 * @copyright  2017-2030 hevada <support@hevada.com>
 * @link       http://codecanyon.net/user/hevada
 * @version    6.3
 * @since      1.0
 */

$controller = new Wpclpro_Controller();
$db_items   = get_option( 'wpclpro_clean_items', array() );
?>

<form action="" method="post" name="wpclpro-form" id="wpclpro-form">
<?php wp_nonce_field( Wpclpro_Loader::ACTION, Wpclpro_Loader::NONCE, true, true ); ?>

	<div class="wpclpro-message wpclpro-gray">
		<span class="dashicons dashicons-warning"></span>
			<?php esc_html_e( 'Current database size: ', 'wpclpro' ); ?>
			<span class="wpclpro-highlight">
			<?php echo esc_html( Wpclpro_Utilities::wpclpro_format_filesize( $controller->wpclpro_get_db_size() ) ); ?>
			</span>

			<?php
			$url = wp_nonce_url(
				admin_url( 'tools.php?page=wpclpro&tabindex=3' ),
				Wpclpro_Loader::ACTION,
				Wpclpro_Loader::NONCE
			);
			printf(
				wp_kses(
					/* translators: %s: a link to the backup tab */
					__(
						'Before cleaning, please backup your data using <a href="%s" class="button" title="backup">database backup</a>',
						'wpclpro'
					),
					array( 'a' => array( 'href' => array() ) )
				),
				esc_url( $url )
			);
			?>
	</div>

	<?php
	if ( wp_next_scheduled( Wpclpro_Loader::SCHEDULED_HOOK_NAME ) ) {
		$class = '';
	} else {
		$class = 'wpclpro-hidden';
	}
	?>
	<div class="wpclpro-message wpclpro-gray <?php echo esc_attr( $class ); ?>" id="wpclpro-scheduled">
		<span class="dashicons dashicons-clock"></span>
			<?php
				printf(
					/* translators: %s: date when the cleaning is scheduled */
					esc_html__(
						'A bulk cleaning of multiple items was scheduled: %s. ',
						'wpclpro'
					),
					esc_html( wp_get_schedule( Wpclpro_Loader::SCHEDULED_HOOK_NAME ) )
				);
				esc_html_e( 'Next run: ', 'wpclpro' );
				echo esc_html( $controller->wpclpro_get_date_scheduled() );
				?>
			<a href="javascript: wpclpro_unschedule();" class="wpclpro-gray">
				<?php esc_html_e( 'Unschedule it ?', 'wpclpro' ); ?>
			</a>
	</div>

	<input type="hidden" name="wpclpro-action" id="wpclpro-action" value="-1">

	<div class="wpclpro-spacer"></div>
	<div class="alignleft actions">
		<label for='action-top' class='screen-reader-text'>
			<?php esc_html_e( 'Select bulk actions', 'wpclpro' ); ?>
		</label>
		<select name="action-top" id="action-top" onchange="wpclpro_bulk_actions(this.value)">
			<option value="-1" selected="selected">
				<?php esc_html_e( 'Bulk actions', 'wpclpro' ); ?></option>
			<option value="<?php echo esc_attr( Wpclpro_Loader::ACTION_CLEAN ); ?>">
				<?php esc_html_e( 'Instant clean', 'wpclpro' ); ?></option>
			<option value="<?php echo esc_attr( Wpclpro_Loader::ACTION_SCHEDULE ); ?>">
				<?php esc_html_e( 'Scheduled clean', 'wpclpro' ); ?></option>
		</select>
		<label for="wpclpro-frequency-top" class="screen-reader-text">
			<?php esc_html_e( 'Schedule', 'wpclpro' ); ?>
		</label>
		<select name="wpclpro-frequency-top" id="wpclpro-frequency-top" onchange="wpclpro_synchronize_frequency(this.value)">
			<option value="monthly"><?php esc_html_e( 'Monthly', 'wpclpro' ); ?></option>
			<option value="weekly"><?php esc_html_e( 'Weekly', 'wpclpro' ); ?></option>
			<option value="daily"><?php esc_html_e( 'Daily', 'wpclpro' ); ?></option>
			<option value="twicedaily"><?php esc_html_e( 'Twice daily', 'wpclpro' ); ?></option>
			<option value="hourly"><?php esc_html_e( 'Hourly', 'wpclpro' ); ?></option>
		</select>
		<input
			type="button" class="button button-primary"
			value="<?php esc_attr_e( 'Apply', 'wpclpro' ); ?>"
			onclick="javascript: wpclpro_action(jQuery('#wpclpro-action').val());">
	</div>
	<div class="alignleft actions">
		<label for="filter-items-top" class="screen-reader-text">
			<?php esc_html_e( 'Filter', 'wpclpro' ); ?>
		</label>
		<select name="filter-items-top" id="filter-items-top" onchange="wpclpro_synchronize_filters(this.value)">
			<option value=""><?php esc_html_e( 'All categories', 'wpclpro' ); ?></option>
			<option value="<?php esc_attr_e( 'Comments', 'wpclpro' ); ?>"><?php esc_html_e( 'Comments', 'wpclpro' ); ?></option>
			<option value="<?php esc_attr_e( 'Posts / Pages', 'wpclpro' ); ?>"><?php esc_html_e( 'Posts / Pages', 'wpclpro' ); ?></option>
			<option value="<?php esc_attr_e( 'Terms', 'wpclpro' ); ?>"><?php esc_html_e( 'Terms', 'wpclpro' ); ?></option>
			<option value="<?php esc_attr_e( 'Options', 'wpclpro' ); ?>"><?php esc_html_e( 'Options', 'wpclpro' ); ?></option>
			<option value="<?php esc_attr_e( 'Users', 'wpclpro' ); ?>"><?php esc_html_e( 'Users', 'wpclpro' ); ?></option>
			<option value="<?php esc_attr_e( 'Tables', 'wpclpro' ); ?>"><?php esc_html_e( 'Tables', 'wpclpro' ); ?></option>
		</select>
		<input
			type="button" class="button button-primary"
			id="filter-items-button-top"
			value="<?php esc_attr_e( 'Filter', 'wpclpro' ); ?>"
			onclick="javascript: wpclpro_filter_items();"/>
	</div>
<div>
<br class="clear"><br>
<table class="widefat wpclpro-table wpclpro-clean-table order-column hover cell-border" id="wpclpro-table">
	<thead>
		<!-- Table header-->
		<tr>
			<th>
				<input type="checkbox" name="items[]" value="" onClick="wpclpro_toggleAll(this)"/>
			</th>
			<th>
				<?php esc_html_e( 'Cleanable items', 'wpclpro' ); ?>
			</th>
			<th>
				<?php esc_html_e( 'Count ', 'wpclpro' ); ?>
			</th>
			<th>
				<?php esc_html_e( 'View', 'wpclpro' ); ?>
			</th>
			<th>
				<?php esc_html_e( 'Clean', 'wpclpro' ); ?>
			</th>
			<th>
				<?php esc_html_e( 'Status', 'wpclpro' ); ?>
			</th>
			<th>
				<?php esc_html_e( 'Description', 'wpclpro' ); ?>
			</th>
			<th>
				<?php esc_html_e( 'Category', 'wpclpro' ); ?>
			</th>
		</tr>
	</thead>
	<tbody>
		<!-- 1. Trash comments -->
		<tr class="wpclpro-comments">
			<?php $item = Wpclpro_Loader::TRASH_COMMENTS; ?>
			<td>
				<input type="checkbox" name="items[]" value="<?php echo esc_attr( $item ); ?>" onClick="wpclpro_toggle(this)" />
			</td>
			<td>
				<?php esc_html_e( 'Trash comments', 'wpclpro' ); ?>
			</td>
			<td id="wpclpro-count-value-<?php echo esc_attr( $item ); ?>" class="wpclpro-strong wpclpro-lightgray">
				0
			</td>
			<td>
				<?php $controller->wpclpro_show_details_icon( __( 'trash comments', 'wpclpro' ), $item ); ?>
			</td>
			<td>
				<?php $controller->wpclpro_show_clean_icon( __( 'trash comments', 'wpclpro' ), $item ); ?>
			</td>
			<td id="scheduled-<?php echo esc_attr( $item ); ?>">
				<?php $controller->wpclpro_get_scheduled_label( $item, $db_items, true ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Comments in the trash bin (which are marked for deletion).', 'wpclpro' ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Comments', 'wpclpro' ); ?>
			</td>
		</tr>
		<!-- 2. Spam comments -->
		<tr class="wpclpro-comments">
			<?php $item = Wpclpro_Loader::SPAM_COMMENTS; ?>
			<td>
				<input type="checkbox" name="items[]" value="<?php echo esc_attr( $item ); ?>" onClick="wpclpro_toggle(this)" />
			</td>
			<td>
				<?php esc_html_e( 'Spam comments', 'wpclpro' ); ?>
			</td>
			<td id="wpclpro-count-value-<?php echo esc_attr( $item ); ?>" class="wpclpro-strong wpclpro-lightgray">
				0
			</td>
			<td>
				<?php $controller->wpclpro_show_details_icon( __( 'spam comments', 'wpclpro' ), $item ); ?>
			</td>
			<td>
				<?php $controller->wpclpro_show_clean_icon( __( 'spam comments', 'wpclpro' ), $item ); ?>
			</td>
			<td id="scheduled-<?php echo esc_attr( $item ); ?>">
				<?php $controller->wpclpro_get_scheduled_label( $item, $db_items, true ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Unsolicited commercial comments posted by visitors.', 'wpclpro' ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Comments', 'wpclpro' ); ?>
			</td>
		</tr>
		<!-- 3. Waing for moderation comments -->
		<tr class="wpclpro-comments">
			<?php $item = Wpclpro_Loader::WMODERATION; ?>
			<td>
				<input type="checkbox" name="items[]" value="<?php echo esc_attr( $item ); ?>" onClick="wpclpro_toggle(this)" />
			</td>
			<td>
				<?php esc_html_e( 'Waiting moderation comments', 'wpclpro' ); ?>
			</td>
			<td id="wpclpro-count-value-<?php echo esc_attr( $item ); ?>" class="wpclpro-strong wpclpro-lightgray">
				0
			</td>
			<td>
				<?php $controller->wpclpro_show_details_icon( __( 'waiting for moderation comments', 'wpclpro' ), $item ); ?>
			</td>
			<td>
				<?php $controller->wpclpro_show_clean_icon( __( 'waiting for moderation comments', 'wpclpro' ), $item ); ?>
			</td>
			<td id="scheduled-<?php echo esc_attr( $item ); ?>">
				<?php $controller->wpclpro_get_scheduled_label( $item, $db_items, true ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Comments waiting the admin\'s approval before being published.', 'wpclpro' ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Comments', 'wpclpro' ); ?>
			</td>
		</tr>
		<!-- 4. Duplicated comment meta -->
		<tr class="wpclpro-comments">
			<?php $item = Wpclpro_Loader::DUPLICATED_COMMENT_META; ?>
			<td>
				<input type="checkbox" name="items[]" value="<?php echo esc_attr( $item ); ?>" onClick="wpclpro_toggle(this)" />
			</td>
			<td>
				<?php esc_html_e( 'Duplicated comment meta', 'wpclpro' ); ?>
			</td>
			<td id="wpclpro-count-value-<?php echo esc_attr( $item ); ?>" class="wpclpro-strong wpclpro-lightgray">
				0
			</td>
			<td>
				<?php $controller->wpclpro_show_details_icon( __( 'duplicated comment meta', 'wpclpro' ), $item ); ?>
			</td>
			<td>
				<?php $controller->wpclpro_show_clean_icon( __( 'duplicated comment meta', 'wpclpro' ), $item ); ?>
			</td>
			<td id="scheduled-<?php echo esc_attr( $item ); ?>">
				<?php $controller->wpclpro_get_scheduled_label( $item, $db_items, true ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Duplicated data in a comment.', 'wpclpro' ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Comments', 'wpclpro' ); ?>
			</td>
		</tr>
		<!-- 5. Pingbacks -->
		<tr class="wpclpro-comments">
			<?php $item = Wpclpro_Loader::PINGBACKS; ?>
			<td>
				<input type="checkbox" name="items[]" value="<?php echo esc_attr( $item ); ?>" onClick="wpclpro_toggle(this)" />
			</td>
			<td>
				<?php esc_html_e( 'Pingbacks', 'wpclpro' ); ?>
			</td>
			<td id="wpclpro-count-value-<?php echo esc_attr( $item ); ?>" class="wpclpro-strong wpclpro-lightgray">
				0
			</td>
			<td>
				<?php $controller->wpclpro_show_details_icon( __( 'pingbacks', 'wpclpro' ), $item ); ?>
			</td>
			<td>
				<?php $controller->wpclpro_show_clean_icon( __( 'pingbacks', 'wpclpro' ), $item ); ?>
			</td>
			<td id="scheduled-<?php echo esc_attr( $item ); ?>">
				<?php $controller->wpclpro_get_scheduled_label( $item, $db_items, true ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Special comments that are created when you link to another blog post.', 'wpclpro' ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Comments', 'wpclpro' ); ?>
			</td>
		</tr>
		<!-- 6. Trackbacks -->
		<tr class="wpclpro-comments">
			<?php $item = Wpclpro_Loader::TRACKBACKS; ?>
			<td>
				<input type="checkbox" name="items[]" value="<?php echo esc_attr( $item ); ?>" onClick="wpclpro_toggle(this)" />
			</td>
			<td>
				<?php esc_html_e( 'Trackbacks', 'wpclpro' ); ?>
			</td>
			<td id="wpclpro-count-value-<?php echo esc_attr( $item ); ?>" class="wpclpro-strong wpclpro-lightgray">
				0
			</td>
			<td>
				<?php $controller->wpclpro_show_details_icon( __( 'trackbacks', 'wpclpro' ), $item ); ?>
			</td>
			<td>
				<?php $controller->wpclpro_show_clean_icon( __( 'trackbacks', 'wpclpro' ), $item ); ?>
			</td>
			<td id="scheduled-<?php echo esc_attr( $item ); ?>">
				<?php $controller->wpclpro_get_scheduled_label( $item, $db_items, true ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Special comments notifying that another website links to your website.', 'wpclpro' ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Comments', 'wpclpro' ); ?>
			</td>
		</tr>
		<!-- 7. Weird characters in comments -->
		<tr class="wpclpro-comments">
			<?php $item = Wpclpro_Loader::COMMENT_WEIRD_CHARS; ?>
			<td>
				<input type="checkbox" name="items[]" value="<?php echo esc_attr( $item ); ?>" onClick="wpclpro_toggle(this)" />
			</td>
			<td>
				<?php esc_html_e( 'Weird characters in comments', 'wpclpro' ); ?>
			</td>
			<td id="wpclpro-count-value-<?php echo esc_attr( $item ); ?>" class="wpclpro-strong wpclpro-lightgray">
				0
			</td>
			<td>
				<?php $controller->wpclpro_show_details_icon( __( 'weird characters in comments', 'wpclpro' ), $item ); ?>
			</td>
			<td>
				<?php $controller->wpclpro_show_clean_icon( __( 'weird characters in comments', 'wpclpro' ), $item ); ?>
			</td>
			<td id="scheduled-<?php echo esc_attr( $item ); ?>">
				<?php $controller->wpclpro_get_scheduled_label( $item, $db_items, true ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Weird characters appeared in comments after a website migration.', 'wpclpro' ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Comments', 'wpclpro' ); ?>
			</td>
		</tr>
		<!-- 8. Comment agent from comments -->
		<tr class="wpclpro-comments">
			<?php $item = Wpclpro_Loader::COMMENT_AGENT; ?>
			<td>
				<input type="checkbox" name="items[]" value="<?php echo esc_attr( $item ); ?>" onClick="wpclpro_toggle(this)" />
			</td>
			<td>
				<?php esc_html_e( 'Comment agent information', 'wpclpro' ); ?>
			</td>
			<td id="wpclpro-count-value-<?php echo esc_attr( $item ); ?>" class="wpclpro-strong wpclpro-lightgray">
				0
			</td>
			<td>
				<?php $controller->wpclpro_show_details_icon( __( 'comment agent information', 'wpclpro' ), $item ); ?>
			</td>
			<td>
				<?php $controller->wpclpro_show_clean_icon( __( 'comment agent information', 'wpclpro' ), $item ); ?>
			</td>
			<td id="scheduled-<?php echo esc_attr( $item ); ?>">
				<?php $controller->wpclpro_get_scheduled_label( $item, $db_items, true ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Info about the browser and operating system of the commenting user.', 'wpclpro' ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Comments', 'wpclpro' ); ?>
			</td>
		</tr>
		<!-- 9. Comments orphan meta data -->
		<tr class="wpclpro-comments">
			<?php $item = Wpclpro_Loader::ORPHAN_COMMENT_META; ?>
			<td>
				<input type="checkbox" name="items[]" value="<?php echo esc_attr( $item ); ?>" onClick="wpclpro_toggle(this)" />
			</td>
			<td>
				<?php esc_html_e( 'Orphan comment meta', 'wpclpro' ); ?>
			</td>
			<td id="wpclpro-count-value-<?php echo esc_attr( $item ); ?>" class="wpclpro-strong wpclpro-lightgray">
				0
			</td>
			<td>
				<?php $controller->wpclpro_show_details_icon( __( 'orphan comment meta', 'wpclpro' ), $item ); ?>
			</td>
			<td>
				<?php $controller->wpclpro_show_clean_icon( __( 'orphan comment meta', 'wpclpro' ), $item ); ?>
			</td>
			<td id="scheduled-<?php echo esc_attr( $item ); ?>">
				<?php $controller->wpclpro_get_scheduled_label( $item, $db_items, true ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Data belonging to a comment which no longer exists.', 'wpclpro' ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Comments', 'wpclpro' ); ?>
			</td>
		</tr>
		<!-- 10. Drafts -->
		<tr class="wpclpro-posts">
			<?php $item = Wpclpro_Loader::DRAFTS; ?>
			<td>
				<input type="checkbox" name="items[]" value="<?php echo esc_attr( $item ); ?>" onClick="wpclpro_toggle(this)" />
			</td>
			<td>
				<?php esc_html_e( 'Drafts', 'wpclpro' ); ?>
			</td>
			<td id="wpclpro-count-value-<?php echo esc_attr( $item ); ?>" class="wpclpro-strong wpclpro-lightgray">
				0
			</td>
			<td>
				<?php $controller->wpclpro_show_details_icon( __( 'drafts', 'wpclpro' ), $item ); ?>
			</td>
			<td>
				<?php $controller->wpclpro_show_clean_icon( __( 'drafts', 'wpclpro' ), $item ); ?>
			</td>
			<td id="scheduled-<?php echo esc_attr( $item ); ?>">
				<?php $controller->wpclpro_get_scheduled_label( $item, $db_items, true ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Posts or pages which are saved, but yet unpublished.', 'wpclpro' ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Posts/Pages', 'wpclpro' ); ?>
			</td>
		</tr>
		<!-- 11. Auto-drafts -->
		<tr class="wpclpro-posts">
			<?php $item = Wpclpro_Loader::AUTODRAFTS; ?>
			<td>
				<input type="checkbox" name="items[]" value="<?php echo esc_attr( $item ); ?>" onClick="wpclpro_toggle(this)" />
			</td>
			<td>
				<?php esc_html_e( 'Auto-drafts', 'wpclpro' ); ?>
			</td>
			<td id="wpclpro-count-value-<?php echo esc_attr( $item ); ?>" class="wpclpro-strong wpclpro-lightgray">
				0
			</td>
			<td>
				<?php $controller->wpclpro_show_details_icon( __( 'auto-drafts', 'wpclpro' ), $item ); ?>
			</td>
			<td>
				<?php $controller->wpclpro_show_clean_icon( __( 'auto-drafts', 'wpclpro' ), $item ); ?>
			</td>
			<td id="scheduled-<?php echo esc_attr( $item ); ?>">
				<?php $controller->wpclpro_get_scheduled_label( $item, $db_items, true ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Posts or pages which are auto-saved by WordPress, but yet unpublished.', 'wpclpro' ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Posts/Pages', 'wpclpro' ); ?>
			</td>
		</tr>
		<!-- 12. Revisions -->
		<tr class="wpclpro-posts">
			<?php $item = Wpclpro_Loader::REVISIONS; ?>
			<td>
				<input type="checkbox" name="items[]" value="<?php echo esc_attr( $item ); ?>" onClick="wpclpro_toggle(this)" />
			</td>
			<td>
				<?php esc_html_e( 'Revisions', 'wpclpro' ); ?>
			</td>
			<td id="wpclpro-count-value-<?php echo esc_attr( $item ); ?>" class="wpclpro-strong wpclpro-lightgray">
				0
			</td>
			<td>
				<?php $controller->wpclpro_show_details_icon( __( 'revisions', 'wpclpro' ), $item ); ?>
			</td>
			<td>
				<?php $controller->wpclpro_show_clean_icon( __( 'revisions', 'wpclpro' ), $item ); ?>
			</td>
			<td id="scheduled-<?php echo esc_attr( $item ); ?>">
				<?php $controller->wpclpro_get_scheduled_label( $item, $db_items, true ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Backups of your post or page, created when you click Save Draft / Update.', 'wpclpro' ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Posts/Pages', 'wpclpro' ); ?>
			</td>
		</tr>
		<!-- 13. Trash posts -->
		<tr class="wpclpro-posts">
			<?php $item = Wpclpro_Loader::TRASH_POSTS; ?>
			<td>
				<input type="checkbox" name="items[]" value="<?php echo esc_attr( $item ); ?>" onClick="wpclpro_toggle(this)" />
			</td>
			<td>
				<?php esc_html_e( 'Trash posts', 'wpclpro' ); ?>
			</td>
			<td id="wpclpro-count-value-<?php echo esc_attr( $item ); ?>" class="wpclpro-strong wpclpro-lightgray">
				0
			</td>
			<td>
				<?php $controller->wpclpro_show_details_icon( __( 'trash posts', 'wpclpro' ), $item ); ?>
			</td>
			<td>
				<?php $controller->wpclpro_show_clean_icon( __( 'trash posts', 'wpclpro' ), $item ); ?>
			</td>
			<td id="scheduled-<?php echo esc_attr( $item ); ?>">
				<?php $controller->wpclpro_get_scheduled_label( $item, $db_items, true ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Posts in the trash bin (which are marked for deletion).', 'wpclpro' ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Posts/Pages', 'wpclpro' ); ?>
			</td>
		</tr>
		<!-- 14. Duplicated post meta -->
		<tr class="wpclpro-posts">
			<?php $item = Wpclpro_Loader::DUPLICATED_POST_META; ?>
			<td>
				<input type="checkbox" name="items[]" value="<?php echo esc_attr( $item ); ?>" onClick="wpclpro_toggle(this)" />
			</td>
			<td>
				<?php esc_html_e( 'Duplicated post meta', 'wpclpro' ); ?>
			</td>
			<td id="wpclpro-count-value-<?php echo esc_attr( $item ); ?>" class="wpclpro-strong wpclpro-lightgray">
				0
			</td>
			<td>
				<?php $controller->wpclpro_show_details_icon( __( 'duplicated post meta', 'wpclpro' ), $item ); ?>
			</td>
			<td>
				<?php $controller->wpclpro_show_clean_icon( __( 'duplicated post meta', 'wpclpro' ), $item ); ?>
			</td>
			<td id="scheduled-<?php echo esc_attr( $item ); ?>">
				<?php $controller->wpclpro_get_scheduled_label( $item, $db_items, true ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Duplicated data which belongs to the same post.', 'wpclpro' ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Posts/Pages', 'wpclpro' ); ?>
			</td>
		</tr>
		<!-- 15. Weird characters in posts -->
		<tr class="wpclpro-posts">
			<?php $item = Wpclpro_Loader::POST_WEIRD_CHARS; ?>
			<td>
				<input type="checkbox" name="items[]" value="<?php echo esc_attr( $item ); ?>" onClick="wpclpro_toggle(this)" />
			</td>
			<td>
				<?php esc_html_e( 'Weird characters in posts', 'wpclpro' ); ?>
			</td>
			<td id="wpclpro-count-value-<?php echo esc_attr( $item ); ?>" class="wpclpro-strong wpclpro-lightgray">
				0
			</td>
			<td>
				<?php $controller->wpclpro_show_details_icon( __( 'weird characters in posts', 'wpclpro' ), $item ); ?>
			</td>
			<td>
				<?php $controller->wpclpro_show_clean_icon( __( 'weird characters in posts', 'wpclpro' ), $item ); ?>
			</td>
			<td id="scheduled-<?php echo esc_attr( $item ); ?>">
				<?php $controller->wpclpro_get_scheduled_label( $item, $db_items, true ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Weird characters appeared in posts after a website migration.', 'wpclpro' ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Posts/Pages', 'wpclpro' ); ?>
			</td>
		</tr>
		<!-- 16. oEmbed caches from post meta -->
		<tr class="wpclpro-posts">
			<?php $item = Wpclpro_Loader::OEMBED_CACHES; ?>
			<td>
				<input type="checkbox" name="items[]" value="<?php echo esc_attr( $item ); ?>" onClick="wpclpro_toggle(this)" />
			</td>
			<td>
				<?php esc_html_e( 'oEmbed caches in posts meta', 'wpclpro' ); ?>
			</td>
			<td id="wpclpro-count-value-<?php echo esc_attr( $item ); ?>" class="wpclpro-strong wpclpro-lightgray">
				0
			</td>
			<td>
				<?php $controller->wpclpro_show_details_icon( __( 'oEmbed caches in posts meta', 'wpclpro' ), $item ); ?>
			</td>
			<td>
				<?php $controller->wpclpro_show_clean_icon( __( 'oEmbed caches in posts meta', 'wpclpro' ), $item ); ?>
			</td>
			<td id="scheduled-<?php echo esc_attr( $item ); ?>">
				<?php $controller->wpclpro_get_scheduled_label( $item, $db_items, true ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Temporarly data about the embeddable content (Youtube, Vimeo).', 'wpclpro' ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Posts/Pages', 'wpclpro' ); ?>
			</td>
		</tr>
		<!-- 17. Posts orphan meta -->
		<tr class="wpclpro-posts">
			<?php $item = Wpclpro_Loader::ORPHAN_POST_META; ?>
			<td>
				<input type="checkbox" name="items[]" value="<?php echo esc_attr( $item ); ?>" onClick="wpclpro_toggle(this)" />
			</td>
			<td>
				<?php esc_html_e( 'Orphan post meta', 'wpclpro' ); ?>
			</td>
			<td id="wpclpro-count-value-<?php echo esc_attr( $item ); ?>" class="wpclpro-strong wpclpro-lightgray">
				0
			</td>
			<td>
				<?php $controller->wpclpro_show_details_icon( __( 'orphan post meta', 'wpclpro' ), $item ); ?>
			</td>
			<td>
				<?php $controller->wpclpro_show_clean_icon( __( 'orphan post meta', 'wpclpro' ), $item ); ?>
			</td>
			<td id="scheduled-<?php echo esc_attr( $item ); ?>">
				<?php $controller->wpclpro_get_scheduled_label( $item, $db_items, true ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Data belonging to posts which no longer exist.', 'wpclpro' ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Posts/Pages', 'wpclpro' ); ?>
			</td>
		</tr>
		<!-- 18. Old slugs -->
		<tr class="wpclpro-posts">
			<?php $item = Wpclpro_Loader::OLD_SLUGS; ?>
			<td>
				<input type="checkbox" name="items[]" value="<?php echo esc_attr( $item ); ?>" onClick="wpclpro_toggle(this)" />
			</td>
			<td>
				<?php esc_html_e( 'Old slugs', 'wpclpro' ); ?>
			</td>
			<td id="wpclpro-count-value-<?php echo esc_attr( $item ); ?>" class="wpclpro-strong wpclpro-lightgray">
				0
			</td>
			<td>
				<?php $controller->wpclpro_show_details_icon( __( 'old slugs', 'wpclpro' ), $item ); ?>
			</td>
			<td>
				<?php $controller->wpclpro_show_clean_icon( __( 'old slugs', 'wpclpro' ), $item ); ?>
			</td>
			<td id="scheduled-<?php echo esc_attr( $item ); ?>">
				<?php $controller->wpclpro_get_scheduled_label( $item, $db_items, true ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Old editable parts of pages URLs.', 'wpclpro' ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Posts/Pages', 'wpclpro' ); ?>
			</td>
		</tr>
		<!-- 19. Old dates -->
		<tr class="wpclpro-posts">
			<?php $item = Wpclpro_Loader::OLD_DATES; ?>
			<td>
				<input type="checkbox" name="items[]" value="<?php echo esc_attr( $item ); ?>" onClick="wpclpro_toggle(this)" />
			</td>
			<td>
				<?php esc_html_e( 'Old dates', 'wpclpro' ); ?>
			</td>
			<td id="wpclpro-count-value-<?php echo esc_attr( $item ); ?>" class="wpclpro-strong wpclpro-lightgray">
				0
			</td>
			<td>
				<?php $controller->wpclpro_show_details_icon( __( 'old dates', 'wpclpro' ), $item ); ?>
			</td>
			<td>
				<?php $controller->wpclpro_show_clean_icon( __( 'old dates', 'wpclpro' ), $item ); ?>
			</td>
			<td id="scheduled-<?php echo esc_attr( $item ); ?>">
				<?php $controller->wpclpro_get_scheduled_label( $item, $db_items, true ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Dates when posts/pages were originally written.', 'wpclpro' ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Posts/Pages', 'wpclpro' ); ?>
			</td>
		</tr>
		<!-- 20. Orphan shortcodes -->
		<tr class="wpclpro-posts">
			<?php $item = Wpclpro_Loader::ORPHAN_SHORTCODES; ?>
			<td>
				<input type="checkbox" name="items[]" value="<?php echo esc_attr( $item ); ?>" onClick="wpclpro_toggle(this)" />
			</td>
			<td>
				<?php esc_html_e( 'Orphan shortcodes', 'wpclpro' ); ?>
			</td>
			<td id="wpclpro-count-value-<?php echo esc_attr( $item ); ?>" class="wpclpro-strong wpclpro-lightgray">
				0
			</td>
			<td>
				<?php $controller->wpclpro_show_details_icon( __( 'orphan shortcodes', 'wpclpro' ), $item ); ?>
			</td>
			<td>
				<?php $controller->wpclpro_show_clean_icon( __( 'orphan shortcodes', 'wpclpro' ), $item ); ?>
			</td>
			<td id="scheduled-<?php echo esc_attr( $item ); ?>">
				<?php $controller->wpclpro_get_scheduled_label( $item, $db_items, true ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Orphan shortcodes, left in posts/pages by uninstalled plugins, themes.', 'wpclpro' ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Posts/Pages', 'wpclpro' ); ?>
			</td>
		</tr>
		<!-- 21. Unused terms-->
		<tr class="wpclpro-terms">
			<?php $item = Wpclpro_Loader::UNUSED_TERMS; ?>
			<td>
				<input type="checkbox" name="items[]" value="<?php echo esc_attr( $item ); ?>" onClick="wpclpro_toggle(this)" />
			</td>
			<td>
				<?php esc_html_e( 'Unused terms', 'wpclpro' ); ?>
			</td>
			<td id="wpclpro-count-value-<?php echo esc_attr( $item ); ?>" class="wpclpro-strong wpclpro-lightgray">
				0
			</td>
			<td>
				<?php $controller->wpclpro_show_details_icon( __( 'unused terms', 'wpclpro' ), $item ); ?>
			</td>
			<td>
				<?php $controller->wpclpro_show_clean_icon( __( 'unused terms', 'wpclpro' ), $item ); ?>
			</td>
			<td id="scheduled-<?php echo esc_attr( $item ); ?>">
				<?php $controller->wpclpro_get_scheduled_label( $item, $db_items, true ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Terms not used in a page, post or a custom post type.', 'wpclpro' ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Terms', 'wpclpro' ); ?>
			</td>
		</tr>
		<!-- 22. Duplicated term meta-->
		<tr class="wpclpro-terms">
			<?php $item = Wpclpro_Loader::DUPLICATED_TERM_META; ?>
			<td>
				<input type="checkbox" name="items[]" value="<?php echo esc_attr( $item ); ?>" onClick="wpclpro_toggle(this)" />
			</td>
			<td>
				<?php esc_html_e( 'Duplicated term meta', 'wpclpro' ); ?>
			</td>
			<td id="wpclpro-count-value-<?php echo esc_attr( $item ); ?>" class="wpclpro-strong wpclpro-lightgray">
				0
			</td>
			<td>
				<?php $controller->wpclpro_show_details_icon( __( 'duplicated term meta', 'wpclpro' ), $item ); ?>
			</td>
			<td>
				<?php $controller->wpclpro_show_clean_icon( __( 'duplicated term meta', 'wpclpro' ), $item ); ?>
			</td>
			<td id="scheduled-<?php echo esc_attr( $item ); ?>">
				<?php $controller->wpclpro_get_scheduled_label( $item, $db_items, true ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Duplicated data which belongs to the same term.', 'wpclpro' ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Terms', 'wpclpro' ); ?>
			</td>
		</tr>
		<!-- 23. Orphan term relationships -->
		<tr class="wpclpro-terms">
			<?php $item = Wpclpro_Loader::ORPHAN_TERM_RELATIONSHIPS; ?>
			<td>
				<input type="checkbox" name="items[]" value="<?php echo esc_attr( $item ); ?>" onClick="wpclpro_toggle(this)" />
			</td>
			<td>
				<?php esc_html_e( 'Orphan term relationships', 'wpclpro' ); ?>
			</td>
			<td id="wpclpro-count-value-<?php echo esc_attr( $item ); ?>" class="wpclpro-strong wpclpro-lightgray">
				0
			</td>
			<td>
				<?php $controller->wpclpro_show_details_icon( __( 'orphan term relationships', 'wpclpro' ), $item ); ?>
			</td>
			<td>
				<?php $controller->wpclpro_show_clean_icon( __( 'orphan term relationships', 'wpclpro' ), $item ); ?>
			</td>
			<td id="scheduled-<?php echo esc_attr( $item ); ?>">
				<?php $controller->wpclpro_get_scheduled_label( $item, $db_items, true ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Associations between a post and a category/tag that has been deleted.', 'wpclpro' ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Terms', 'wpclpro' ); ?>
			</td>
		</tr>
		<!-- 24. Expired transients -->
		<tr class="wpclpro-options">
			<?php $item = Wpclpro_Loader::EXPIRED_TRANSIENTS; ?>
			<td>
				<input type="checkbox" name="items[]" value="<?php echo esc_attr( $item ); ?>" onClick="wpclpro_toggle(this)" />
			</td>
			<td>
				<?php esc_html_e( 'Expired transients', 'wpclpro' ); ?>
			</td>
			<td id="wpclpro-count-value-<?php echo esc_attr( $item ); ?>" class="wpclpro-strong wpclpro-lightgray">
				0
			</td>
			<td>
				<?php $controller->wpclpro_show_details_icon( __( 'expired transients', 'wpclpro' ), $item ); ?>
			</td>
			<td>
				<?php $controller->wpclpro_show_clean_icon( __( 'expired transients', 'wpclpro' ), $item ); ?>
			</td>
			<td id="scheduled-<?php echo esc_attr( $item ); ?>">
				<?php $controller->wpclpro_get_scheduled_label( $item, $db_items, true ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Temporary, expired information stored by plugins and themes.', 'wpclpro' ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Options', 'wpclpro' ); ?>
			</td>
		</tr>
		<!-- 25. Orphan options -->
		<tr class="wpclpro-options">
			<?php $item = Wpclpro_Loader::ORPHAN_OPTIONS; ?>
			<td>
				<input type="checkbox" name="items[]" value="<?php echo esc_attr( $item ); ?>" onClick="wpclpro_toggle(this)" />
			</td>
			<td>
				<?php esc_html_e( 'Orphan options', 'wpclpro' ); ?>
			</td>
			<td id="wpclpro-count-value-<?php echo esc_attr( $item ); ?>" class="wpclpro-strong wpclpro-lightgray">
				0
			</td>
			<td>
				<?php $controller->wpclpro_show_details_icon( __( 'orphan options', 'wpclpro' ), $item ); ?>
			</td>
			<td>
				<?php $controller->wpclpro_show_clean_icon( __( 'orphan options', 'wpclpro' ), $item ); ?>
			</td>
			<td id="scheduled-<?php echo esc_attr( $item ); ?>">
				<?php $controller->wpclpro_get_scheduled_label( $item, $db_items, true ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Orphan options stored by plugins and themes.', 'wpclpro' ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Options', 'wpclpro' ); ?>
			</td>
		</tr>
		<!-- 26. Duplicated user meta -->
		<tr class="wpclpro-users">
			<?php $item = Wpclpro_Loader::DUPLICATED_USER_META; ?>
			<td>
				<input type="checkbox" name="items[]" value="<?php echo esc_attr( $item ); ?>" onClick="wpclpro_toggle(this)" />
			</td>
			<td>
				<?php esc_html_e( 'Duplicated user meta', 'wpclpro' ); ?>
			</td>
			<td id="wpclpro-count-value-<?php echo esc_attr( $item ); ?>" class="wpclpro-strong wpclpro-lightgray">
				0
			</td>
			<td>
				<?php $controller->wpclpro_show_details_icon( __( 'duplicated user meta', 'wpclpro' ), $item ); ?>
			</td>
			<td>
				<?php $controller->wpclpro_show_clean_icon( __( 'duplicated user meta', 'wpclpro' ), $item ); ?>
			</td>
			<td id="scheduled-<?php echo esc_attr( $item ); ?>">
				<?php $controller->wpclpro_get_scheduled_label( $item, $db_items, true ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Duplicated data which belongs to the same user.', 'wpclpro' ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Users', 'wpclpro' ); ?>
			</td>
		</tr>
		<!-- 27. Subscribers with invalid email -->
		<tr class="wpclpro-users">
			<?php $item = Wpclpro_Loader::SUBSCRIBERS_INVALID_EMAIL; ?>
			<td>
				<input type="checkbox" name="items[]" value="<?php echo esc_attr( $item ); ?>" onClick="wpclpro_toggle(this)" />
			</td>
			<td>
				<?php esc_html_e( 'Subscribers with invalid email', 'wpclpro' ); ?>
			</td>
			<td id="wpclpro-count-value-<?php echo esc_attr( $item ); ?>" class="wpclpro-strong wpclpro-lightgray">
				0
			</td>
			<td>
				<?php $controller->wpclpro_show_details_icon( __( 'subscribers with invalid email', 'wpclpro' ), $item ); ?>
			</td>
			<td>
				<?php $controller->wpclpro_show_clean_icon( __( 'subscribers with invalid email', 'wpclpro' ), $item ); ?>
			</td>
			<td id="scheduled-<?php echo esc_attr( $item ); ?>">
				<?php $controller->wpclpro_get_scheduled_label( $item, $db_items, true ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Subscribers with invalid email address (based on http://emailregex.com).', 'wpclpro' ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Users', 'wpclpro' ); ?>
			</td>
		</tr>
		<!-- 28. Orphan user meta -->
		<tr class="wpclpro-users">
			<?php $item = Wpclpro_Loader::ORPHAN_USER_META; ?>
			<td>
				<input type="checkbox" name="items[]" value="<?php echo esc_attr( $item ); ?>" onClick="wpclpro_toggle(this)" />
			</td>
			<td>
				<?php esc_html_e( 'Orphan user meta', 'wpclpro' ); ?>
			</td>
			<td id="wpclpro-count-value-<?php echo esc_attr( $item ); ?>" class="wpclpro-strong wpclpro-lightgray">
				0
			</td>
			<td>
				<?php $controller->wpclpro_show_details_icon( __( 'orphan user meta', 'wpclpro' ), $item ); ?>
			</td>
			<td>
				<?php $controller->wpclpro_show_clean_icon( __( 'orphan user meta', 'wpclpro' ), $item ); ?>
			</td>
			<td id="scheduled-<?php echo esc_attr( $item ); ?>">
				<?php $controller->wpclpro_get_scheduled_label( $item, $db_items, true ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Data which belongs to users who no longer exists.', 'wpclpro' ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Users', 'wpclpro' ); ?>
			</td>
		</tr>
		<!-- 29. All links in the wp_links table -->
		<tr class="wpclpro-tables">
			<?php $item = Wpclpro_Loader::WP_LINKS; ?>
			<td>
				<input type="checkbox" name="items[]" value="<?php echo esc_attr( $item ); ?>" onClick="wpclpro_toggle(this)" />
			</td>
			<td>
				<?php esc_html_e( 'Links in wp_links table', 'wpclpro' ); ?>
			</td>
			<td id="wpclpro-count-value-<?php echo esc_attr( $item ); ?>" class="wpclpro-strong wpclpro-lightgray">
				0
			</td>
			<td>
				<?php $controller->wpclpro_show_details_icon( __( 'links in wp_links table', 'wpclpro' ), $item ); ?>
			</td>
			<td>
				<?php $controller->wpclpro_show_clean_icon( __( 'links in wp_links table', 'wpclpro' ), $item ); ?>
			</td>
			<td id="scheduled-<?php echo esc_attr( $item ); ?>">
				<?php $controller->wpclpro_get_scheduled_label( $item, $db_items, true ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Links in table wp_links (an orphan table not used by WordPress anymore).', 'wpclpro' ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Tables', 'wpclpro' ); ?>
			</td>
		</tr>
		<!-- 30. Orphan empty tables -->
		<tr class="wpclpro-tables">
			<?php $item = Wpclpro_Loader::ORPHAN_TABLES; ?>
			<td>
				<input type="checkbox" name="items[]" value="<?php echo esc_attr( $item ); ?>" onClick="wpclpro_toggle(this)" />
			</td>
			<td>
				<?php esc_html_e( 'Orphan empty tables', 'wpclpro' ); ?>
			</td>
			<td id="wpclpro-count-value-<?php echo esc_attr( $item ); ?>" class="wpclpro-strong wpclpro-lightgray">
				0
			</td>
			<td>
				<?php $controller->wpclpro_show_details_icon( __( 'orphan tables', 'wpclpro' ), $item ); ?>
			</td>
			<td>
				<?php $controller->wpclpro_show_clean_icon( __( 'orphan tables', 'wpclpro' ), $item ); ?>
			</td>
			<td id="scheduled-<?php echo esc_attr( $item ); ?>">
				<?php $controller->wpclpro_get_scheduled_label( $item, $db_items, true ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Orphan empty tables, that do not belong anymore to a plugin or a theme.', 'wpclpro' ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Tables', 'wpclpro' ); ?>
			</td>
		</tr>
		<!-- 31. Plugin's old logs -->
		<tr class="wpclpro-tables">
			<?php $item = Wpclpro_Loader::PLUGIN_OLD_LOGS; ?>
			<td>
				<input type="checkbox" name="items[]" value="<?php echo esc_attr( $item ); ?>" onClick="wpclpro_toggle(this)" />
			</td>
			<td>
				<?php esc_html_e( 'Plugin old logs', 'wpclpro' ); ?>
			</td>
			<td id="wpclpro-count-value-<?php echo esc_attr( $item ); ?>" class="wpclpro-strong wpclpro-lightgray">
				0
			</td>
			<td>
				<?php $controller->wpclpro_show_details_icon( __( 'plugin old logs', 'wpclpro' ), $item ); ?>
			</td>
			<td>
				<?php $controller->wpclpro_show_clean_icon( __( 'plugin old logs', 'wpclpro' ), $item ); ?>
			</td>
			<td id="scheduled-<?php echo esc_attr( $item ); ?>">
				<?php $controller->wpclpro_get_scheduled_label( $item, $db_items, true ); ?>
			</td>
			<td>
				<?php esc_html_e( 'This plugin\'s old logs (older than a month).', 'wpclpro' ); ?>
			</td>
			<td>
				<?php esc_html_e( 'Tables', 'wpclpro' ); ?>
			</td>
		</tr>
	</tbody>
	<tfoot>
		<!-- Table footer-->
		<tr>
			<th>
				<input type="checkbox" name="items[]" value="" onClick="wpclpro_toggleAll(this)"/>
			</th>
			<th>
				<?php esc_html_e( 'Cleanable items', 'wpclpro' ); ?>
			</th>
			<th>
				<?php esc_html_e( 'Count', 'wpclpro' ); ?>
			</th>
			<th>
				<?php esc_html_e( 'View', 'wpclpro' ); ?>
			</th>
			<th>
				<?php esc_html_e( 'Clean', 'wpclpro' ); ?>
			</th>
			<th>
				<?php esc_html_e( 'Status', 'wpclpro' ); ?>
			</th>
			<th>
				<?php esc_html_e( 'Description', 'wpclpro' ); ?>
			</th>
			<th>
				<?php esc_html_e( 'Category', 'wpclpro' ); ?>
			</th>
		</tr>
	</tfoot>
</table>
</div>

<br class="clear">
<div class="alignleft actions">
	<label for='action-botom' class='screen-reader-text'>
		<?php esc_html_e( 'Select bulk action', 'wpclpro' ); ?>
	</label>
	<select name="action-bottom" id="action-bottom" onchange="wpclpro_bulk_actions(this.value)">
			<option value="-1" selected="selected">
				<?php esc_html_e( 'Bulk actions', 'wpclpro' ); ?></option>
			<option value="<?php echo esc_attr( Wpclpro_Loader::ACTION_CLEAN ); ?>">
				<?php esc_html_e( 'Instant clean', 'wpclpro' ); ?></option>
			<option value="<?php echo esc_attr( Wpclpro_Loader::ACTION_SCHEDULE ); ?>">
				<?php esc_html_e( 'Scheduled clean', 'wpclpro' ); ?></option>
		</select>
	<label for="wpclpro-frequency-bottom" class="screen-reader-text">
		<?php esc_html_e( 'Schedule', 'wpclpro' ); ?>
	</label>
	<select name="wpclpro-frequency-bottom" id="wpclpro-frequency-bottom" onchange="wpclpro_synchronize_frequency(this.value)">
		<option value="monthly"><?php esc_html_e( 'Monthly', 'wpclpro' ); ?></option>
		<option value="weekly"><?php esc_html_e( 'Weekly', 'wpclpro' ); ?></option>
		<option value="daily"><?php esc_html_e( 'Daily', 'wpclpro' ); ?></option>
		<option value="twicedaily"><?php esc_html_e( 'Twice daily', 'wpclpro' ); ?></option>
		<option value="hourly"><?php esc_html_e( 'Hourly', 'wpclpro' ); ?></option>
	</select>
	<input
		type="button" class="button button-primary"
		value="<?php esc_attr_e( 'Apply', 'wpclpro' ); ?>"
		onclick="javascript: wpclpro_action(jQuery('#wpclpro-action').val());">
</div>
<div class="alignleft actions">
	<label for="filter-items-bottom" class="screen-reader-text">
		<?php esc_html_e( 'Filter', 'wpclpro' ); ?>
	</label>
	<select name="filter-items-bottom" id="filter-items-bottom" onchange="wpclpro_synchronize_filters(this.value)">
		<option value="" selected="selected"><?php esc_html_e( 'All categories', 'wpclpro' ); ?></option>
		<option value="<?php esc_attr_e( 'Comments', 'wpclpro' ); ?>"><?php esc_html_e( 'Comments', 'wpclpro' ); ?></option>
		<option value="<?php esc_attr_e( 'Posts / Pages', 'wpclpro' ); ?>"><?php esc_html_e( 'Posts / Pages', 'wpclpro' ); ?></option>
		<option value="<?php esc_attr_e( 'Terms', 'wpclpro' ); ?>"><?php esc_html_e( 'Terms', 'wpclpro' ); ?></option>
		<option value="<?php esc_attr_e( 'Options', 'wpclpro' ); ?>"><?php esc_html_e( 'Options', 'wpclpro' ); ?></option>
		<option value="<?php esc_attr_e( 'Users', 'wpclpro' ); ?>"><?php esc_html_e( 'Users', 'wpclpro' ); ?></option>
		<option value="<?php esc_attr_e( 'Tables', 'wpclpro' ); ?>"><?php esc_html_e( 'Tables', 'wpclpro' ); ?></option>
	</select>
	<input
		type="button" class="button button-primary"
		id="filter-items-button-bottom"
		value="<?php esc_attr_e( 'Filter', 'wpclpro' ); ?>"
		onclick="javascript: wpclpro_filter_items();"/>
</div>

<br class="clear">
</form>
