<?php
/**
 * Holds the data displayed on the About tab.
 *
 * @package    wp-cleaner-pro
 * @author     hevada <support@hevada.com>
 * @copyright  2017-2030 hevada <support@hevada.com>
 * @link       http://codecanyon.net/user/hevada
 * @version    6.3
 * @since      1.0
 */

?>

<form action="" method="post" name="wpclpro-form" id="wpclpro-form">
<div class="wpclpro-message wpclpro-gray">
	<span class="dashicons dashicons-info"></span>
	<?php esc_html_e( 'WP Cleaner Pro, a plugin created by hevada', 'wpclpro' ); ?>
</div>
<div class="wpclpro-message wpclpro-gray">
	<span class="dashicons dashicons-info"></span>
	<?php esc_html_e( 'Version: 6.3 (last updated: 10 February 2024)', 'wpclpro' ); ?>
</div>
<div class="wpclpro-spacer"></div>
<div class="wpclpro-message wpclpro-gray wpclpro-about">
	<?php
		esc_html_e(
			'One of the most popular subjects in the WordPress community is speeding up WordPress and optimizing web pages. Databases are the central point of your website: they store all the valuable, important data that you show on your pages to your visitors.
			So, WordPress databases are a powerful way to keep your data, but if you use them wrong and you don\'t maintain them, they can get huge and bloated with useless data. And like any other software, WordPress needs maintenance, too.
			This is the role of this plugin: WP Cleaner Pro helps you to professionally clean the obsolete data in your database. It allows you to make an instant cleaning or a scheduled cleaning. After each cleaning operation (instant or scheduled) a database optimization is performed in the background too. Everything with a simple, intuitive interface and optimized for speed.',
			'wpclpro'
		);
		?>
</div>
<div class="wpclpro-spacer"></div>
<br class="clear">
</form>
