<?php
/**
 * Holds the data displayed on the Support tab.
 *
 * @package    wp-cleaner-pro
 * @author     hevada <support@hevada.com>
 * @copyright  2017-2030 hevada <support@hevada.com>
 * @link       http://codecanyon.net/user/hevada
 * @version    6.3
 * @since      1.0
 */

$controller = new Wpclpro_Controller();
?>

<form action="" method="post" name="wpclpro-form" id="wpclpro-form">
<div>
	<div class="wpclpro-message wpclpro-gray">
		<span class="dashicons dashicons-book-alt"></span>
		<?php esc_html_e( 'The complete documentation of the plugin: ', 'wpclpro' ); ?>
		<a
			href="<?php echo esc_url( plugin_dir_url( __DIR__ ) . 'documentation/' ); ?>"
			target="_blank"><?php esc_html_e( 'here', 'wpclpro' ); ?></a>
	</div>
	<div class="wpclpro-message wpclpro-gray">
		<span class="dashicons dashicons-businessman"></span>
		<?php esc_html_e( 'Developer page: ', 'wpclpro' ); ?>
		<a href="https://codecanyon.net/user/hevada" target="_blank"><?php esc_html_e( 'here', 'wpclpro' ); ?></a>
	</div>
	<div class="wpclpro-message wpclpro-gray">
		<span class="dashicons dashicons-info"></span>
		<?php esc_html_e( 'Technical information below:', 'wpclpro' ); ?>
	</div>
	<br class="clear"><br>

	<div class="wpclpro-wrap">
	<?php
			$information = PHP_EOL . PHP_EOL . __( 'Technical information: ', 'wpclpro' ) . PHP_EOL;

			$information .= __( 'Server', 'wpclpro' );
			$software     = isset( $_SERVER['SERVER_SOFTWARE'] ) ? sanitize_text_field( wp_unslash( $_SERVER['SERVER_SOFTWARE'] ) ) : '-';
			$information .= ': ' . $software . PHP_EOL;

			$information .= __( 'Operating system', 'wpclpro' );
			$information .= ': ' . PHP_OS . PHP_EOL;

			$information .= __( 'Server hostname', 'wpclpro' );
			$hostname     = isset( $_SERVER['SERVER_NAME'] ) ? sanitize_text_field( wp_unslash( $_SERVER['SERVER_NAME'] ) ) : '-';
			$information .= ': ' . $hostname . PHP_EOL;

			$information .= __( 'Server date / time', 'wpclpro' );
			$information .= ': ' . Wpclpro_Utilities::wpclpro_get_server_date_time() . PHP_EOL;

			$information .= __( 'PHP Memory limit', 'wpclpro' );
			$information .= ': ' . Wpclpro_Utilities::wpclpro_get_php_memory_limit() . PHP_EOL;

			$information .= __( 'PHP script execution timeout', 'wpclpro' );
			$information .= ': ' . Wpclpro_Utilities::wpclpro_get_max_execution_time() . PHP_EOL;

			$information .= __( 'WordPress version', 'wpclpro' );
			global $wp_version;
			$information .= ': ' . $wp_version . PHP_EOL;

			$information .= __( 'WordPress multisite', 'wpclpro' );
			$information .= ': ' . Wpclpro_Utilities::wpclpro_is_multisite() . PHP_EOL;

			$information .= __( 'MySQL', 'wpclpro' );
			$information .= ': ' . Wpclpro_Utilities::wpclpro_get_mysql_version() . PHP_EOL;

			$information .= __( 'Database total size (including logs)', 'wpclpro' );
			$information .= ': ' . Wpclpro_Utilities::wpclpro_format_filesize( $controller->wpclpro_get_db_size() ) . PHP_EOL;

			$information .= __( 'Number of tables', 'wpclpro' );
			$information .= ': ' . $controller->wpclpro_count( Wpclpro_Loader::TABLES ) . PHP_EOL;

			$information .= __( 'Maximum upload file size', 'wpclpro' );
			$information .= ': ' . Wpclpro_Utilities::wpclpro_get_max_upload_size() . PHP_EOL;

			$information .= __( 'Plugin version', 'wpclpro' );
			$information .= ': ' . Wpclpro_Utilities::wpclpro_get_plugin_version();
	?>
		<textarea id="wpclpro-information" rows="15" cols="100" class="wpclpro-textarea" readonly><?php echo esc_textarea( $information ); ?>
		</textarea>

	</div>
</div>
<br class="clear">
</form>
