<?php
/**
 * Holds the main form shown in admin plugin dashboard.
 *
 * @package    wp-cleaner-pro
 * @author     hevada <support@hevada.com>
 * @copyright  2017-2030 hevada <support@hevada.com>
 * @link       http://codecanyon.net/user/hevada
 * @version    6.3
 * @since      1.0
 */

header( 'Content-type: text/html; charset=utf-8' );
header( 'Access-Control-Allow-Origin: *' );
header( 'Access-Control-Allow-Methods: GET, POST' );

/**
 * Handles the logic in plugin's main admin form.
 *
 * @access public (restricted to admin having the 'manage_options' capability)
 * @return void
 */
function wpclpro_admin_form() {
	// The controller that handles the logic.
	$controller = new Wpclpro_Controller();
	$controller->wpclpro_check_access_capability();

	// Raise temporarily the time limits, because if database is big, the processing takes longer.
	Wpclpro_Utilities::wpclpro_raise_time_limits();

	// The tabber that builds the tabs.
	$tabber = new Wpclpro_Tabber();
	?>

	<div class="wrap">
		<h2 class="wpclpro-header">
			<span class="dashicons dashicons-pressthis"></span>
			<?php esc_html_e( 'WP Cleaner Pro', 'wpclpro' ); ?>
			<sup class="wpclpro-sup">version
				<span>
					<?php echo esc_html( Wpclpro_Utilities::wpclpro_get_plugin_version() ); ?>
					<form action="https://www.paypal.com/donate" method="post" target="_top">
			<input type="hidden" name="hosted_button_id" value="DJGS6D5UEDZNJ" />
			<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif" border="0" name="submit" title="PayPal - The safer, easier way to pay online!" alt="Donate with PayPal button" />
			<img alt="" border="0" src="https://www.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1" />
			</form>
				</span>
			</sup>
			
		</h2>

		<div id="wpclpro-progress" class="wpclpro-hidden">
			<span><?php esc_html_e( 'Processing, please wait...', 'wpclpro' ); ?></span>
		</div>

		<div id="wpclpro-bar" class="error notice is-dismissible">
			<p>
			<?php esc_html_e( 'No item was selected. Please select items that can be cleaned first, checking the checkboxes from the table below.', 'wpclpro' ); ?>
			</p>
		</div>

		<a href="#" id="back-to-top" title="Back to top" class="button-primary">&uarr;</a>

		<div class="wpclpro-tabs-holder" id="wpclpro-tabs-holder">
			<?php $tabber->wpclpro_tabs_start(); ?>

			<?php $tabber->wpclpro_tab( __( 'Clean', 'wpclpro' ), 'wpclpro-tab-clean.php' ); ?>

			<?php $tabber->wpclpro_tab( __( 'Details', 'wpclpro' ), 'wpclpro-tab-details.php' ); ?>

			<?php $tabber->wpclpro_tab( __( 'Log', 'wpclpro' ), 'wpclpro-tab-log.php' ); ?>

			<?php $tabber->wpclpro_tab( __( 'Backup', 'wpclpro' ), 'wpclpro-tab-backup.php' ); ?>

			<?php $tabber->wpclpro_tab( __( 'Support', 'wpclpro' ), 'wpclpro-tab-support.php' ); ?>

			<?php $tabber->wpclpro_tab( __( 'About', 'wpclpro' ), 'wpclpro-tab-about.php' ); ?>

			<?php $tabber->wpclpro_tabs_end(); ?>
		</div>
	</div>

	<?php
	// Restore the time limits to their original settings.
	Wpclpro_Utilities::wpclpro_restore_time_limits();
}  // end of wpclpro_admin_form() method
