<?php
/**
 * Holds the data displayed on the Backup tab.
 *
 * @package    wp-cleaner-pro
 * @author     hevada <support@hevada.com>
 * @copyright  2017-2030 hevada <support@hevada.com>
 * @link       http://codecanyon.net/user/hevada
 * @version    6.3
 * @since      1.0
 */

?>
<form action="" method="post" name="wpclpro-form" id="wpclpro-form">
	<?php wp_nonce_field( Wpclpro_Loader::ACTION, Wpclpro_Loader::NONCE, true, true ); ?>
	<input type="hidden" name="wpclpro-action" id="wpclpro-action" value="-1">
	<?php
	// Get the actual backups.
	$controller = new Wpclpro_Controller();
	$backups    = $controller->wpclpro_get_backups();
	if ( ! empty( $backups ) ) {
		$nr_backups = count( $backups );
	} else {
		$nr_backups = 0;
	}
	?>

	<div class="wpclpro-message wpclpro-gray">
		<span class="dashicons dashicons-info"></span>
		<?php
		esc_html_e(
			'You can create here a database backup which you can restore later. (only the latest 10 backups are stored) ',
			'wpclpro'
		);
		?>
	</div>
	<div class="wpclpro-message wpclpro-gray">
		<span class="dashicons dashicons-book"></span>
		<?php esc_html_e( 'Read more about: ', 'wpclpro' ); ?>
		<a href="https://developer.wordpress.org/advanced-administration/security/backup/" target="_blank">
			<?php esc_html_e( 'restoring your database from a backup', 'wpclpro' ); ?>
		</a>
	</div>

	<div class="wpclpro-spacer"></div>
	<div class="alignleft actions">
		<input type="button" class="button button-primary"
			value="<?php esc_attr_e( 'Create a database backup', 'wpclpro' ); ?>"
			onclick="javascript: wpclpro_create_backup();">
	</div>

	<?php $class = ( 0 === $nr_backups ) ? 'wpclpro-hidden' : ''; ?>
	<div class="alignleft actions <?php echo esc_attr( $class ); ?> wpclpro-delete-backups">
	<input type="button" class="button button-primary"
		value="<?php esc_attr_e( 'Delete all backups', 'wpclpro' ); ?>"
		onclick="javascript: wpclpro_delete_all_backups();">
	</div>
	<br class="clear"><br>

	<!-- The id of the backup to delete -->
	<input type="hidden"
		id="<?php echo esc_attr( Wpclpro_Loader::BACKUP_NAME ); ?>"
		name="<?php echo esc_attr( Wpclpro_Loader::BACKUP_NAME ); ?>"
		value="0">
	<table class="widefat wpclpro-table wpclpro-backup-table order-column hover cell-border" id="wpclpro-table">
	<thead>
		<!-- Table header-->
		<tr>
			<th>
				<?php esc_html_e( '#', 'wpclpro' ); ?>
			</th>
			<th>
				<?php esc_html_e( 'Backup name', 'wpclpro' ); ?>
			</th>
			<th>
				<?php esc_html_e( 'When it was created', 'wpclpro' ); ?>
			</th>
			<th>
				<?php esc_html_e( 'Backup size', 'wpclpro' ); ?>
			</th>
			<th>
				<?php esc_html_e( 'Download', 'wpclpro' ); ?>
			</th>
			<th>
				<?php esc_html_e( 'Delete', 'wpclpro' ); ?>
			</th>
		</tr>
	</thead>

	<tbody id="wpclpro-tbody">
	</tbody>

	<tfoot>
	<!-- Table footer-->
		<tr>
			<th>
				<?php esc_html_e( '#', 'wpclpro' ); ?>
			</th>
			<th>
				<?php esc_html_e( 'Backup name', 'wpclpro' ); ?>
			</th>
			<th>
				<?php esc_html_e( 'When it was created', 'wpclpro' ); ?>
			</th>
			<th>
				<?php esc_html_e( 'Backup size', 'wpclpro' ); ?>
			</th>
			<th>
				<?php esc_html_e( 'Download', 'wpclpro' ); ?>
			</th>
			<th>
				<?php esc_html_e( 'Delete', 'wpclpro' ); ?>
			</th>
		</tr>
	</tfoot>
	</table>

	<br class="clear">
	<div class="alignleft actions">
		<input type="button" class="button button-primary"
			value="<?php esc_attr_e( 'Create a database backup', 'wpclpro' ); ?>"
			onclick="javascript: wpclpro_create_backup();">
	</div>
	<?php $class = ( 0 === $nr_backups ) ? 'wpclpro-hidden' : ''; ?>
	<div class="alignleft actions <?php echo esc_attr( $class ); ?> wpclpro-delete-backups">
	<input type="button" class="button button-primary"
		value="<?php esc_attr_e( 'Delete all backups', 'wpclpro' ); ?>"
		onclick="javascript: wpclpro_delete_all_backups();">
	</div>

	<br class="clear"><br><br>

	<div class="alignleft wpclpro-gray">
		<span class="dashicons dashicons-info"></span>
		<span>
			<?php
			esc_html_e(
				'Note: Files names have this format:
				db-backup_DD-MM-YYYY_hh-mm-ss.sql where DD=day, MM=month, YYYY=year, hh=hours, mm=minutes, ss=seconds',
				'wpclpro'
			);
			?>
		</span>
	</div>
<br class="clear"><br>
</form>
