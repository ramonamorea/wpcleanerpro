<?php
/**
 * Holds the data displayed on the Details tab.
 *
 * @package    wp-cleaner-pro
 * @author     hevada <support@hevada.com>
 * @copyright  2017-2030 hevada <support@hevada.com>
 * @link       http://codecanyon.net/user/hevada
 * @version    6.3
 * @since      1.0
 */

$controller = new Wpclpro_Controller();
?>

<form action="" method="post" name="wpclpro-form" id="wpclpro-form">
<?php wp_nonce_field( Wpclpro_Loader::ACTION, Wpclpro_Loader::NONCE, true, true ); ?>

<div class="wpclpro-message wpclpro-gray">
	<span class="dashicons dashicons-database"></span>
	<?php esc_html_e( 'Showing details for:', 'wpclpro' ); ?>
		<span class="wpclpro-highlight">
		<?php
			$item_name = lcfirst( $controller->wpclpro_get_item_text( $controller->wpclpro_get_item() ) );
			// @codingStandardsIgnoreStart -- ignore all output should be run though escaping, because it does.
			echo sprintf(
				/* translators: %s: Name of a WordPress item that will be cleaned by the plugin */
				__( '%s.', 'wpclpro' ),
				$item_name
			);
			// @codingStandardsIgnoreEnd.
			?>
		</span>
</div>
<div class="wpclpro-message wpclpro-gray">
	<span class="dashicons dashicons-trash"></span>
	<?php
		$url = wp_nonce_url( 'tools.php?page=wpclpro&tabindex=0', Wpclpro_Loader::ACTION, Wpclpro_Loader::NONCE );

		printf(
			wp_kses(
				/* translators: %s: a link to the cleaning tab */
				__(
					'To view more items you can clean, please check the <a href="%s" title="clean">cleaning page.</a> .',
					'wpclpro'
				),
				array( 'a' => array( 'href' => array() ) )
			),
			esc_url( $url )
		);
		?>
</div>
<div class="wpclpro-spacer"></div>

<div class="wpclpro-details-holder" id="wpclpro-details-holder">
	<div class="wpclpro-loader" id="wpclpro-loader"><?php esc_html_e( 'Loading...', 'wpclpro' ); ?></div>
</div>
<br class="clear">

<div class="alignleft wpclpro-orange">
	<span>
	<?php esc_html_e( '*Note: For performance reasons, only the first 500 rows are shown.', 'wpclpro' ); ?>
	</span>
</div>
<br class="clear">
</form>

