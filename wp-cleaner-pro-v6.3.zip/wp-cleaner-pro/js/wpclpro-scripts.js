/** The HTML nodes corresponding to items that can be cleaned. */
var checkboxes = document.getElementsByName('items[]');
/** All the items (as Strings) that can be cleaned. */
var items = [];
/** The UI table shown to user (sortable, searchable, etc). */
var table;
/** An array keeping all currently running Ajax requests. */
jQuery.ajaxRequests = [];
/** An array keeping all currently running items for which counting processes are running. */
jQuery.ajaxItems = [];

/**
 * On document loaded, delegate for each tab the neccessary actions.
 */
jQuery(document).ready(function($) {
	
	// Creates the back to top button.
	wpclpro_backtop();
	
	// Reset the admin form first.
	jQuery('#wpclpro-form').trigger("reset");

	// See on which tab we are and perform the corresponding action.
	var queryString = window.location.search;
	var urlParams = new URLSearchParams(queryString);
	var tabindex = (urlParams.get('tabindex')) ? urlParams.get('tabindex') : 0;
	tabindex = tabindex.toString();
	
	// On tab 0 (Clean) show counting of cleanable items.
	switch(tabindex) {
	  case '0': // Clean tab
		  table = wpclpro_init_table([0, 3, 4], false, false);
		  for(var i = 0, n = checkboxes.length; i < n; i++) {
			  if (checkboxes[i].value.trim() != '') {
				  items.push(checkboxes[i].value);
			  }
		  }
		  wpclpro_count_items(items);
		  break;
	  case '1': // Details
		  item = urlParams.get('item');
		  wpclpro_show_details(item);
		  break;
	  case '2': // Log
		  table = wpclpro_init_table([0], true, true);
		  wpclpro_show_logs();
		  break;
	  case '3': // Backup
		  table = wpclpro_init_table([0, 4, 5], true, false);
		  wpclpro_show_backups();
		  break;
	  default:
		  table = wpclpro_init_table([], false, false);
	  	  break;
	} 
});

/**
 * Inits a data table.
 * @param notordered array Array indicating which columns should not be ordered.
 * @param numbered boolean Indicator showing if the table rows should be numbered.
 * @param paging boolean Indicator showing if the table should be paged.
 * @return void
 */
function wpclpro_init_table(notordered, numbered, paging, data) {

	table = jQuery('#wpclpro-table').DataTable( {
		"dom": '<if<t>ip>',
		"ordering": true,
        "info":     true,
        "paging": paging,
        "lengthChange": false,
        "pageLength": 20,
        "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
        "select": true,
        "responsive": true,
        "deferRender": true,
        "searching": true,
        "retrieve": true,
        "data": data,
        "processing": true,
        "scrollX": true,
        "language": {
            "emptyTable": "No data to show.",
            "search": ' ',
            "searchPlaceholder": 'Search...'
        },
        "order": [],
        "columnDefs": [{
        		'orderable': false,
        		'targets': notordered, 
	    }],
	    initComplete: function() {
	        jQuery('#wpclpro-table_filter input').attr("placeholder", "Search...");
	    }
 	  } );
	
	// Add row numbers.
	if (numbered) {
		 table.on( 'order.dt search.dt', function () {
			 table.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
		            cell.innerHTML = i+1;
		        } );
		 } ).draw();
	}
	
	return table;
}
/**
 * Counts all cleanable items, initiating Ajax requests.
 * @param array The items to count.
 * @return void
 */
function wpclpro_count_items(items) {
	for(var i = 0, n = items.length; i < n; i++) {
		wpclpro_count(items[i]);
  	}
}

/**
 * Send an Ajax request to server, to count how many items of type given as parameter.
 * @param item The type of item to count.
 * @return void
 */
function wpclpro_count(item) {
	jQuery('#wpclpro-count-value-' + item)
			  .html('')
			  .html('<span id="wpclpro-inloader-"' + item + ' class="wpclpro-status">'
					  + wpclproajax.counting + '</span>')
			  .show();
	
	var data = {
	        'action': 'wpclpro_count_item',
	        'post_type': 'post',
	        'item' : item,
	        'wpclpro-nonce' : jQuery('#wpclpro-nonce').val()
    };
    
	var xhr = new window.XMLHttpRequest();
    var request = jQuery.ajax({
       type : "GET",
       url: wpclproajax.ajaxurl,
       contentType: "application/json; charset=utf-8",
       data : data,
       dataType:"json",
       url: wpclproajax.ajaxurl,
       xhr : function(){
           return xhr;
       },
       beforeSend: function() {
    	   jQuery.ajaxRequests.push(xhr);
    	   jQuery.ajaxItems.push(item);
       },
       success: function(response) {
    	   if (response && response.count && response.count != '0' ) {
    		  if (response.detailslink && response.detailslink.trim() != "" ) {
         		  jQuery('#wpclpro-details-link-' + item).attr("href", response.detailslink.trim());
         		  jQuery('#wpclpro-details-link-' + item + ' span')
         		  													.removeClass("wpclpro-lightgray")
         		  													.addClass("wpclpro-turqoise");
         	  }
         	  if (response.cleanlink && response.cleanlink.trim() != "" ) {
         		  jQuery('#wpclpro-clean-link-' + item).attr("href", response.cleanlink.trim());
         		  jQuery('#wpclpro-clean-link-' + item + ' span')
         		  												.removeClass("wpclpro-lightgray")
         		  												.addClass("wpclpro-orange");
         	  }
         	  var row = table.cell('#wpclpro-count-value-' + item).index().row;
        	  var column = table.cell('#wpclpro-count-value-' + item).index().column;
        	  api = jQuery('#wpclpro-table').dataTable();
        	  api.fnUpdate( response.count, row, column ); 
       	  
        	  jQuery('#wpclpro-count-value-' + item)
   		  										.removeClass("wpclpro-lightgray")
   		  										.addClass("wpclpro-red");
          } else {
    		  jQuery('#wpclpro-details-link-' + item).removeAttr("href");
    		  jQuery('#wpclpro-details-link-' + item + ' span')
    		  													.removeClass("wpclpro-turqoise")
    		  													.addClass("wpclpro-lightgray");
    		  
    		  jQuery('#wpclpro-clean-link-' + item).removeAttr("href");
    		  jQuery('#wpclpro-clean-link-' + item + ' span')
    		  													.removeClass("wpclpro-orange")
    		  													.addClass("wpclpro-lightgray");
    		  
    		  var row = table.cell('#wpclpro-count-value-' + item).index().row;
         	  var column = table.cell('#wpclpro-count-value-' + item).index().column;
         	  api = jQuery('#wpclpro-table').dataTable();
         	  api.fnUpdate( '0', row, column );
         	  
        	  jQuery('#wpclpro-count-value-' + item)
        	  										.removeClass("wpclpro-red")
    		  										.addClass("wpclpro-lightgray");
          }
    	  if (response) {
			   wpclpro_show_message_bar(response.message, response.messagetype);
		  }
       },
       error: function(xhr, status, error){
    	   jQuery('#wpclpro-inloader-' + item).hide();
    	   if (xhr.readyState != 0) {
    		   wpclpro_show_message_bar(wpclproajax.dberror, 'error');
    	   }
       }
	});
}

/**
 * Send an Ajax request to server, to show the details of a cleanable item.
 * @param item The type of item to show the details for.
 * @return void
 */
function wpclpro_show_details(item) {
	jQuery('.notice.is-dismissible').hide();
	var data = {
	        'action': 'wpclpro_show_details',
	        'post_type': 'post',
	        'item' : item,
	        'wpclpro-security' : jQuery('#wpclpro-nonce').val()
    };
    
    jQuery.ajax({
       type : "GET",
       url: wpclproajax.ajaxurl,
       contentType: "application/json; charset=utf-8",
       data : data,
       dataType:"json",
       url : wpclproajax.ajaxurl,  
       success: function(response) {
    	   if (response && response.output) {
    		   jQuery('#wpclpro-loader').hide();
    		   jQuery('#wpclpro-details-holder').append(response.output);
    		   table = wpclpro_init_table([0], true, true);
    	   }
    	   if (response) {
			   wpclpro_show_message_bar(response.message, response.messagetype);
		   }
       },
       error: function(xhr, status, error){
    	   if (xhr.readyState != 0) {
    		   wpclpro_show_message_bar(wpclproajax.dberror, 'error');
    	   }
       } 
	});
}

/**
 * Send an Ajax request to server, to create a backup of the database.
 * @return void
 */
function wpclpro_create_backup() {
	jQuery('.notice.is-dismissible').hide();
	wpclpro_show_progress();
	
	var data = {
	        'action': 'wpclpro_create_backup',
	        'post_type': 'post',
	        'wpclpro-security' : jQuery('#wpclpro-nonce').val()
    };
	
    jQuery.ajax({
       type : "GET",
       url: wpclproajax.ajaxurl,
       contentType: "application/json; charset=utf-8",
       data : data,
       dataType:"json",
       url : wpclproajax.ajaxurl,
       success: function(response) {
    	   if (response) {
    		   jQuery('.notice.is-dismissible').hide();
    		   wpclpro_hide_progress();
    		   
    		   wpclpro_show_message_bar(response.message, response.messagetype);
    		   
    		   if (response.backups_exist && response.backups_exist == 'yes') {
    			   jQuery('.wpclpro-delete-backups').show();
    		   } else {
    			   jQuery('.wpclpro-delete-backups').hide();
    		   }
    		   wpclpro_show_backups();
    	   }
       },
       error: function(xhr, status, error){
    	   if (xhr.readyState != 0) {
    		   wpclpro_show_message_bar(wpclproajax.dberror, 'error');
    	   }
       } 
	});
}

/**
* Send an Ajax request to server, to display all the backups.
* @return void
*/
function wpclpro_show_backups() {
	var dataSet = [];
	
	var data = {
	        'action': 'wpclpro_show_backups',
	        'post_type': 'post',
	        'wpclpro-security' : jQuery('#wpclpro-nonce').val()
    };
	
    jQuery.ajax({
       type : "GET",
       url: wpclproajax.ajaxurl,
       contentType: "application/json; charset=utf-8",
       data : data,
       dataType:"json",
       url : wpclproajax.ajaxurl,
       success: function(response) {
    	   if (response && response.backups) {
    		   wpclpro_hide_progress();
    		   
    		   jQuery.each(response.backups, function(i, backup) {
    				dataSet.push([
    					"",
    					backup['name'],
    					backup['date'],
    					backup['size'],
    					backup['download'],
    					backup['delete']
    				]);
    			});
    		   
    		   	table.destroy();
    		   	table = wpclpro_init_table([0], true, true, dataSet);
    	   }
    	   if (response) {
			   wpclpro_show_message_bar(response.message, response.messagetype);
		   }
       },
       error: function(xhr, status, error){
    	   if (xhr.readyState != 0) {
    		   wpclpro_show_message_bar(wpclproajax.dberror, 'error');
    	   }
       } 
	});
}

/**
* Send an Ajax request to server, to display all the logs.
* @return void
*/
function wpclpro_show_logs() {
	var dataSet = [];
	
	var data = {
	        'action': 'wpclpro_show_logs',
	        'post_type': 'post',
	        'wpclpro-security' : jQuery('#wpclpro-nonce').val()
    };
	
    jQuery.ajax({
       type : "GET",
       url: wpclproajax.ajaxurl,
       contentType: "application/json; charset=utf-8",
       data : data,
       dataType:"json",
       url : wpclproajax.ajaxurl,
       success: function(response) {
    	   if (response && response.logs) {
    		   wpclpro_hide_progress();
    		   
    		   jQuery.each(response.logs, function(i, log) {
    				dataSet.push([
    					"",
    					log['time'],
    					log['classname'],
    					log['line'],
    					log['level'],
    					log['message']
    				]);
    			});
    		   
    		    table.destroy();
    		    table = wpclpro_init_table([0], true, true, dataSet);
    	   }
       },
       error: function(xhr, status, error){
    	   if (xhr.readyState != 0) {
    		   wpclpro_show_message_bar(wpclproajax.dberror, 'error');
    	   }
       } 
	});
}

/**
* Send an Ajax request to server, to delete all the backups.
* @return void
*/
function wpclpro_delete_all_backups() {
	jQuery('.notice.is-dismissible').hide();
	wpclpro_show_progress();
	
	var data = {
	        'action': 'wpclpro_delete_all_backups',
	        'post_type': 'post',
	        'wpclpro-security' : jQuery('#wpclpro-nonce').val()
   };
	    
   jQuery.ajax({
      type : "GET",
      url: wpclproajax.ajaxurl,
      contentType: "application/json; charset=utf-8",
      data : data,
      dataType: "json",
      url : wpclproajax.ajaxurl,
      success: function(response) {
    	  if (response) {
    		  jQuery('.notice.is-dismissible').hide();
    		  wpclpro_hide_progress();
    		  
			  wpclpro_show_message_bar(response.message, response.messagetype);
    		  
    		  if (response.backups_exist && response.backups_exist == 'yes') {
    			  jQuery('.wpclpro-delete-backups').show();
    		  } else {
    			  jQuery('.wpclpro-delete-backups').hide();
    		  }
    		  wpclpro_show_backups();
    	  }
      },
      error: function(xhr, status, error){
    	  if (xhr.readyState != 0) {
    		  wpclpro_show_message_bar(wpclproajax.dberror, 'error');
    	  }
      } 
	});
}

/**
* Send an Ajax request to server, to delete a given backup.
* @return void
*/
function wpclpro_delete_backup(backup) {
	if (!backup) {
		return;
	}
	jQuery('.notice.is-dismissible').hide();
	wpclpro_show_progress();
	
	var data = {
	        'action': 'wpclpro_delete_backup',
	        'post_type': 'post',
	        'wpclpro-backup-name': backup,
	        'wpclpro-security' : jQuery('#wpclpro-nonce').val()
   };
	    
   jQuery.ajax({
      type : "GET",
      url: wpclproajax.ajaxurl,
      contentType: "application/json; charset=utf-8",
      data : data,
      dataType:"json",
      url : wpclproajax.ajaxurl,
      success: function(response) {
    	  if (response) {
	   		   jQuery('.notice.is-dismissible').hide();
	   		   wpclpro_hide_progress();
	   		   
			   wpclpro_show_message_bar(response.message, response.messagetype);
	   		   
			   if (response.backups_exist && response.backups_exist == 'yes') {
				   jQuery('.wpclpro-delete-backups').show();
			   } else {
				   jQuery('.wpclpro-delete-backups').hide();
			   }
			   wpclpro_show_backups();
    	  }
      },
      error: function(xhr, status, error){
    	  if (xhr.readyState != 0) {
    		  wpclpro_show_message_bar(wpclproajax.dberror, 'error');
    	  }
      } 
	});
}

/**
* Send an Ajax request to server, to delete all the logs.
* @return void
*/
function wpclpro_delete_all_logs() {
	jQuery('.notice.is-dismissible').hide();
	wpclpro_show_progress();
	
	var data = {
	        'action': 'wpclpro_delete_all_logs',
	        'post_type': 'post',
	        'wpclpro-security' : jQuery('#wpclpro-nonce').val()
   };
	    
   jQuery.ajax({
      type : "GET",
      url: wpclproajax.ajaxurl,
      contentType: "application/json; charset=utf-8",
      data : data,
      dataType:"json",
      cache: false,
      url : wpclproajax.ajaxurl,
      success: function(response) {
    	  if (response) {
    		  jQuery('.notice.is-dismissible').hide();
    		  wpclpro_hide_progress();
    		  jQuery('#wpclpro-tbody').empty();
    		  
			  wpclpro_show_message_bar(response.message, response.messagetype);
    		  
    		  if (response.logs_exist == 'yes') {
    			  jQuery('.wpclpro-delete-logs').show();
    		  } else {
    			  jQuery('.wpclpro-delete-logs').hide();
    		  }
    		  
    		  jQuery('#wpclpro-form').trigger("reset");
    		  wpclpro_show_logs();
    	  }
      },
      error: function(xhr, status, error){
    	  if (xhr.readyState != 0) {
    		  wpclpro_show_message_bar(wpclproajax.dberror, 'error');
   	      }
      } 
	});
}

/**
 * Send an Ajax request to server, to clean cleanable items from the database.
 * @return void
 */
function wpclpro_clean_items() {
	
	jQuery('.notice.is-dismissible').hide();
	wpclpro_show_progress();
	//jQuery("#wpclpro-form *").prop("disabled", true);

	wpclpro_reset_counter();
	
	for(var i = 0, n = checkboxes.length; i < n; i++) {
		if (checkboxes[i].checked && checkboxes[i].value.trim() != '' && !checkboxes[i].disabled) {
			// Call wpclpro_clean(item, with_optimization) function.
			wpclpro_clean(checkboxes[i].value);
		}
  	}
	
	jQuery("input[type=checkbox][value='']").prop("checked", false);
	//jQuery("#wpclpro-form *").prop("disabled", false);
}

/**
 * Send an Ajax request to server, to clean the item given as parameter.
 * @param item The item to be cleaned.
 * @return the Ajax response
 */
function wpclpro_clean(item) {
	jQuery("input[type=checkbox][value='" + item + "']").prop("checked", true);
	
	jQuery('#wpclpro-count-value-' + item)
											.html('')
											.html('<span id="wpclpro-inloader-"' + item + ' class="wpclpro-status">'
													+ wpclproajax.cleaning + '</span>')
											.show();
	
	jQuery('#wpclpro-details-link-' + item).removeAttr("href");
	jQuery('#wpclpro-details-link-' + item + ' span')
													.removeClass("wpclpro-turqoise")
													.addClass("wpclpro-lightgray");
	  
	jQuery('#wpclpro-clean-link-' + item).removeAttr("href");
	jQuery('#wpclpro-clean-link-' + item + ' span')
													.removeClass("wpclpro-orange")
													.addClass("wpclpro-lightgray");
			
	var data = {
	        'action': 'wpclpro_clean_item',
	        'post_type': 'post',
	        'item': item,
	        'wpclpro-security' : jQuery('#wpclpro-nonce').val()
    };
	    
    jQuery.ajax({
       type : "GET",
       url: wpclproajax.ajaxurl,
       contentType: "application/json; charset=utf-8",
       data : data,
       dataType:"json",
       url : wpclproajax.ajaxurl,
       beforeSend: function() {
			index = jQuery.ajaxItems.indexOf(item); 
			jQuery.xhr = jQuery.ajaxRequests[index];
			if(jQuery.xhr) jQuery.xhr.abort();
			jQuery.ajaxItems.splice(index, 1);
			jQuery.ajaxRequests.splice(index, 1);
      },
       success: function(response){ 
    	   if (response) {
    		   jQuery("input[type=checkbox][value='" + item + "']").prop("checked", false);
    		   wpclpro_count(item);
			   wpclpro_show_message_bar(response.message, response.messagetype);
    	   }
       },
       complete: function(response){ 
           if (jQuery.ajaxRequests.length == items.length) {
               // All cleaning completed, doing optimize.
               wpclpro_optimize_tables();
           }
       },
       error: function(xhr, status, error){
    	   jQuery("input[type=checkbox][value='" + item + "']").prop("checked", false);
    	   wpclpro_count(item);
    	   if (xhr.readyState != 0) {
    		   wpclpro_show_message_bar(wpclproajax.dberror, 'error');
    	   }
       } 
	});
}

/**
 * Send an Ajax request to server, to schedule the selected items for cleaning.
 * @return void
 */
function wpclpro_schedule_items() {
	
	jQuery('.notice.is-dismissible').hide();
	wpclpro_show_progress();
	jQuery("#wpclpro-form *").prop("disabled", true);
	frequency = jQuery('#wpclpro-frequency-top option:selected' ).val();
	
	var scheduled = [];
	for(var i = 0, n = checkboxes.length; i < n; i++) {
		if (checkboxes[i].checked && checkboxes[i].value.trim() != '') {
			scheduled.push(checkboxes[i].value);
		}
  	}
	
	var data = {
	        'action': 'wpclpro_schedule_items',
	        'post_type': 'post',
	        'items': scheduled,
	        'wpclpro-frequency': frequency,
	        'wpclpro-security' : jQuery('#wpclpro-nonce').val()
    };
	
	jQuery.ajax({
	       type : "GET",
	       url: wpclproajax.ajaxurl,
	       contentType: "application/json; charset=utf-8",
	       data : data,
	       dataType:"json",
	       url : wpclproajax.ajaxurl,
	       success: function(response) {
	    	   if (response) {
	    		   jQuery('#wpclpro-scheduled').load(document.URL +  ' #wpclpro-scheduled');
	    		   jQuery('#wpclpro-scheduled').attr('style','display:inline-block !important');
	    		   
	    		   for(var i = 0, n = items.length; i < n; i++) {
		    		   wpclpro_get_scheduled_label(items[i]);
		    	   }
				   wpclpro_show_message_bar(response.message, response.messagetype);
	    		   jQuery("input[type=checkbox]").prop("checked", false);
	    		   jQuery("#wpclpro-form *").prop("disabled", false);
	    	   }
	       },
	       error: function(xhr, status, error){
	    	   jQuery("input[type=checkbox]").prop("checked", false);
    		   jQuery("#wpclpro-form *").prop("disabled", false);
    		   if (xhr.readyState != 0) {
        		   wpclpro_show_message_bar(wpclproajax.dberror, 'error');
        	   }
	       } 
		});
}

/**
 * Send an Ajax request to server, to unschedule the scheduled cleaning.
 * @return void
 */
function wpclpro_unschedule() {
	jQuery('.notice.is-dismissible').hide();
	wpclpro_show_progress();
	jQuery("#wpclpro-form *").prop("disabled", true);
	
	var data = {
	        'action': 'wpclpro_unschedule',
	        'post_type': 'post',
	        'wpclpro-security' : jQuery('#wpclpro-nonce').val()
    };
	
	jQuery.ajax({
	       type : "GET",
	       url: wpclproajax.ajaxurl,
	       contentType: "application/json; charset=utf-8",
	       data : data,
	       dataType:"json",
	       url : wpclproajax.ajaxurl,
	       success: function(response) {
	    	   if (response) {
	    		   wpclpro_hide_progress();
	    		   for(var i = 0, n = items.length; i < n; i++) {
		    		   wpclpro_get_scheduled_label(items[i]);
		    	   }
	    		   wpclpro_show_message_bar(response.message, response.messagetype);
	    		   jQuery('#wpclpro-scheduled').hide().empty();
	    		   jQuery("#wpclpro-form #action-top").val("-1");
	    		   jQuery("#wpclpro-form #action-bottom").val("-1");
	    		   wpclpro_hide_frequency();
	    		   jQuery("#wpclpro-form *").prop("disabled", false);
	    	   }
	       },
	       error: function(xhr, status, error){
	    	   if (xhr.readyState != 0) {
	    		   wpclpro_show_message_bar(wpclproajax.dberror, 'error');
	    	   }
	       } 
		});
}

/**
 * Send an Ajax request to server, to optimize the database tables.
 * @return void
 */
function wpclpro_optimize_tables() {
	
	var data = {
	        'action': 'wpclpro_optimize_tables',
	        'post_type': 'post',
	        'wpclpro-security' : jQuery('#wpclpro-nonce').val()
    };
	
	jQuery.ajax({
	       type : "GET",
	       url: wpclproajax.ajaxurl,
	       contentType: "application/json; charset=utf-8",
	       data : data,
	       dataType:"json",
	       url : wpclproajax.ajaxurl,
	       success: function(response) {
	    	   // Nothing to do especially, the user has already seen the cleaning message.
	       },
	       error: function(xhr, status, error){
	    	   if (xhr.readyState != 0) {
	    		   wpclpro_show_message_bar(wpclproajax.dberror, 'error');
	    	   }
	       } 
		});
}

/**
 * Send an Ajax request to server, to reset the cleaning counter.
 * @return void
 */
function wpclpro_reset_counter() {
	
	var data = {
	        'action': 'wpclpro_reset_counter',
	        'post_type': 'post',
	        'wpclpro-security' : jQuery('#wpclpro-nonce').val()
    };
	
	jQuery.ajax({
	       type : "GET",
	       url: wpclproajax.ajaxurl,
	       contentType: "application/json; charset=utf-8",
	       data : data,
	       dataType:"json",
	       url : wpclproajax.ajaxurl,
	       success: function(response) {
	    	   // Nothing to do especially, the user has already seen the cleaning message.
	       },
	       error: function(xhr, status, error){
	    	   if (xhr.readyState != 0) {
	    		   wpclpro_show_message_bar(wpclproajax.dberror, 'error');
	    	   }
	       } 
		});
}

/**
 * Send an Ajax request to server, to get the scheduled/not scheduled label.
 * @param item The item to get the scheduled/not scheduled label for.
 * @return void
 */
function wpclpro_get_scheduled_label(item) {
	jQuery('.notice.is-dismissible').hide();
	wpclpro_show_progress();
	
	var data = {
	        'action': 'wpclpro_get_scheduled_label',
	        'post_type': 'post',
	        'item': item,
	        'wpclpro-security' : jQuery('#wpclpro-nonce').val()
    };
	
	jQuery.ajax({
	       type : "GET",
	       url: wpclproajax.ajaxurl,
	       contentType: "application/json; charset=utf-8",
	       data : data,
	       dataType:"json",
	       url : wpclproajax.ajaxurl,
	       success: function(response) {
	    	   if (response && response.output) {
	    		   jQuery( "#scheduled-" + item ).empty().prepend(response.output);
	    	   }
	       },
	       error: function(xhr, status, error){
	    	   if (xhr.readyState != 0) {
	    		   wpclpro_show_message_bar(wpclproajax.dberror, 'error');
	    	   }
	       } 
		});
}

/**
 * Shows a message in the top side of the page, of type notice/error.
 * @param message The message to be displayed.
 * @param type The type of the message: notice or error.
 * @return void
 */
function wpclpro_show_message_bar(message, type) {
	if (!message || !type) {
		return;
	}
	
	if (type == 'notice') {
		wpclpro_hide_progress();
		jQuery('#wpclpro-bar').removeClass('error');
		jQuery('#wpclpro-bar').addClass('updated wpclpro-notice');
		jQuery('#wpclpro-bar').children("p:first").remove();
		jQuery('#wpclpro-bar').append('<p>' + message + '</p>');
		jQuery('#wpclpro-bar').show();
	}
	if (type == 'error') {
		wpclpro_hide_progress();
		jQuery('#wpclpro-bar').removeClass('updated wpclpro-notice');
		jQuery('#wpclpro-bar').addClass('error');
		jQuery('#wpclpro-bar').children("p:first").remove();
		jQuery('#wpclpro-bar').append('<p>' + message + '</p>');
		jQuery('#wpclpro-bar').show();
	}
}

/**
 * Toggles on/off the checkboxes given as parameters.
 * @param source The checkboxes to toggle on/off.
 * @return void
 */
function wpclpro_toggleAll(source) {
	for(var i = 0, n = checkboxes.length; i < n; i++) {
    	checkboxes[i].checked = source.checked;
  	}
}

/**
 * Toggles on/off the checkbox given as pameter.
 * @param source The checkbox to toggle on or off.
 * @return void
 */
function wpclpro_toggle(source) {
	if (!source.checked) {
		checkboxes[0].checked = false;
		checkboxes[checkboxes.length - 1].checked = false;
	} else {
		var allChecked = true;
		for(var i = 1, n = checkboxes.length - 1; i < n; i++) {
			if (!checkboxes[i].checked) {
				allChecked = false;
			}
    		
  		}
  		if (allChecked) {
			checkboxes[0].checked = true;
			checkboxes[checkboxes.length - 1].checked = true;
		}
	}
}

/**
 * Synchronizes the actions and show/hide frequency filters. 
 * @param value The value of the select to synchronize.
 * @return void
 */
function wpclpro_bulk_actions(value) {
	// Synchronize actions first.
	wpclpro_synchronize_actions(value);
	// Show/hide frequency filters (show only when the action is "schedule", otherwise hide).
	if (value == 'action-schedule') {
		wpclpro_show_frequency();
	} else {
		wpclpro_hide_frequency();
	}
}

/**
 * Makes the select with the id "#action" have the same value at the top and bottom of page. 
 * @param value The value of the select to synchronize.
 * @return void
 */
function wpclpro_synchronize_actions(value) {
    jQuery('select#action-top').val(value);
    jQuery('select#action-bottom').val(value);
    jQuery('#wpclpro-action').val(value);
}

/**
 * Makes the select with the id "#filter-items" have the same value at the top and bottom of page. 
 * @param value The value of the select to synchronize.
 * @return void
 */
function wpclpro_synchronize_filters(value) {
    jQuery('select#filter-items-top').val(value);
    jQuery('select#filter-items-bottom').val(value);
}

/**
 * Makes the select with the id "#Frequency" have the same value at the top and bottom of page. 
 * @param value The value of the select to synchronize.
 * @return void
 */
function wpclpro_synchronize_frequency(value) {
    jQuery('select#wpclpro-frequency-top').val(value);
    jQuery('select#wpclpro-frequency-bottom').val(value);
}

/**
 * Makes the select with the id "#LogLevel" have the same value at the top and bottom of page. 
 * @param value The value of the select to synchronize.
 * @return void
 */
function wpclpro_synchronize_level(value) {
	jQuery('select#filter-logs-top').val(value);
    jQuery('select#filter-logs-bottom').val(value);
}

/**
 * Shows the select for frequency.
 * @return void
 */
function wpclpro_show_frequency() {
    jQuery('select#wpclpro-frequency-top').show();
    jQuery('select#wpclpro-frequency-bottom').show();
}

/**
 * Hides the select for frequency (is shown only for the 'schedule' action).
 * @return
 */
function wpclpro_hide_frequency() {
    jQuery('select#wpclpro-frequency-top').hide();
    jQuery('select#wpclpro-frequency-bottom').hide();
}

/**
 * Filters the items to clean. (all, comments, posts, terms, options, users and tables).
 * @return void
 */
function wpclpro_filter_items() {
    var category = jQuery('select#filter-items-top').val();
    table.search(category).draw();
}

/**
 * Filters the logs (INFO, ERROR).
 * @param level The log level to filter by.
 * @return void
 */
function wpclpro_filter_logs(level) {
    var level = jQuery('select#filter-logs-top').val();
    switch(level) {
    case "ALL":
    	table.search('').draw();
        break;
    case "INFO":
    	table.search( level ).draw();
        break;
    case "ERROR":
    	table.search( level ).draw();
        break;
    default: //all
    	table.search('').draw();
    }
}

/**
 * Hides an HTML obiect with the CSS class given as parameter and disables the corresponding checkbox.
 * @param className The CSS of the element to hide.
 * @return void
 */
function wpclpro_hide(className) {
    jQuery(className).hide();
    jQuery(className).find('input').attr('disabled', true);
}

/**
 * Shows an HTML obiect with the CSS class given as parameter and enables the corresponding checkbox.
 * @param className The CSS of the element to show.
 * @return void
 */
function wpclpro_show(className) {
    jQuery(className).show();
    jQuery(className).find('input').attr('disabled', false);
}

/**
 * Launches the action given by the 'action' parameter.
 * @param action The action to perform with the form.
 * @return void
 */
function wpclpro_action(action) {
	jQuery('#wpclpro-action').val(action);
	
	if (action && wpclpro_is_prepared() && action.trim() == 'action-clean') {
		wpclpro_clean_items();
	}
	
	if ( action && wpclpro_is_prepared() && action.trim() == 'action-schedule') {
		wpclpro_schedule_items();
    }
}

/**
 * Checks if the form is prepared for any action (if any checkbox is selected),  
 * otherwise displaying a warning message.
 * @return true If the form is ready for action, false otherwise. 
 */
function wpclpro_is_prepared() {
    action = jQuery('#action-top').val();
    
    if (action == "-1") {
    	wpclpro_show_message_bar('Please select first an action from the Bulk Actions box below.', 'notice');
    	return false;
    } else {
    	// validate if checkboxes are selected
        if(jQuery('#wpclpro-form input[type=checkbox]:checked').length == 0)  {
        	wpclpro_show_message_bar('Please select at least one item to perform this action on.', 'notice');
            return false;
        } else {
        	return true;
        }
    }
}

/**
 * Goes back to the caller page.
 * @return false if the back action was unsuccessful.
 */
function wpclpro_back() {
    location.href = document.referrer; 
    return false;
}

/**
 * Shows the progress bar.
 * @return void.
 */
function wpclpro_show_progress() {
	jQuery('#wpclpro-progress').attr('style','display:block !important');
}

/**
 * Hides the progress bar.
 * @return void.
 */
function wpclpro_hide_progress() {
	jQuery('#wpclpro-progress').attr('style','display:none !important');
}

/**
 * Searches a table HTML element for the text given.
 * @param text string The text to search for in the table.
 * @return void.
 */
function wpclpro_search_table(text) {
	table.search(text).draw();
}
/**
 * Creates a back to top button.
 * @param text string The text to search for in the table.
 * @return void.
 */
function wpclpro_backtop() {
	if (jQuery('#back-to-top').length) {
	    var scrollTrigger = 100, // px
	        backToTop = function () {
	            var scrollTop = jQuery(window).scrollTop();
	            if (scrollTop > scrollTrigger) {
	                jQuery('#back-to-top').addClass('show');
	            } else {
	                jQuery('#back-to-top').removeClass('show');
	            }
	        };
	    backToTop();
	    jQuery(window).on('scroll', function () {
	        backToTop();
	    });
	    jQuery('#back-to-top').on('click', function (e) {
	        e.preventDefault();
	        jQuery('html,body').animate({
	            scrollTop: 0
	        }, 700);
	    });
	}
}