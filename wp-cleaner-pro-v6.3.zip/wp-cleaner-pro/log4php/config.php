<?php
return array (
        'rootLogger' => array (
                'appenders' => array (
                        'primary'
                )
        ),
        'appenders' => array (
                'primary' => array (
                        'class' => 'Wpclpro_Logger_Appender'
                )
        )
);

?>