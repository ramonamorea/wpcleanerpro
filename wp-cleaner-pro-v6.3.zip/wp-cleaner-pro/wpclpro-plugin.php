<?php
/**
 * Plugin Name: WP Cleaner Pro
 * Description: WP Cleaner Pro cleans and optimizes your WordPress database, making your website faster.
 * Version: 6.3
 * Author: hevada
 * Copyright: 2017-2030 hevada <support@hevada.com>
 * Text Domain: wpclpro
 * Author URI: http://codecanyon.net/user/hevada
 * Plugin URI: http://codecanyon.net/user/hevada
 *
 * @package    wp-cleaner-pro
 */

/**
 * Block direct access to plugin's files.
 */
if ( ! defined( 'ABSPATH' ) ) {
	die( 'Plugins files cannot be accessed directly!' );
}

/**
 * Define the plugin's directory.
 */
define( 'WPCLPRO_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

/**
 * Init the classes auto-loader.
 */
require_once WPCLPRO_PLUGIN_DIR . '/classes/class-wpclpro-loader.php';

/**
 * Init the classes auto-loader on plugin init.
 *
 * @access public
 * @return void
 */
function wpclpro_init() {
	// Set the path, the namespace.
	Wpclpro_Loader::wpclpro_set_path( __DIR__ );
	Wpclpro_Loader::wpclpro_set_namespace( 'Wpclpro' );

	// And register the auto-loader.
	spl_autoload_register( 'Wpclpro_Loader::wpclpro_load' );
}
add_action( 'init', 'wpclpro_init' );

/**
 * Load plugin translations.
 *
 * @access public
 * @return void
 */
function wpclpro_load_textdomain() {
	load_plugin_textdomain( 'wpclpro', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
}
add_action( 'plugins_loaded', 'wpclpro_load_textdomain' );

/**
 * Displays a Dashboard link in Plugins -> Installed Plugins page.
 *
 * @access public
 * @param array  $links An array containing the Settings link.
 * @param string $file The plugin's folder name.
 *
 * @return array $links The formatted array containing the plugin action links.
 */
function wpclpro_plugin_action_links( $links, $file ) {
	if ( plugin_basename( __FILE__ ) === $file ) {

		// Define the Dashboard link.
		$wpclpro_links = '<a href="' . esc_attr( get_admin_url() ) . 'tools.php?page=wpclpro">' .
			esc_html__( 'Dashboard', 'wpclpro' ) . '</a>';

		// Make the link appear first.
		array_unshift( $links, $wpclpro_links );
	}
	return $links;
}
add_filter( 'plugin_action_links', 'wpclpro_plugin_action_links', 10, 2 );

/**
 * Display the 'Documentation' and the 'Support' links in Dashboard -> Plugins -> Installed Plugins.
 *
 * @access public
 * @param array  $links An array containing the Documentation and Support links.
 * @param string $file The plugin folder name.
 *
 * @return array $links the formatted array containing the plugin action links.
 */
function wpclpro_plugin_row_meta( $links, $file ) {
	if ( plugin_basename( __FILE__ ) === $file ) {

		$dashboard_link =
			'<a href="' . esc_attr( get_admin_url() ) . 'tools.php?page=wpclpro" title="'
			. esc_attr__( 'Plugin dashboard', 'wpclpro' ) . '">'
			. esc_html__( 'Dashboard', 'wpclpro' ) . '</a>';

		$documentation_link =
			'<a target="_blank" href="' . esc_attr( plugin_dir_url( __FILE__ ) )
			. 'documentation/" title="'
			. esc_attr__( 'View documentation', 'wpclpro' ) . '">'
			. esc_html__( 'Documentation', 'wpclpro' ) . '</a>';

		$support_link = '<a target="_blank" href="http://support.hevada.com" title="'
			. esc_attr__( 'Ask for support', 'wpclpro' ) . '">'
			. esc_html__( 'Support', 'wpclpro' ) . '</a>';

		$links[] = $dashboard_link;
		$links[] = $documentation_link;
		$links[] = $support_link;
	}
	return $links;
}
add_filter( 'plugin_row_meta', 'wpclpro_plugin_row_meta', 10, 2 );

/**
 * Adds a submenu under Tools menu for the plugin's settings page.
 *
 * @access public
 * @return void
 * @global false|string $wpclpro_tools_page The resulting page's hook_suffix, or false if
 * the user does not have the capability required.
 */
function wpclpro_admin_menu() {
	// Include the admin form.
	include_once 'views/wpclpro-admin-form.php';

	// Add plugin page in Tools menu.
	global $wpclpro_tools_page;
	$wpclpro_tools_page = add_management_page(
		__( 'WP Cleaner Pro', 'wpclpro' ),
		__( 'WP Cleaner Pro', 'wpclpro' ),
		'manage_options',
		'wpclpro',
		'wpclpro_admin_form'
	);
}
add_action( 'admin_menu', 'wpclpro_admin_menu' );

/**
 * Adds the plugin's CSS files.
 *
 * @access public
 * @param string $hook The plugin hook.
 * @return void
 * @global false|string $wpclpro_tools_page The resulting page's hook_suffix, or false if
 * the user does not have the capability required.
 */
function wpclpro_admin_styles( $hook ) {
	// If not on plugin's page, exit and do not add the CSS file.
	global $wpclpro_tools_page;
	if ( $hook !== $wpclpro_tools_page ) {
		return;
	}

	// Enqueue the plugin's CSS file.
	wp_enqueue_style( 'wpclpro', plugins_url( 'css/wpclpro-styles.css', __FILE__ ), null, '1.0' );

	// Register and enqueue the DataTables library.
	wp_enqueue_style(
		'wpclpro-datatables',
		plugins_url( 'lib/datatables/datatables.min.css', __FILE__ ),
		array(),
		'1.13.8',
		'all'
	);
}
add_action( 'admin_enqueue_scripts', 'wpclpro_admin_styles' );

/**
 * Adds the javascript/jQuery scripts.
 *
 * @access public
 * @param string $hook the plugin hook.
 * @return void
 * @global false|string $wpclpro_tools_page The resulting page's hook_suffix, or false if
 * the user does not have the capability required.
 */
function wpclpro_admin_scripts( $hook ) {
	// If not on plugin's page, exit and do not add the CSS file.
	global $wpclpro_tools_page;
	if ( $hook !== $wpclpro_tools_page ) {
		return;
	}

	// Register and enqueue the plugin's scripts.
	wp_enqueue_script( 'wpclpro-script', plugins_url( 'js/wpclpro-scripts.js', __FILE__ ), array( 'jquery' ), '1.0', true );
	$url = wp_nonce_url(
		admin_url( 'tools.php?page=wpclpro&tabindex=2' ),
		Wpclpro_Loader::ACTION,
		Wpclpro_Loader::NONCE
	);
	wp_localize_script(
		'wpclpro-script',
		'wpclproajax',
		array(
			'ajaxurl'  => admin_url( 'admin-ajax.php' ),
			'counting' => __( 'counting...', 'wpclpro' ),
			'cleaning' => __( 'cleaning...', 'wpclpro' ),
			'dberror'  => sprintf(
				wp_kses(
					/* translators: %s: the link is to the Log tab */
					__(
						'A database error occurred, for more details please check the <a href="%s" title="log">Log tab</a>.',
						'wpclpro'
					),
					array( 'a' => array( 'href' => array() ) )
				),
				esc_url( $url )
			),
		)
	);

	// Register and enqueue the DataTables library.
	wp_enqueue_script(
		'wpclpro-datatables-script',
		plugins_url( 'lib/datatables/datatables.min.js', __FILE__ ),
		array( 'jquery' ),
		'1.13.8',
		true
	);
}
add_action( 'admin_enqueue_scripts', 'wpclpro_admin_scripts' );

/**
 * Triggers the cleaning of scheduled items.
 *
 * @access public
 * @return void
 */
function wpclpro_trigger_scheduled_items() {
	$controller = new Wpclpro_Controller();
	$controller->wpclpro_start_scheduled_items();
}
add_action( Wpclpro_Loader::SCHEDULED_HOOK_NAME, 'wpclpro_trigger_scheduled_items' );

/**
 * Adds to the default schedules intervals the Weekly and Monthly intervals.
 *
 * @access public
 * @param array $schedules The default WordPress schedules intervals.
 * @return array[] the default scheduled intervals in WordPress plus "Weekly" and "Monthly".
 */
function wpclpro_add_intervals( $schedules ) {

	// Add 'weekly' interval (604800 seconds).
	$schedules['weekly'] = array(
		'interval' => 604800,
		'display'  => __( 'Once Weekly' ),
	);

	// Add 'monthly' interval (2629743 seconds).
	$schedules['monthly'] = array(
		'interval' => 2629743,
		'display'  => __( 'Once Monthly' ),
	);

	return $schedules;
}
add_filter( 'cron_schedules', 'wpclpro_add_intervals' );

/**
 * Register plugin activation hook.
 *
 * @access public
 * @return void
 */
function wpclpro_on_activation() {
	// Init the classes auto-loader.
	include_once WPCLPRO_PLUGIN_DIR . '/classes/class-wpclpro-installer.php';

	// And run the installer.
	$installer = new Wpclpro_Installer();
	$installer->wpclpro_install();
}
register_activation_hook( __FILE__, 'wpclpro_on_activation' );

/**
 * Register plugin deactivation hook.
 *
 * @access public
 * @return void
 */
function wpclpro_on_deactivation() {
	$installer = new Wpclpro_Installer();
	$installer->wpclpro_deactivate();
}
register_deactivation_hook( __FILE__, 'wpclpro_on_deactivation' );

/**
 * Register plugin uninstall hook.
 *
 * @access public
 * @return void
 */
function wpclpro_on_uninstall() {
	$installer = new Wpclpro_Installer();
	$installer->wpclpro_uninstall();
}
register_deactivation_hook( __FILE__, 'wpclpro_on_uninstall' );

/**
 * Registers the action that counts the items of certain type which can be cleaned by this plugin, via Ajax.
 *
 * @access public
 * @throws Exception Throws an exception if error occured during counting item.
 * @return void
 */
function wpclpro_count_item_callback() {
	// Security check.
	check_ajax_referer( Wpclpro_Loader::ACTION, Wpclpro_Loader::NONCE, true );

	// Initializations.
	$response   = array();
	$controller = new Wpclpro_Controller();

	try {
		if ( ! empty( $_GET ) && isset( $_GET[ Wpclpro_Loader::ITEM ] ) ) {
			// Get parameters.
			$item = sanitize_text_field( wp_unslash( $_GET[ Wpclpro_Loader::ITEM ] ) );

			// Count how many items of this type can be cleaned.
			$count = $controller->wpclpro_count( $item );

			if ( null === $count ) {
				throw new Exception( 'Error counting ' . $controller->wpclpro_get_item_text( $item ) . '.' );
			}

			// Create the "show details" and "clean" links for them.
			$details_link = wp_nonce_url(
				admin_url( 'tools.php?page=wpclpro&tabindex=1&item=' . $item ),
				Wpclpro_Loader::ACTION,
				Wpclpro_Loader::NONCE
			);
			$clean_link   = 'javascript: wpclpro_clean(\'' . $item . '\', true)';

			// And return them as response to the Ajax call.
			$response['count']       = trim( strval( $count ) );
			$response['detailslink'] = html_entity_decode( $details_link );
			$response['cleanlink']   = $clean_link;
		}
	} catch ( Exception $e ) {
		// Log the error, return a message when an error occurs counting items and show 0 as count.
		$controller->wpclpro_log_error( $e->getMessage() );
		$response['count']   = '0';
		$url                 = wp_nonce_url(
			admin_url( 'tools.php?page=wpclpro&tabindex=2' ),
			Wpclpro_Loader::ACTION,
			Wpclpro_Loader::NONCE
		);
		$response['message'] = sprintf(
			wp_kses(
				/* translators: %s: a link to the log tab */
				__(
					'A database error occurred, for more details please check the <a href="%s" title="log">Log tab</a>.',
					'wpclpro'
				),
				array( 'a' => array( 'href' => array() ) )
			),
			esc_url( $url )
		);
		$response['messagetype'] = Wpclpro_Loader::ERROR;
	}

	exit( wp_json_encode( $response ) );
}
add_action( 'wp_ajax_wpclpro_count_item', 'wpclpro_count_item_callback' );

/**
 * Registers the action that shows the details of a cleanable item, via Ajax.
 *
 * @access public
 * @return void
 */
function wpclpro_show_details_callback() {
	// Security check.
	check_ajax_referer( Wpclpro_Loader::ACTION, Wpclpro_Loader::SECURITY, true );

	// Initializations.
	$response   = array();
	$controller = new Wpclpro_Controller();

	try {
		// Get parameters.
		if ( ! empty( $_GET ) && isset( $_GET[ Wpclpro_Loader::ITEM ] ) ) {
			$item = sanitize_text_field( wp_unslash( $_GET[ Wpclpro_Loader::ITEM ] ) );
		} else {
			$item = Wpclpro_Loader::TABLES;
		}

		// Show details of a cleanable item.
		$details = $controller->wpclpro_get_details( $item );
		// For details of orphan shortcodes, don't strip HTML tags, for others, yes.
		if ( Wpclpro_Loader::ORPHAN_SHORTCODES === $item ) {
			$output = $controller->wpclpro_format_details( $details, false );
		} else {
			$output = $controller->wpclpro_format_details( $details, true );
		}

		// And return them as response to the Ajax call.
		$response           = array();
		$response['output'] = $output;
	} catch ( Exception $e ) {
		// Log the exception, return a message when an error occurs showing details of item.
		$controller->wpclpro_log_error( $e->getMessage() );
		$url                 = wp_nonce_url(
			admin_url( 'tools.php?page=wpclpro&tabindex=2' ),
			Wpclpro_Loader::ACTION,
			Wpclpro_Loader::NONCE
		);
		$response['message'] = sprintf(
			wp_kses(
				/* translators: %s: a link to the log tab */
				__(
					'A database error occurred, for more details please check the <a href="%s" title="log">Log tab</a>.',
					'wpclpro'
				),
				array( 'a' => array( 'href' => array() ) )
			),
			esc_url( $url )
		);
		$response['messagetype'] = Wpclpro_Loader::ERROR;
	}
	exit( wp_json_encode( $response ) );
}
add_action( 'wp_ajax_wpclpro_show_details', 'wpclpro_show_details_callback' );

/**
 * Registers the action that creates a database backup, via Ajax.
 *
 * @access public
 * @throws Exception Throws an exception when a database error occured during database backup creation.
 * @return void
 */
function wpclpro_create_backup_callback() {
	// Security check.
	check_ajax_referer( Wpclpro_Loader::ACTION, Wpclpro_Loader::SECURITY, true );

	// Initializations.
	$response   = array();
	$controller = new Wpclpro_Controller();

	try {
		// Create the database backup and build the response.
		$zipname = $controller->wpclpro_action_create_backup();

		if ( ! empty( $zipname ) ) {
			$response['message']     = esc_html__( 'A new database backup was successfully created: ', 'wpclpro' )
			. '<span class="wpclpro-strong wpclpro-orange">' . esc_html( $zipname ) . '</span>&nbsp;'
			. esc_html__( '(you can find it in the table below)', 'wpclpro' );
			$response['messagetype'] = Wpclpro_Loader::NOTICE;
		} else {
			throw new Exception( 'Database exception occuren when creating backup.' );
		}

		$response['backups_exist'] = $controller->wpclpro_backups_exist() ? Wpclpro_Loader::YES : Wpclpro_Loader::NO;

	} catch ( Exception $e ) {
		// Log the exception, return a message when an error occurs creating the backup.
		$controller->wpclpro_log_error( $e->getMessage() );
		$url                 = wp_nonce_url(
			admin_url( 'tools.php?page=wpclpro&tabindex=2' ),
			Wpclpro_Loader::ACTION,
			Wpclpro_Loader::NONCE
		);
		$response['message'] = sprintf(
			wp_kses(
				/* translators: %s: a link to the log tab */
				__(
					'A database error occurred, for more details please check the <a href="%s" title="log">Log tab</a>.',
					'wpclpro'
				),
				array( 'a' => array( 'href' => array() ) )
			),
			esc_url( $url )
		);
		$response['messagetype'] = Wpclpro_Loader::ERROR;
	}

	exit( wp_json_encode( $response ) );
}
add_action( 'wp_ajax_wpclpro_create_backup', 'wpclpro_create_backup_callback' );

/**
 * Registers the action that shows the available database backups, via Ajax.
 *
 * @access public
 * @return void
 */
function wpclpro_show_backups_callback() {
	// Security check.
	check_ajax_referer( Wpclpro_Loader::ACTION, Wpclpro_Loader::SECURITY, true );

	// Initializations.
	$response   = array();
	$backups    = array();
	$controller = new Wpclpro_Controller();

	// Get all the available backups.
	try {
		$backups             = $controller->wpclpro_get_backups();
		$backups             = $controller->wpclpro_format_backups( $backups );
		$response['backups'] = $backups;
	} catch ( Exception $e ) {
		// Log the exception, return a message when an error occurs while showing backups.
		$controller->wpclpro_log_error( $e->getMessage() );
		$url                 = wp_nonce_url(
			admin_url( 'tools.php?page=wpclpro&tabindex=2' ),
			Wpclpro_Loader::ACTION,
			Wpclpro_Loader::NONCE
		);
		$response['message'] = sprintf(
			wp_kses(
				/* translators: %s: a link to the log tab */
				__(
					'A database error occurred, for more details please check the <a href="%s" title="log">Log tab</a>.',
					'wpclpro'
				),
				array( 'a' => array( 'href' => array() ) )
			),
			esc_url( $url )
		);
		$response['messagetype'] = Wpclpro_Loader::ERROR;
	}

	exit( wp_json_encode( $response ) );
}
add_action( 'wp_ajax_wpclpro_show_backups', 'wpclpro_show_backups_callback' );

/**
 * Registers the action that deletes all the database backups, via Ajax.
 *
 * @access public
 * @return void
 */
function wpclpro_delete_all_backups_callback() {
	// Security check.
	check_ajax_referer( Wpclpro_Loader::ACTION, Wpclpro_Loader::SECURITY, true );

	// Initalizations.
	$response   = array();
	$controller = new Wpclpro_Controller();

	// Delete all the backups.
	try {
		$controller = new Wpclpro_Controller();
		$controller->wpclpro_action_delete_all_backups();

		// And return a message when the backups are deleted.
		if ( $controller->wpclpro_backups_exist() ) {
			$response['message']       = esc_html__( 'An error occurred, please try to delete backups again.', 'wpclpro' );
			$response['backups_exist'] = Wpclpro_Loader::YES;
			$response['messagetype']   = Wpclpro_Loader::ERROR;
		} else {
			$response['message']       = esc_html__( 'All backups were successfully deleted.', 'wpclpro' );
			$response['backups_exist'] = Wpclpro_Loader::NO;
			$response['messagetype']   = Wpclpro_Loader::NOTICE;
		}
	} catch ( Exception $e ) {
		// Log the exception, return a message when an error occurs deleting backups.
		$controller->wpclpro_log_error( $e->getMessage() );
		$url                 = wp_nonce_url(
			admin_url( 'tools.php?page=wpclpro&tabindex=2' ),
			Wpclpro_Loader::ACTION,
			Wpclpro_Loader::NONCE
		);
		$response['message'] = sprintf(
			wp_kses(
				/* translators: %s: a link to the log tab */
				__(
					'A database error occurred, for more details please check the <a href="%s" title="log">Log tab</a>.',
					'wpclpro'
				),
				array( 'a' => array( 'href' => array() ) )
			),
			esc_url( $url )
		);
		$response['messagetype'] = Wpclpro_Loader::ERROR;
	}
	exit( wp_json_encode( $response ) );
}
add_action( 'wp_ajax_wpclpro_delete_all_backups', 'wpclpro_delete_all_backups_callback' );

/**
 * Registers the action that optimizes the database tables, via Ajax.
 *
 * @access public
 * @return void
 */
function wpclpro_optimize_tables_callback() {
	// Security check.
	check_ajax_referer( Wpclpro_Loader::ACTION, Wpclpro_Loader::SECURITY, true );

	// Initializations.
	$response   = array();
	$controller = new Wpclpro_Controller();

	// Optimize database tables.
	try {
		$controller = new Wpclpro_Controller();
		$controller->wpclpro_optimize_tables();

	} catch ( Exception $e ) {
		// Log the exception, return a message when an error occurs optimizing database.
		$controller->wpclpro_log_error( $e->getMessage() );
		$url                 = wp_nonce_url(
			admin_url( 'tools.php?page=wpclpro&tabindex=2' ),
			Wpclpro_Loader::ACTION,
			Wpclpro_Loader::NONCE
		);
		$response['message'] = sprintf(
			wp_kses(
				/* translators: %s: a link to the log tab */
				__(
					'A database error occurred, for more details please check the <a href="%s" title="log">Log tab</a>.',
					'wpclpro'
				),
				array( 'a' => array( 'href' => array() ) )
			),
			esc_url( $url )
		);
		$response['messagetype'] = Wpclpro_Loader::ERROR;
	}
	exit( wp_json_encode( $response ) );
}
add_action( 'wp_ajax_wpclpro_optimize_tables', 'wpclpro_optimize_tables_callback' );

/**
 * Registers the action that resets the cleaning counter, via Ajax.
 *
 * @access public
 * @return void
 */
function wpclpro_reset_counter_callback() {
	// Security check.
	check_ajax_referer( Wpclpro_Loader::ACTION, Wpclpro_Loader::SECURITY, true );

	// Initializations.
	$response   = array();
	$controller = new Wpclpro_Controller();

	// Reset the cleaning counter.
	try {
		$controller = new Wpclpro_Controller();
		$controller->wpclpro_reset_counter();

	} catch ( Exception $e ) {
		// Log the exception, return a message when an error occurs resetting the counter.
		$controller->wpclpro_log_error( $e->getMessage() );
		$url                 = wp_nonce_url(
			admin_url( 'tools.php?page=wpclpro&tabindex=2' ),
			Wpclpro_Loader::ACTION,
			Wpclpro_Loader::NONCE
		);
		$response['message'] = sprintf(
			wp_kses(
				/* translators: %s: a link to the log tab */
				__(
					'A database error occurred, for more details please check the <a href="%s" title="log">Log tab</a>.',
					'wpclpro'
				),
				array( 'a' => array( 'href' => array() ) )
			),
			esc_url( $url )
		);
		$response['messagetype'] = Wpclpro_Loader::ERROR;
	}
	exit( wp_json_encode( $response ) );
}
add_action( 'wp_ajax_wpclpro_reset_counter', 'wpclpro_reset_counter_callback' );

/**
 * Registers the action that deletes a given database backup, via Ajax.
 *
 * @access public
 * @return void
 */
function wpclpro_delete_backup_callback() {
	// Security check.
	check_ajax_referer( Wpclpro_Loader::ACTION, Wpclpro_Loader::SECURITY, true );

	// Initializations.
	$response   = array();
	$controller = new Wpclpro_Controller();

	// Delete a given backup.
	try {
		if ( ! empty( $_GET ) && isset( $_GET[ Wpclpro_Loader::BACKUP_NAME ] ) ) {
			$backup_name = sanitize_text_field( wp_unslash( $_GET[ Wpclpro_Loader::BACKUP_NAME ] ) );

			$deleted = $controller->wpclpro_action_delete_backup( $backup_name );

			// And return a message when the given backup was deleted.
			if ( $deleted ) {
				$response['message']     = esc_html__( 'Successfully deleted the backup: ', 'wpclpro' )
				. '<strong>' . esc_attr( $backup_name ) . '.</strong>';
				$response['messagetype'] = Wpclpro_Loader::NOTICE;
			} else {
				$response['message']     = esc_html__( 'An error occured while trying to delete the backup: ', 'wpclpro' )
				. '<strong>' . esc_attr( $backup_name ) . '. Please try again.</strong>';
				$response['messagetype'] = Wpclpro_Loader::ERROR;
			}

			$response['backups_exist'] = $controller->wpclpro_backups_exist() ? Wpclpro_Loader::YES : Wpclpro_Loader::NO;
		}
	} catch ( Exception $e ) {
		// Log the exception, return a message when an error occurs deleting the backup.
		$controller->wpclpro_log_error( $e->getMessage() );
		$url                 = wp_nonce_url(
			admin_url( 'tools.php?page=wpclpro&tabindex=2' ),
			Wpclpro_Loader::ACTION,
			Wpclpro_Loader::NONCE
		);
		$response['message'] = sprintf(
			wp_kses(
				/* translators: %s: a link to the log tab */
				__(
					'A database error occurred, for more details please check the <a href="%s" title="log">Log tab</a>.',
					'wpclpro'
				),
				array( 'a' => array( 'href' => array() ) )
			),
			esc_url( $url )
		);
		$response['messagetype'] = Wpclpro_Loader::ERROR;
	}

	exit( wp_json_encode( $response ) );
}
add_action( 'wp_ajax_wpclpro_delete_backup', 'wpclpro_delete_backup_callback' );

/**
 * Registers the action that shows the available logs, via Ajax.
 *
 * @access public
 * @return void
 */
function wpclpro_show_logs_callback() {
	// Security check.
	check_ajax_referer( Wpclpro_Loader::ACTION, Wpclpro_Loader::SECURITY, true );

	// Initializations.
	$response   = array();
	$controller = new Wpclpro_Controller();

	// Get all the available logs.
	try {
		$logs             = $controller->wpclpro_format_logs( $controller->wpclpro_get_logs() );
		$response['logs'] = $logs;
	} catch ( Exception $e ) {
		// Log the exception, return a message when an error occurs showing logs.
		$controller->wpclpro_log_error( $e->getMessage() );
		$url                 = wp_nonce_url(
			admin_url( 'tools.php?page=wpclpro&tabindex=2' ),
			Wpclpro_Loader::ACTION,
			Wpclpro_Loader::NONCE
		);
		$response['message'] = sprintf(
			wp_kses(
				/* translators: %s: a link to the log tab */
				__(
					'A database error occurred, for more details please check the <a href="%s" title="log">Log tab</a>.',
					'wpclpro'
				),
				array( 'a' => array( 'href' => array() ) )
			),
			esc_url( $url )
		);
		$response['messagetype'] = Wpclpro_Loader::ERROR;
	}

	exit( wp_json_encode( $response ) );
}
add_action( 'wp_ajax_wpclpro_show_logs', 'wpclpro_show_logs_callback' );

/**
 * Registers the action that deletes all the logs, via Ajax.
 *
 * @access public
 * @return void
 */
function wpclpro_delete_all_logs_callback() {
	// Security check.
	check_ajax_referer( Wpclpro_Loader::ACTION, Wpclpro_Loader::SECURITY, true );

	// Initializations.
	$response   = array();
	$controller = new Wpclpro_Controller();

	// Delete all the logs.
	try {
		$controller->wpclpro_action_delete_all_logs();

		// And return a message when the logs are deleted.
		if ( $controller->wpclpro_logs_exist() ) {
			$response['message']     = esc_html__( 'An error occurred, please try to delete logs again.', 'wpclpro' );
			$response['logs_exist']  = Wpclpro_Loader::YES;
			$response['messagetype'] = Wpclpro_Loader::ERROR;
		} else {
			$response['message']     = esc_html__( 'All logs were successfully deleted.', 'wpclpro' );
			$response['logs_exist']  = Wpclpro_Loader::NO;
			$response['messagetype'] = Wpclpro_Loader::NOTICE;
		}
	} catch ( Exception $e ) {
		// Log the exception, return a message when an error occurs deleting the logs.
		$controller->wpclpro_log_error( $e->getMessage() );
		$url                 = wp_nonce_url(
			admin_url( 'tools.php?page=wpclpro&tabindex=2' ),
			Wpclpro_Loader::ACTION,
			Wpclpro_Loader::NONCE
		);
		$response['message'] = sprintf(
			wp_kses(
				/* translators: %s: a link to the log tab */
				__(
					'A database error occurred, for more details please check the <a href="%s" title="log">Log tab</a>.',
					'wpclpro'
				),
				array( 'a' => array( 'href' => array() ) )
			),
			esc_url( $url )
		);
		$response['messagetype'] = Wpclpro_Loader::ERROR;
	}

	exit( wp_json_encode( $response ) );
}
add_action( 'wp_ajax_wpclpro_delete_all_logs', 'wpclpro_delete_all_logs_callback' );

/**
 * Registers the action that cleans the received item of certain type, via Ajax.
 *
 * @access public
 * @return void
 */
function wpclpro_clean_item_callback() {
	// Security check.
	check_ajax_referer( Wpclpro_Loader::ACTION, Wpclpro_Loader::SECURITY, true );

	// Initializations.
	$response   = array();
	$controller = new Wpclpro_Controller();

	// Process request and clean.
	try {
		if ( ! empty( $_GET ) && isset( $_GET[ Wpclpro_Loader::ITEM ] ) ) {
			$item = sanitize_text_field( wp_unslash( $_GET[ Wpclpro_Loader::ITEM ] ) );

			// Clean the cleanable item from the database.
			$controller->wpclpro_action_clean( $item );

			// Return a message when the item was cleaned.
			$response['message']     = esc_html__( 'Cleaning performed successfully, total space cleaned: ', 'wpclpro' )
										. $controller->wpclpro_get_cleaned_space();
			$response['messagetype'] = Wpclpro_Loader::NOTICE;
		}
	} catch ( Exception $e ) {
		// Log the exception, return a message when an error occurs cleaning the item.
		$controller->wpclpro_log_error( $e->getMessage() );
		$url                 = wp_nonce_url(
			admin_url( 'tools.php?page=wpclpro&tabindex=2' ),
			Wpclpro_Loader::ACTION,
			Wpclpro_Loader::NONCE
		);
		$response['message'] = sprintf(
			wp_kses(
				/* translators: %s: a link to the log tab */
				__(
					'A database error occurred, for more details please check the <a href="%s" title="log">Log tab</a>.',
					'wpclpro'
				),
				array( 'a' => array( 'href' => array() ) )
			),
			esc_url( $url )
		);
		$response['messagetype'] = Wpclpro_Loader::ERROR;
	}

	exit( wp_json_encode( $response ) );
}
add_action( 'wp_ajax_wpclpro_clean_item', 'wpclpro_clean_item_callback' );

/**
 * Registers the action that schedules the selected items for cleaning, via Ajax.
 *
 * @access public
 * @return void
 */
function wpclpro_schedule_items_callback() {
	// Security check.
	check_ajax_referer( Wpclpro_Loader::ACTION, Wpclpro_Loader::SECURITY, true );

	// Initializations.
	$response   = array();
	$controller = new Wpclpro_Controller();

	// Process parameters and the schedule action.
	try {
		if ( ! empty( $_GET ) && isset( $_GET[ Wpclpro_Loader::ITEMS ] ) && isset( $_GET[ Wpclpro_Loader::FREQUENCY ] ) ) {
			$items     = filter_input_array( INPUT_GET, FILTER_DEFAULT )[ Wpclpro_Loader::ITEMS ];
			$frequency = sanitize_text_field( wp_unslash( $_GET[ Wpclpro_Loader::FREQUENCY ] ) );

			// Schedule the selected items for cleaning.
			$scheduled = $controller->wpclpro_action_schedule( $items, $frequency );

			// And return a message when the items are scheduled.
			if ( $scheduled ) {
				$response['message']     = esc_html__( 'Done. The cleaning has been scheduled successfully.', 'wpclpro' );
				$response['messagetype'] = Wpclpro_Loader::NOTICE;
			} else {
				$response['message']     = esc_html__( 'Error while scheduling the cleaning. Please try again.', 'wpclpro' );
				$response['messagetype'] = Wpclpro_Loader::ERROR;
			}
		}
	} catch ( Exception $e ) {
		// Log the exception, return a message when an error occurs scheduling items.
		$controller->wpclpro_log_error( $e->getMessage() );
		$url                 = wp_nonce_url(
			admin_url( 'tools.php?page=wpclpro&tabindex=2' ),
			Wpclpro_Loader::ACTION,
			Wpclpro_Loader::NONCE
		);
		$response['message'] = sprintf(
			wp_kses(
				/* translators: %s: a link to the log tab */
				__(
					'A database error occurred, for more details please check the <a href="%s" title="log">Log tab</a>.',
					'wpclpro'
				),
				array( 'a' => array( 'href' => array() ) )
			),
			esc_url( $url )
		);
		$response['messagetype'] = Wpclpro_Loader::ERROR;
	}
	exit( wp_json_encode( $response ) );
}
add_action( 'wp_ajax_wpclpro_schedule_items', 'wpclpro_schedule_items_callback' );

/**
 * Registers the action that gets a scheduled/not scheduled label for a certain item, via Ajax.
 *
 * @access public
 * @return void
 */
function wpclpro_get_scheduled_label_callback() {
	// Security check.
	check_ajax_referer( Wpclpro_Loader::ACTION, Wpclpro_Loader::SECURITY, true );

	// Initializations.
	$response   = array();
	$controller = new Wpclpro_Controller();

	// Process request.
	try {
		if ( ! empty( $_GET ) && isset( $_GET[ Wpclpro_Loader::ITEM ] ) ) {
			$item  = sanitize_text_field( wp_unslash( $_GET[ Wpclpro_Loader::ITEM ] ) );
			$items = get_option( 'wpclpro_clean_items', array() );

			// Get a scheduled/not scheduled label for a certain item.
			$output = $controller->wpclpro_get_scheduled_label( $item, $items, false );

			// And build the response.
			$response['output'] = $output;
		}
	} catch ( Exception $e ) {
		// Log the exception, return a message when an error occurs getting the scheduled label for an item.
		$controller->wpclpro_log_error( $e->getMessage() );
		$url                 = wp_nonce_url(
			admin_url( 'tools.php?page=wpclpro&tabindex=2' ),
			Wpclpro_Loader::ACTION,
			Wpclpro_Loader::NONCE
		);
		$response['message'] = sprintf(
			wp_kses(
				/* translators: %s: a link to the log tab */
				__(
					'A database error occurred, for more details please check the <a href="%s" title="log">Log tab</a>.',
					'wpclpro'
				),
				array( 'a' => array( 'href' => array() ) )
			),
			esc_url( $url )
		);
		$response['messagetype'] = Wpclpro_Loader::ERROR;
	}

	exit( wp_json_encode( $response ) );
}
add_action( 'wp_ajax_wpclpro_get_scheduled_label', 'wpclpro_get_scheduled_label_callback' );

/**
 * Registers the action that unschedules the scheduled cleaning, via Ajax.
 *
 * @access public
 * @return void
 */
function wpclpro_unschedule_callback() {
	// Security check.
	check_ajax_referer( Wpclpro_Loader::ACTION, Wpclpro_Loader::SECURITY, true );

	// Initializations.
	$response   = array();
	$controller = new Wpclpro_Controller();

	// Unschedule the scheduled cleaning.
	try {
		$unscheduled = $controller->wpclpro_action_unschedule();

		// And return a message when the cleaning of items are unscheduled.
		if ( false === $unscheduled ) {
			$response['message']     = esc_html__( 'Error while unscheduling the cleaning. Please try again.', 'wpclpro' );
			$response['messagetype'] = Wpclpro_Loader::ERROR;
		} else {
			$response['message']     = esc_html__( 'Done. The bulk cleaning of multiple has been unscheduled successfully.', 'wpclpro' );
			$response['messagetype'] = Wpclpro_Loader::NOTICE;
		}
	} catch ( Exception $e ) {
		// Log the exception and return a message when an error occurs while unscheduling cleaning of items.
		$controller->wpclpro_log_error( $e->getMessage() );
		$url                 = wp_nonce_url(
			admin_url( 'tools.php?page=wpclpro&tabindex=2' ),
			Wpclpro_Loader::ACTION,
			Wpclpro_Loader::NONCE
		);
		$response['message'] = sprintf(
			wp_kses(
				/* translators: %s: a link to the log tab */
				__(
					'A database error occurred, for more details please check the <a href="%s" title="log">Log tab</a>.',
					'wpclpro'
				),
				array( 'a' => array( 'href' => array() ) )
			),
			esc_url( $url )
		);
		$response['messagetype'] = Wpclpro_Loader::ERROR;
	}

	exit( wp_json_encode( $response ) );
}
add_action( 'wp_ajax_wpclpro_unschedule', 'wpclpro_unschedule_callback' );
