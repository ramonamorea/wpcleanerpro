<?php
/**
 * Holds the logic for handling plugin logs.
 *
 * @package    wp-cleaner-pro
 * @author     hevada <support@hevada.com>
 * @copyright  2017-2030 hevada <support@hevada.com>
 * @link       http://codecanyon.net/user/hevada
 * @version    6.3
 * @since      1.0
 */

/**
 * Class that contains the logic for handling plugin logs.
 */
class Wpclpro_Logger_DAO {

	/**
	 * Counts the plugin's logs.
	 *
	 * @access public
	 * @return int $count The number of all entries in the plugin's log table.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_count_logs() {
		global $wpdb;
		$logs_table = $wpdb->prefix . Wpclpro_Loader::LOGS_TABLE_NAME;

		// @codingStandardsIgnoreStart -- ignore interpolated variable rule.
		$count = $wpdb->get_var( 'SELECT COUNT(log_id) FROM ' . $logs_table );
		// @codingStandardsIgnoreEnd
		return $count;
	}

	/**
	 * Gets all the entries from plugin's log table.
	 *
	 * @access public
	 * @return array $logs The available plugin's log entries.
	 * (entries are limited to 500 entries for performance reasons)
	 * @global wpdb $wpdb
	 */
	public function wpclpro_get_logs() {
		// Prepare to get log entries.
		global $wpdb;
		$logs  = array();
		$table = $wpdb->prefix . Wpclpro_Loader::LOGS_TABLE_NAME;

		// phpcs:disable -- ignore direct database access rule.
		$logs = $wpdb->get_results( 'SELECT * FROM ' . $table . ' ORDER BY log_id DESC LIMIT 500', ARRAY_A );
		// phpcs:enable

		return $logs;
	}

	/**
	 * Deletes all log entries from the plugin's log table.
	 *
	 * @access public
	 * @return boolean True if the log entries were succesfully deleted, false otherwise.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_delete_all_logs() {

		// Prepare to delete log entries.
		global $wpdb;
		$table = $wpdb->prefix . Wpclpro_Loader::LOGS_TABLE_NAME;

		// And delete them.
		// phpcs:disable -- ignore direct database access rule.
		$deleted = $wpdb->query( 'DELETE FROM ' . $table );
		// phpcs:enable

		return $deleted;
	}
}
