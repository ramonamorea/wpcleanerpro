<?php
/**
 * Holds the logic for database backups.
 *
 * @package    wp-cleaner-pro
 * @author     hevada <support@hevada.com>
 * @copyright  2017-2030 hevada <support@hevada.com>
 * @link       http://codecanyon.net/user/hevada
 * @version    6.3
 * @since      1.0
 */

/**
 * Class that contains the logic to create, list, delete database backups.
 */
class Wpclpro_Backupper_DAO extends Wpclpro_DAO {

	/**
	 * Stores the location of the folder where to keep the backups.
	 *
	 * @access private
	 * @var string
	 */
	private $backups_dir;

	/**
	 * Stores the url to where backups are kept.
	 *
	 * @access private
	 * @var string
	 */
	private $backups_url;

	/**
	 * Constructor.
	 *
	 * @access public
	 */
	public function __construct() {
		// Get the upload directory.
		$wp_upload_dir = wp_upload_dir();

		// Initiate the backups dir and url.
		$this->backups_url = trailingslashit( $wp_upload_dir['baseurl'] ) . trailingslashit( Wpclpro_Loader::FOLDER );
		$this->backups_dir = trailingslashit( $wp_upload_dir['basedir'] ) . trailingslashit( Wpclpro_Loader::FOLDER );

		// Initialize file system and protect the backups directory.
		parent::wpclpro_prepare_filesystem();
		$this->wpclpro_protect_backups_dir();
	}

	/**
	 * Creates a database backup.
	 *
	 * After it creates the backup, it also saves it in the filesystem.
	 * After saving it, it also deletes automatically the old backups from the filesystem.
	 * (only 10 backups are kept in the filesystem).
	 *
	 * @access public
	 * @return string Returns the name of the backup created.
	 * @global $wpdb The WordPress database.
	 */
	public function wpclpro_create_db_backup() {
		global $wpdb;
		$filesystem = $this->wpclpro_prepare_filesystem();

		// Raise temporarily the time limits, because if database is big, the processing takes longer.
		Wpclpro_Utilities::wpclpro_raise_time_limits();

		// Continue proccess even if user aborts, for database consistency.
		ignore_user_abort( true );

		// If the backup directory does not exist, create it.
		if ( ! $filesystem->is_dir( $this->backups_dir ) ) {
			$filesystem->mkdir( $this->backups_dir );
		}

		// Build the .sql file name and path.
		$date_gmt = get_date_from_gmt( gmdate( 'Y-m-d H:i:s', time() ), 'd-m-Y_H-i-s' );
		$filename = 'db-backup_' . $date_gmt . '.sql';
		$filepath = $this->backups_dir . $filename;

		// Define the end of line for SQL statements.
		$eol = "\r\n";

		// Numeric and binary array types.
		$numeric = array_flip( array( 'TINYINT', 'SMALLINT', 'MEDIUMINT', 'INT', 'BIGINT', 'FLOAT', 'DOUBLE', 'DECIMAL' ) );
		$binary  = array_flip( array( 'BINARY', 'VARBINARY', 'TINYBLOB', 'MEDIUMBLOB', 'BLOB', 'LONGBLOB' ) );

		// Save the .sql file to filesystem. Generate and write the header for the database dump file.
		$output = $this->wpclpro_get_dump_header();

		// Get all tables of the database.
		// phpcs:disable -- ignore direct database access rule.
		$tables = $wpdb->get_col( 'SHOW FULL TABLES FROM ' . $wpdb->dbname . ' WHERE table_type = \'BASE TABLE\';', 0 );
		// phpcs:enable.

		// Export data for each table.
		foreach ( $tables as $table ) {

			// @codingStandardsIgnoreStart -- ignore interpolated variable rule.
			$rows = $wpdb->get_results( "SELECT * FROM {$table}", ARRAY_N );

			// How many rows the table has?
			$nr_rows = count( $rows );

			// Create the drop statement.
			$output .= "DROP TABLE IF EXISTS `$table`;$eol";

			// Get the columns names of current table.
			$columns = $wpdb->get_col( $wpdb->prepare( 'SELECT column_name
										FROM information_schema.columns
										WHERE table_schema=%s AND table_name=%s', $wpdb->dbname, $table ));
			$column_names = implode( '`, `', $columns );

			// Get the columns types of current table.
			$types = $wpdb->get_col( $wpdb->prepare( 'SELECT data_type
										FROM information_schema.columns
										WHERE table_schema=%s AND table_name=%s', $wpdb->dbname, $table ));

			// Get the statement that creates the table.
			$statemt = $wpdb->get_row( 'SHOW CREATE TABLE ' . $table, ARRAY_N );
			// @codingStandardsIgnoreEnd.
			if ( ! is_null( $statemt ) ) {
				$output .= "$eol" . $statemt[1] . ";$eol$eol";
			}

			// Create the INSERT INTO statement only if there are rows to insert.
			if ( $rows ) {
				$output .= $eol . 'INSERT INTO `' . $table . '` (`' . $column_names . '`) VALUES ' . $eol;
				for ( $i = 0; $i < $nr_rows; $i++ ) {

					// Start building the values to insert.
					$output .= '(';

					$row   = $rows[ $i ];
					$count = count( $rows[0] );

					for ( $j = 0; $j < $count; $j++ ) {

						$type = strtoupper( $types[ $j ] );

						if ( ! isset( $row[ $j ] ) || is_null( $row[ $j ] ) ) { // empty cell.
							$output .= 'NULL';
						} elseif ( isset( $numeric[ $type ] ) ) { // numeric cell.
							$output .= $row[ $j ];
						} elseif ( isset( $binary[ $type ] ) ) { // binary cell.
							if ( empty( $row[ $j ] ) && '0' !== $row[ $j ] ) {
								$output .= '\'\'';
							} else {
								$output .= '0x' . bin2hex( $row[ $j ] );
							}
						} else { // string cell or any other type.
							$output .= "'" . $wpdb->_real_escape( $row[ $j ] ) . "'";
						}
						if ( $j < ( count( $rows[0] ) - 1 ) ) {
							$output .= ', ';
						}
						$count = count( $rows[0] );
					}

					$output .= ')';
					if ( $i < $nr_rows - 1 ) {
						$output .= ',' . $eol;
					}
				}
				$output .= ";$eol$eol";

				// End of creating the INSERT INTO statement.
			}
		}

		// Generate the footer and save the backup file.
		$output .= $this->wpclpro_get_dump_footer();
		$filesystem->put_contents( $filepath, $output );

		// Now create a zip file adding to it the .sql file, in the backups directory.
		$zip     = new ZipArchive();
		$zipname = 'db-backup_' . $date_gmt . '.zip';
		$zippath = $this->backups_dir . $zipname;

		if ( true === $zip->open( $zippath, ZipArchive::CREATE ) ) {
			$zip->addFile( $filepath, $filename );
			$zip->close();
		}

		// Now delete the .sql file generated, because it's not needed any longer, we have the .zip file.
		$filesystem->delete( $filepath );

		// Also delete the old backups (only 10 backups are kept in filesystem).
		$this->wpclpro_delete_old_backups();

		// Restore the time limits to their original settings.
		Wpclpro_Utilities::wpclpro_restore_time_limits();

		return $filename;
	}

	/**
	 * Builds the header for the database dump file.
	 *
	 * @access private
	 * @return string Returns the header for the database dump file.
	 * @global $wpdb The WordPress database.
	 */
	private function wpclpro_get_dump_header() {
		$eol = "\r\n";
		global $wpdb;
		$output = '';

		// Generate the header.
		$output .= '-- SQL Dump generated by WP Cleaner Pro plugin ' . $eol;
		$output .= '-- Host: ' . $wpdb->dbhost . $eol;
		$output .= '-- Generation time: ' . Wpclpro_Utilities::wpclpro_format_date( time() ) . $eol;
		$output .= '-- Database server: ' . Wpclpro_Utilities::wpclpro_get_mysql_version() . $eol;
		if ( isset( $_SERVER['SERVER_SOFTWARE'] ) ) {
			$output .= '-- Server software: ' . sanitize_text_field( wp_unslash( $_SERVER['SERVER_SOFTWARE'] ) ) . $eol;
		}
		$output .= '-- Database name: ' . $wpdb->dbname . $eol . $eol;
		$output .= '/*!40101 SET NAMES ' . $wpdb->charset . " */;$eol";
		$output .= "/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;$eol";
		$output .= "/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;$eol";
		$output .= "/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;$eol";
		$output .= "/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;$eol";
		$output .= "/*!40103 SET TIME_ZONE='+00:00' */;$eol";
		$output .= "/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;$eol";
		$output .= "/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;$eol";
		$output .= "/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;$eol";
		$output .= "/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;$eol$eol";

		return $output;
	}

	/**
	 * Builds the footer for the database dump file.
	 *
	 * @access private
	 * @return string Returns the footer for the database dump file.
	 */
	private function wpclpro_get_dump_footer() {
		$eol    = "\r\n";
		$output = '';

		// Generate the footer.
		$output .= "$eol$eol";
		$output .= "/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;$eol";
		$output .= "/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;$eol";
		$output .= "/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;$eol";
		$output .= "/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;$eol";
		$output .= "/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;$eol";
		$output .= "/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;$eol";
		$output .= "/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;$eol$eol";

		return $output;
	}

	/**
	 * Gets the list of all backup files from the filesystem.
	 *
	 * @access public
	 * @return array Returns the list of all backups available.
	 */
	public function wpclpro_get_backups() {
		$filesystem = $this->wpclpro_prepare_filesystem();

		$backups = array();

		// Get the list of backup files from the filesystem.
		$files = $filesystem->dirlist( $this->backups_dir );

		// If no backups, return the list empty.
		if ( false === $files ) {
			return $backups;
		}

		// Build the list of backups, setting for each backup item the attributes.
		foreach ( $files as $file ) {

			$format = substr( $file['name'], - 4 );

			if ( '.zip' === $format ) {
				$backups[ $file['name'] ] = array(
					'name'   => $file['name'],
					'size'   => $file['size'],
					'url'    => $this->backups_url . $file['name'] . '?key=' . get_option( 'wpclpro_db_key' ),
					'date'   => $file['lastmodunix'],
					'format' => $format,
				);
			}
		}

		// Return the list of all backups available.
		array_multisort( $backups, SORT_ASC, $backups );

		return $backups;
	}

	/**
	 * Counts from the filesystem all backup files generated by the plugin.
	 *
	 * @access public
	 * @return array Returns the number of all backup files generated by the plugin from the filesystem.
	 */
	public function wpclpro_count_backups() {
		// Get the list of backup files from the filesystem.
		$backups = $this->wpclpro_get_backups();

		// If no backups, return zero.
		if ( empty( $backups ) ) {
			return 0;
		}

		// Else return the number of backups.
		return count( $backups );
	}

	/**
	 * Deletes a backup given by its filename.
	 *
	 * @access public
	 * @param string $filename The file name of the backup to delete.
	 * @return boolean Returns true if the backup is deleted successfully, false otherwise.
	 */
	public function wpclpro_delete_backup( $filename ) {
		$filesystem = $this->wpclpro_prepare_filesystem();

		return $filesystem->delete( $this->backups_dir . $filename );
	}

	/**
	 * Deletes old backups, leaving only 10 backups in filesystem.
	 *
	 * @access private
	 * @return boolean Returns true if the delete process finished successfully, false otherwise.
	 */
	private function wpclpro_delete_old_backups() {

		// Get all backups available.
		$backups = $this->wpclpro_get_backups();

		// And count them.
		$nr_backups = count( $backups );

		// How many backups should remain.
		$should_remain = 10;

		// If more than 10 backups, delete the old ones, only leave 10 backups all the time.
		if ( $nr_backups > $should_remain ) {

			$nr_to_delete = $nr_backups - $should_remain;

			// Extract the backups to delete.
			$backups_to_delete = array_slice( $backups, 0, $nr_to_delete, false );

			foreach ( $backups_to_delete as $backup ) {
				$this->wpclpro_delete_backup( $backup['name'] );
			}
		}

		// At this point, delete proccess was finished.
		return true;
	}

	/**
	 * Deletes all backups available in the filesystem.
	 *
	 * @access public
	 * @return bool Returns true if delete proccess finished, false otherwise.
	 */
	public function wpclpro_delete_all_backups() {
		$filesystem = $this->wpclpro_prepare_filesystem();

		// Get all backups available and delete them, one by one.
		$backups = $this->wpclpro_get_backups();

		// If no backups, return zero.
		if ( empty( $backups ) ) {
			return true;
		}

		foreach ( $backups as $backup ) {
			$this->wpclpro_delete_backup( $backup['name'] );
		}

		// Also delete the index.html file inside the backups directory.
		$index_file = $this->backups_dir . 'index.html';
		if ( $filesystem->exists( $index_file ) ) {
			$filesystem->delete( $index_file );
		}

		// Also delete .htaccess file if on Apache server.
		global $is_apache;
		$htaccess = $this->backups_dir . '.htaccess';

		if ( $is_apache && $filesystem->exists( $htaccess ) ) {
			$filesystem->delete( $htaccess );
		}

		// Also delete the backups dir.
		$filesystem->delete( $this->backups_dir );

		// Delete proccess finished successfully.
		return true;
	}

	/**
	 * Adds listing & downloading protection to the plugin's backups folder.
	 *
	 * @access private
	 * @return void
	 */
	private function wpclpro_protect_backups_dir() {
		$filesystem = $this->wpclpro_prepare_filesystem();

		// Protect against directory listing by including a index.html file in the backups directory.
		$index_file = $this->backups_dir . 'index.html';
		if ( $filesystem->exists( $this->backups_dir ) && ! $filesystem->exists( $index_file ) ) {
			$filesystem->put_contents( $index_file, '' );
		}

		// Generate a unique, random key, used to download later the database backups and save it in database.
		$key = md5( wp_json_encode( time() ) );
		update_option( 'wpclpro_db_key', $key, false );

		// Also protect the backups directory with a .htaccess file on Apache servers.
		global $is_apache;

		$htaccess = $this->backups_dir . '.htaccess';
		if ( $is_apache && $filesystem->exists( $htaccess ) ) {
			$filesystem->delete( $htaccess );
		}

		if ( $is_apache && function_exists( 'insert_with_markers' ) ) {
			$code[] = '# Protect against direct backups downloads';
			$code[] = '';
			$code[] = '<IfModule mod_rewrite.c>';
			$code[] = 'RewriteEngine On';
			$code[] = 'RewriteCond %{QUERY_STRING} !key=' . get_option( 'wpclpro_db_key' );
			$code[] = 'RewriteRule (.*) - [F]';
			$code[] = '</IfModule>';
			$code[] = '';
			insert_with_markers( $htaccess, __( 'WP Cleaner Pro', 'wpclpro' ), $code );
		}
	}
}
