<?php
/**
 * Holds the logic to view the details of items that can be cleaned.
 *
 * @package wp-cleaner-pro
 * @author hevada <support@hevada.com>
 * @copyright 2017-2030 hevada <support@hevada.com>
 * @link http://codecanyon.net/user/hevada
 * @version 6.3
 * @since 1.0
 */

/**
 * Class that contains the logic to view the details of items that can be cleaned.
 */
class Wpclpro_Details_DAO extends Wpclpro_DAO {

	/**
	 * Stores the class logger.
	 *
	 * @access private
	 * @var Logger
	 */
	private $logger;

	/**
	 * Constructor
	 */
	public function __construct() {
		Logger::configure( WPCLPRO_PLUGIN_DIR . 'log4php/config.php' );
		$this->logger = Logger::getLogger( __CLASS__ );

		// Initialize the WordPress file system.
		parent::wpclpro_prepare_filesystem();
	}

	/**
	 * Gets details for trash comments.
	 *
	 * @access public
	 * @return array A bidemensional array of details for trash comments.
	 * @throws Exception Throws an exception when a database occurred during getting details of item.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_get_details_trash_comments() {
		global $wpdb;

		// Get columns names.
		// phpcs:disable -- ignore direct database access rule.
		$cols = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT column_name
				FROM information_schema.columns
				WHERE table_schema=%s AND table_name=%s',
				$wpdb->dbname,
				$wpdb->comments
			),
			ARRAY_A
		);

		// Get rows, limit to 500 for performance.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT *
				FROM $wpdb->comments
				WHERE comment_approved = %s
				LIMIT 500",
				'trash'
			),
			ARRAY_A
		);
		// phpcs:enable
		if ( empty( $cols ) || empty( $rows ) ) {
			throw new Exception( 'Database error during getting details for trash comments.' );
		}

		// Build the array to return.
		$resulted[0] = $cols;
		$resulted[1] = $rows;
		return $resulted;
	}

	/**
	 * Gets details for spam comments.
	 *
	 * @access public
	 * @return array A bidemensional array of details for spam comments.
	 * @throws Exception Throws an exception when a database occurred during getting details of item.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_get_details_spam_comments() {
		global $wpdb;

		// Get columns names.
		// phpcs:disable -- ignore direct database access rule.
		$cols = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT column_name
				FROM information_schema.columns
				WHERE table_schema=%s AND table_name=%s',
				$wpdb->dbname,
				$wpdb->comments
			),
			ARRAY_A
		);

		// Get rows, limit to 500 for performance.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT *
				FROM $wpdb->comments
				WHERE comment_approved = %s
				LIMIT 500",
				'spam'
			),
			ARRAY_A
		);
		// phpcs:enable
		if ( empty( $cols ) || empty( $rows ) ) {
			throw new Exception( 'Database error during getting details for spam comments.' );
		}

		// Build the array to return.
		$resulted[0] = $cols;
		$resulted[1] = $rows;
		return $resulted;
	}

	/**
	 * Gets details for comments waiting for moderation.
	 *
	 * @access public
	 * @return array A bidemensional array of details for comments waiting for moderation.
	 * @throws Exception Throws an exception when a database occurred during getting details of item.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_get_details_wmoderation() {
		global $wpdb;

		// Get columns names.
		// phpcs:disable -- ignore direct database access rule.
		$cols = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT column_name
				FROM information_schema.columns
				WHERE table_schema=%s AND table_name=%s',
				$wpdb->dbname,
				$wpdb->comments
			),
			ARRAY_A
		);

		// Get rows, limit to 500 for performance.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT *
				FROM $wpdb->comments
				WHERE comment_approved = %s
				LIMIT 500",
				'0'
			),
			ARRAY_A
		);
		// phpcs:enable
		if ( empty( $cols ) || empty( $rows ) ) {
			throw new Exception( 'Database error during getting details for waiting for moderation comments.' );
		}

		// Build the array to return.
		$resulted[0] = $cols;
		$resulted[1] = $rows;
		return $resulted;
	}

	/**
	 * Gets details for orphan comment meta.
	 *
	 * @access public
	 * @return array A bidemensional array of details for orphan comment meta.
	 * @throws Exception Throws an exception when a database occurred during getting details of item.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_get_details_orphan_comment_meta() {
		global $wpdb;

		// Get columns names.
		// phpcs:disable -- ignore direct database access rule.
		$cols = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT column_name
				FROM information_schema.columns
				WHERE table_schema=%s AND table_name=%s',
				$wpdb->dbname,
				$wpdb->commentmeta
			),
			ARRAY_A
		);

		// Get rows, limit to 500 for performance.
		$rows = $wpdb->get_results(
			"SELECT *
			FROM $wpdb->commentmeta
			WHERE comment_id NOT IN
			(SELECT comment_id FROM $wpdb->comments)
			LIMIT 500",
			ARRAY_A
		);
		// phpcs:enable
		if ( empty( $cols ) || empty( $rows ) ) {
			throw new Exception( 'Database error during getting details for orphan comment meta.' );
		}

		// Build the array to return.
		$resulted[0] = $cols;
		$resulted[1] = $rows;
		return $resulted;
	}

	/**
	 * Gets details for duplicated comment meta.
	 *
	 * @access public
	 * @return array A bidemensional array of details for duplicated comment meta.
	 * @throws Exception Throws an exception when a database occurred during getting details of item.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_get_details_duplicated_comment_meta() {
		global $wpdb;

		// Get columns names.
		// phpcs:disable -- ignore direct database access rule.
		$cols = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT column_name
				FROM information_schema.columns
				WHERE table_schema=%s AND table_name=%s',
				$wpdb->dbname,
				$wpdb->commentmeta
			),
			ARRAY_A
		);

		// Get rows, limit to 500 for performance.
		$rows = $wpdb->get_results(
			"SELECT DISTINCT *
			FROM $wpdb->commentmeta as t1
			WHERE EXISTS (
			SELECT comment_id, meta_key, meta_value
			FROM $wpdb->commentmeta as t2
			WHERE t1.meta_id <> t2.meta_id
			AND t1.comment_id = t2.comment_id
			AND t1.meta_key = t2.meta_key
			AND t1.meta_value = t2.meta_value )
			ORDER BY t1.comment_id, t1.meta_key, t1.meta_value
			LIMIT 500",
			ARRAY_A
		);
		// phpcs:enable
		if ( empty( $cols ) || empty( $rows ) ) {
			throw new Exception( 'Database error during getting details for duplicated comment meta.' );
		}

		// Build the array to return.
		$resulted[0] = $cols;
		$resulted[1] = $rows;
		return $resulted;
	}

	/**
	 * Gets details for pingbacks.
	 *
	 * @access public
	 * @return array A bidemensional array of details for pingbacks.
	 * @throws Exception Throws an exception when a database occurred during getting details of item.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_get_details_pingbacks() {
		global $wpdb;

		// Get the columns names.
		// phpcs:disable -- ignore direct database access rule.
		$cols = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT column_name
				FROM information_schema.columns
				WHERE table_schema=%s AND table_name=%s',
				$wpdb->dbname,
				$wpdb->comments
			),
			ARRAY_A
		);

		// Get the rows, limit to 500 for performance.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT *
				FROM $wpdb->comments
				WHERE comment_type = %s
				LIMIT 500",
				'pingback'
			),
			ARRAY_A
		);
		// phpcs:enable
		if ( empty( $cols ) || empty( $rows ) ) {
			throw new Exception( 'Database error during getting details for pingbacks.' );
		}

		// Build the array to return.
		$resulted[0] = $cols;
		$resulted[1] = $rows;
		return $resulted;
	}

	/**
	 * Gets details for trackbacks.
	 *
	 * @access public
	 * @return array A bidemensional array of details for trackbacks.
	 * @throws Exception Throws an exception when a database occurred during getting details of item.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_get_details_trackbacks() {
		global $wpdb;

		// Get columns names.
		// phpcs:disable -- ignore direct database access rule.
		$cols = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT column_name
				FROM information_schema.columns
				WHERE table_schema=%s AND table_name=%s',
				$wpdb->dbname,
				$wpdb->comments
			),
			ARRAY_A
		);

		// Get the rows, limit to 500, for performance.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT *
				FROM $wpdb->comments
				WHERE comment_type = %s
				LIMIT 500",
				'trackback'
			),
			ARRAY_A
		);
		// phpcs:enable
		if ( empty( $cols ) || empty( $rows ) ) {
			throw new Exception( 'Database error during getting details for trackbacks.' );
		}

		// Build the array to return.
		$resulted[0] = $cols;
		$resulted[1] = $rows;
		return $resulted;
	}

	/**
	 * Gets details for drafts.
	 *
	 * @access public
	 * @return array A bidemensional array of details for drafts.
	 * @throws Exception Throws an exception when a database occurred during getting details of item.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_get_details_drafts() {
		global $wpdb;

		// Get the column names.
		// phpcs:disable -- ignore direct database access rule.
		$cols = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT column_name
				FROM information_schema.columns
				WHERE table_schema=%s AND table_name=%s',
				$wpdb->dbname,
				$wpdb->posts
			),
			ARRAY_A
		);

		// Get the rows, limit to 500, for performance.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT *
				FROM $wpdb->posts
				WHERE post_status = %s
				LIMIT 500",
				'draft'
			),
			ARRAY_A
		);
		// phpcs:enable
		if ( empty( $cols ) || empty( $rows ) ) {
			throw new Exception( 'Database error during getting details for drafts.' );
		}

		// Build the array to return.
		$resulted[0] = $cols;
		$resulted[1] = $rows;
		return $resulted;
	}

	/**
	 * Gets details for auto drafts.
	 *
	 * @access public
	 * @return array A bidemensional array of details for auto drafts.
	 * @throws Exception Throws an exception when a database occurred during getting details of item.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_get_details_auto_drafts() {
		global $wpdb;

		// Get columns names.
		// phpcs:disable -- ignore direct database access rule.
		$cols = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT column_name
				FROM information_schema.columns
				WHERE table_schema=%s AND table_name=%s',
				$wpdb->dbname,
				$wpdb->posts
			),
			ARRAY_A
		);

		// Get the rows, limit to 500, for performance.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT *
				FROM $wpdb->posts
				WHERE post_status = %s
				LIMIT 500",
				'auto-draft'
			),
			ARRAY_A
		);
		// phpcs:enable
		if ( empty( $cols ) || empty( $rows ) ) {
			throw new Exception( 'Database error during getting details for auto drafts.' );
		}

		// Build the array to return.
		$resulted[0] = $cols;
		$resulted[1] = $rows;
		return $resulted;
	}

	/**
	 * Gets details for revisions.
	 *
	 * @access public
	 * @return array A bidemensional array of details for revisions.
	 * @throws Exception Throws an exception when a database occurred during getting details of item.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_get_details_revisions() {
		global $wpdb;

		// Get the columns names.
		// phpcs:disable -- ignore direct database access rule.
		$cols = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT column_name
				FROM information_schema.columns
				WHERE table_schema=%s AND table_name=%s',
				$wpdb->dbname,
				$wpdb->posts
			),
			ARRAY_A
		);

		// Get the rows, limit to 500, for performance.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT *
				FROM $wpdb->posts
				WHERE post_type = %s
				LIMIT 500",
				'revision'
			),
			ARRAY_A
		);
		// phpcs:enable
		if ( empty( $cols ) || empty( $rows ) ) {
			throw new Exception( 'Database error during getting details for revisions.' );
		}

		// Build the array to return.
		$resulted[0] = $cols;
		$resulted[1] = $rows;
		return $resulted;
	}

	/**
	 * Gets details for trash posts.
	 *
	 * @access public
	 * @return array A bidemensional array of details for trash posts.
	 * @throws Exception Throws an exception when a database occurred during getting details of item.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_get_details_trash_posts() {
		global $wpdb;

		// Get columns names.
		// phpcs:disable -- ignore direct database access rule.
		$cols = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT column_name
				FROM information_schema.columns
				WHERE table_schema=%s AND table_name=%s',
				$wpdb->dbname,
				$wpdb->posts
			),
			ARRAY_A
		);

		// Get the rows, limit to 500, for performance.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT *
				FROM $wpdb->posts
				WHERE post_status = %s
				LIMIT 500",
				'trash'
			),
			ARRAY_A
		);
		// phpcs:enable
		if ( empty( $cols ) || empty( $rows ) ) {
			throw new Exception( 'Database error during getting details for trash posts.' );
		}

		// Build the array to return.
		$resulted[0] = $cols;
		$resulted[1] = $rows;
		return $resulted;
	}

	/**
	 * Gets details for orphan post meta.
	 *
	 * @access public
	 * @return array A bidemensional array of details for orphan post meta.
	 * @throws Exception Throws an exception when a database occurred during getting details of item.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_get_details_orphan_post_meta() {
		global $wpdb;

		// Get the columns names.
		// phpcs:disable -- ignore direct database access rule.
		$cols = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT column_name
				FROM information_schema.columns
				WHERE table_schema=%s AND table_name=%s',
				$wpdb->dbname,
				$wpdb->postmeta
			),
			ARRAY_A
		);

		// Get the rows, limit to 500, for performance.
		$rows = $wpdb->get_results(
			"SELECT meta_id, post_id, meta_key, meta_value
			FROM $wpdb->postmeta pm
			LEFT JOIN $wpdb->posts posts ON posts.ID = pm.post_id
			WHERE posts.ID IS NULL
			LIMIT 500",
			ARRAY_A
		);
		// phpcs:enable
		if ( empty( $cols ) || empty( $rows ) ) {
			throw new Exception( 'Database error during getting details for orphan post meta.' );
		}

		// Build the array to return.
		$resulted[0] = $cols;
		$resulted[1] = $rows;
		return $resulted;
	}

	/**
	 * Gets details for old slugs.
	 *
	 * @access public
	 * @return array A bidemensional array of details for old slugs.
	 * @throws Exception Throws an exception when a database occurred during getting details of item.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_get_details_old_slugs() {
		global $wpdb;

		// Get the columns names.
		// phpcs:disable -- ignore direct database access rule.
		$cols = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT column_name
				FROM information_schema.columns
				WHERE table_schema=%s AND table_name=%s',
				$wpdb->dbname,
				$wpdb->postmeta
				),
			ARRAY_A
			);
		
		// Get the rows, limit to 500, for performance.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT meta_id, post_id, meta_key, meta_value
				FROM $wpdb->postmeta
				WHERE meta_key=%s
				LIMIT 500", '_wp_old_slug' ),
			ARRAY_A);
		// phpcs:enable
		if ( empty( $cols ) || empty( $rows ) ) {
			throw new Exception( 'Database error during getting details for old slugs.' );
		}

		// Build the array to return.
		$resulted[0] = $cols;
		$resulted[1] = $rows;
		return $resulted;
	}

	/**
	 * Gets details for old dates.
	 *
	 * @access public
	 * @return array A bidemensional array of details for old dates.
	 * @throws Exception Throws an exception when a database occurred during getting details of item.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_get_details_old_dates() {
		global $wpdb;

		// Get the columns names.
		// phpcs:disable -- ignore direct database access rule.
		$cols = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT column_name
				FROM information_schema.columns
				WHERE table_schema=%s AND table_name=%s',
				$wpdb->dbname,
				$wpdb->postmeta
				),
			ARRAY_A
			);
		
		// Get the rows, limit to 500, for performance.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT meta_id, post_id, meta_key, meta_value
				FROM $wpdb->postmeta
				WHERE meta_key=%s
				LIMIT 500", '_wp_old_date' ),
			ARRAY_A);
		// phpcs:enable
		if ( empty( $cols ) || empty( $rows ) ) {
			throw new Exception( 'Database error during getting details for old dates.' );
		}

		// Build the array to return.
		$resulted[0] = $cols;
		$resulted[1] = $rows;
		return $resulted;
	}

	/**
	 * Gets details for plugins old logs (older than 1 month).
	 *
	 * @access public
	 * @return array A bidemensional array of details for plugin old logs.
	 * @throws Exception Throws an exception when a database occurred during getting details of item.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_get_details_plugin_old_logs() {
		global $wpdb;
		$logs_table = $wpdb->prefix . Wpclpro_Loader::LOGS_TABLE_NAME;

		// Get the columns names.
		// phpcs:disable -- ignore direct database access rule.
		$cols = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT column_name
				FROM information_schema.columns
				WHERE table_schema=%s AND table_name=%s',
				$wpdb->dbname,
				$logs_table
				),
			ARRAY_A
			);
		
		// Get the rows, limit to 500, for performance.
		$rows = $wpdb->get_results(
				"SELECT * 
				 FROM " . $logs_table . " 
				 WHERE time < (DATE_SUB(CURDATE(), INTERVAL 1 MONTH))",
			ARRAY_A);
		// phpcs:enable
		if ( empty( $cols ) || empty( $rows ) ) {
			throw new Exception( 'Database error during getting details for plugin old logs.' );
		}

		// Build the array to return.
		$resulted[0] = $cols;
		$resulted[1] = $rows;
		return $resulted;
	}

	/**
	 * Gets details for duplicated post meta.
	 *
	 * @access public
	 * @return array A bidemensional array of details for duplicated post meta.
	 * @throws Exception Throws an exception when a database occurred during getting details of item.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_get_details_duplicated_post_meta() {
		global $wpdb;

		// Get the columns names.
		// phpcs:disable -- ignore direct database access rule.
		$cols = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT column_name
				FROM information_schema.columns
				WHERE table_schema=%s AND table_name=%s',
				$wpdb->dbname,
				$wpdb->postmeta
			),
			ARRAY_A
		);

		// Get the rows, limit to 500, for performance.
		$rows = $wpdb->get_results(
			"SELECT DISTINCT *
			FROM $wpdb->postmeta as t1
			WHERE EXISTS (
			SELECT post_id, meta_key, meta_value
			FROM $wpdb->postmeta as t2
			WHERE t1.meta_id <> t2.meta_id
			AND t1.post_id = t2.post_id
			AND t1.meta_key = t2.meta_key
			AND t1.meta_value = t2.meta_value )
			ORDER BY t1.post_id, t1.meta_key, t1.meta_value
			LIMIT 500",
			ARRAY_A
		);
		// phpcs:enable
		if ( empty( $cols ) || empty( $rows ) ) {
			throw new Exception( 'Database error during getting details for duplicated post meta.' );
		}

		// Build the array to return.
		$resulted[0] = $cols;
		$resulted[1] = $rows;
		return $resulted;
	}

	/**
	 * Gets details for orphan term relationships.
	 *
	 * @access public
	 * @return array A bidemensional array of details for orphan term relationships.
	 * @throws Exception Throws an exception when a database occurred during getting details of item.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_get_details_orphan_term_relationships() {
		global $wpdb;

		// Get the columns names.
		// phpcs:disable -- ignore direct database access rule.
		$cols = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT column_name
				FROM information_schema.columns
				WHERE table_schema=%s AND table_name=%s',
				$wpdb->dbname,
				$wpdb->term_relationships
			),
			ARRAY_A
		);

		// Get the rows, limit to 500, for performance.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT *
				FROM $wpdb->term_relationships
				WHERE term_taxonomy_id = %d
				AND object_id NOT IN
				(SELECT id FROM $wpdb->posts)
				LIMIT 500",
				1
			),
			ARRAY_A
		);
		// phpcs:enable
		if ( empty( $cols ) || empty( $rows ) ) {
			throw new Exception( 'Database error during getting details for orphan term relationships.' );
		}

		// Build the array to return.
		$resulted[0] = $cols;
		$resulted[1] = $rows;
		return $resulted;
	}

	/**
	 * Gets details for unused terms.
	 *
	 * @access public
	 * @return array A bidemensional array of details for unused terms.
	 * @throws Exception Throws an exception when a database occurred during getting details of item.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_get_details_unused_terms() {
		global $wpdb;

		// Get the columns names.
		// phpcs:disable -- ignore direct database access rule.
		$cols = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT column_name
				FROM information_schema.columns
				WHERE table_schema=%s AND table_name=%s',
				$wpdb->dbname,
				$wpdb->terms
			),
			ARRAY_A
		);

		// Build the excluded ids array.
		$excluded_ids = implode( ',', $this->wpclpro_excluded_term_ids() );

		// And get the details of unused terms, only 500 results, for performance.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT DISTINCT t.*
				FROM $wpdb->terms AS t
				INNER JOIN $wpdb->term_taxonomy AS tt
				ON t.term_id = tt.term_id
				WHERE tt.count = %d AND t.term_id
				NOT IN ( $excluded_ids )
				LIMIT 500", 0), ARRAY_A );
		// phpcs:enable
		if ( empty( $cols ) || empty( $rows ) ) {
			throw new Exception( 'Database error during getting details for unused terms.' );
		}

		// Build the array to return.
		$resulted[0] = $cols;
		$resulted[1] = $rows;
		return $resulted;
	}

	/**
	 * Gets details for duplicated term meta.
	 *
	 * @access public
	 * @return array A bidemensional array of details for duplicated term meta.
	 * @throws Exception Throws an exception when a database occurred during getting details of item.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_get_details_duplicated_term_meta() {
		global $wpdb;

		// Get the columns names.
		// phpcs:disable -- ignore direct database access rule.
		$cols = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT column_name
				FROM information_schema.columns
				WHERE table_schema=%s AND table_name=%s',
				$wpdb->dbname,
				$wpdb->termmeta
			),
			ARRAY_A
		);

		// Get the rows, limit to 500, for performance.
		$rows = $wpdb->get_results(
			"SELECT DISTINCT *
			FROM $wpdb->termmeta as t1
			WHERE EXISTS (
			SELECT term_id, meta_key, meta_value
			FROM $wpdb->termmeta as t2
			WHERE t1.meta_id <> t2.meta_id
			AND t1.term_id = t2.term_id
			AND t1.meta_key = t2.meta_key
			AND t1.meta_value = t2.meta_value )
			ORDER BY t1.term_id, t1.meta_key, t1.meta_value
			LIMIT 500",
			ARRAY_A
		);
		// phpcs:enable
		if ( empty( $cols ) || empty( $rows ) ) {
			throw new Exception( 'Database error during getting details for duplicated term meta.' );
		}

		// Build the array to return.
		$resulted[0] = $cols;
		$resulted[1] = $rows;
		return $resulted;
	}

	/**
	 * Gets details for expired transients.
	 *
	 * @access public
	 * @return array A bidemensional array of details for expired transients.
	 * @throws Exception Throws an exception when a database occurred during getting details of item.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_get_details_expired_transients() {
		$now = time();
		global $wpdb;

		// Get the columns names.
		// phpcs:disable -- ignore direct database access rule.
		$cols = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT column_name
				FROM information_schema.columns
				WHERE table_schema=%s AND table_name=%s',
				$wpdb->dbname,
				$wpdb->options
			),
			ARRAY_A
		);

		// Get the rows, limit to 500, for performance.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT *
				FROM $wpdb->options
				WHERE option_name LIKE %s
				AND option_value < %d
				LIMIT 500",
				'%_transient_timeout_%',
				$now
			),
			ARRAY_A
		);
		// phpcs:enable
		if ( empty( $cols ) || empty( $rows ) ) {
			throw new Exception( 'Database error during getting details for expired transients.' );
		}

		// Build the array to return.
		$resulted[0] = $cols;
		$resulted[1] = $rows;
		return $resulted;
	}

	/**
	 * Gets details for orphan user meta.
	 *
	 * @access public
	 * @return array A bidemensional array of details for orphan user meta.
	 * @throws Exception Throws an exception when a database occurred during getting details of item.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_get_details_orphan_user_meta() {
		global $wpdb;

		// Get columns names.
		// phpcs:disable -- ignore direct database access rule.
		$cols = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT column_name
				FROM information_schema.columns
				WHERE table_schema=%s AND table_name=%s',
				$wpdb->dbname,
				$wpdb->usermeta
			),
			ARRAY_A
		);

		// Get the rows, limit to 500, for performance.
		$rows = $wpdb->get_results(
			"SELECT *
			FROM $wpdb->usermeta
			WHERE user_id NOT IN
			(SELECT ID FROM $wpdb->users)
			LIMIT 500",
			ARRAY_A
		);
		// phpcs:enable
		if ( empty( $cols ) || empty( $rows ) ) {
			throw new Exception( 'Database error during getting details for orphan user meta.' );
		}

		// Build the array to return.
		$resulted[0] = $cols;
		$resulted[1] = $rows;
		return $resulted;
	}

	/**
	 * Gets details for duplicated user meta.
	 *
	 * @access public
	 * @return array A bidemensional array of details for duplicated user meta.
	 * @throws Exception Throws an exception when a database occurred during getting details of item.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_get_details_duplicated_user_meta() {
		global $wpdb;

		// Get columns names.
		// phpcs:disable -- ignore direct database access rule.
		$cols = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT column_name
				FROM information_schema.columns
				WHERE table_schema=%s AND table_name=%s',
				$wpdb->dbname,
				$wpdb->usermeta
			),
			ARRAY_A
		);

		// Get the rows, limit to 500, for performance.
		$rows = $wpdb->get_results(
			"SELECT DISTINCT *
			FROM $wpdb->usermeta as t1
			WHERE EXISTS (
			SELECT user_id, meta_key, meta_value
			FROM $wpdb->usermeta as t2
			WHERE t1.umeta_id <> t2.umeta_id
			AND t1.user_id = t2.user_id
			AND t1.meta_key = t2.meta_key
			AND t1.meta_value = t2.meta_value )
			ORDER BY t1.user_id, t1.meta_key, t1.meta_value
			LIMIT 500",
			ARRAY_A
		);
		// phpcs:enabled.
		if ( empty( $cols ) || empty( $rows ) ) {
			throw new Exception( 'Database error during getting details for duplicated user meta.' );
		}

		// Build the array to return.
		$resulted[0] = $cols;
		$resulted[1] = $rows;
		return $resulted;
	}

	/**
	 * Gets details for subscribers with invalid email.
	 *
	 * @access public
	 * @return array A bidemensional array of details for subscribers with invalid email.
	 * @throws Exception Throws an exception when a database occurred during getting details of item.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_get_details_subscribers_invalid_email() {
		global $wpdb;

		// Get columns names.
		// phpcs:disable -- ignore direct database access rule.
		$cols = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT column_name
				FROM information_schema.columns
				WHERE table_schema=%s AND table_name=%s',
				$wpdb->dbname,
				$wpdb->users
			),
			ARRAY_A
		);

		// Get the rows, limit to 500, for performance.
		// Valid regex coutesy of http://emailregex.com/.
		$rows = $wpdb->get_results(
			"SELECT DISTINCT t1.*
			FROM $wpdb->users AS t1
			INNER JOIN $wpdb->usermeta AS t2
			ON t1.ID = t2.user_id
			WHERE meta_key = 'wp_capabilities'
			AND meta_value  LIKE '%subscriber%'
			AND t1.user_email NOT REGEXP '^[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$'
			LIMIT 500",
			ARRAY_A
		);
		// phpcs:enable
		if ( empty( $cols ) || empty( $rows ) ) {
			throw new Exception( 'Database error during getting details for subscribers with invalid emails.' );
		}

		// Build the array to return.
		$resulted[0] = $cols;
		$resulted[1] = $rows;
		return $resulted;
	}

	/**
	 * Gets details for post weird chars.
	 *
	 * @access public
	 * @return array A bidemensional array of details for post weird chars.
	 * @throws Exception Throws an exception when a database occurred during getting details of item.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_get_details_post_weird_chars() {
		global $wpdb;

		// Get the columns names.
		// phpcs:disable -- ignore direct database access rule.
		$cols = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT column_name
				FROM information_schema.columns
				WHERE table_schema=%s AND table_name=%s',
				$wpdb->dbname,
				$wpdb->posts
			),
			ARRAY_A
		);

		// Add wildcards, since we are searching within text.
		$p1 = '%' . $wpdb->esc_like( 'â€œ' ) . '%';
		$p2 = '%' . $wpdb->esc_like( 'â€' ) . '%';
		$p3 = '%' . $wpdb->esc_like( 'â€™' ) . '%';
		$p4 = '%' . $wpdb->esc_like( 'â€˜' ) . '%';
		$p5 = '%' . $wpdb->esc_like( 'â€”' ) . '%';
		$p6 = '%' . $wpdb->esc_like( 'â€“' ) . '%';
		$p7 = '%' . $wpdb->esc_like( 'â€¢' ) . '%';
		$p8 = '%' . $wpdb->esc_like( 'â€¦' ) . '%';

		// Then get the results using this SQL query.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM $wpdb->posts
				WHERE ( post_content LIKE %s
				OR post_content LIKE %s
				OR post_content LIKE %s
				OR post_content LIKE %s
				OR post_content LIKE %s
				OR post_content LIKE %s
				OR post_content LIKE %s
				OR post_content LIKE %s
				)",
				$p1,
				$p2,
				$p3,
				$p4,
				$p5,
				$p6,
				$p7,
				$p8
			),
			ARRAY_A
		);
		// phpcs:enable
		if ( empty( $cols ) || empty( $rows ) ) {
			throw new Exception( 'Database error during getting details for post weird chars.' );
		}

		// Build the array to return.
		$resulted[0] = $cols;
		$resulted[1] = $rows;
		return $resulted;
	}

	/**
	 * Gets details for comment weird chars.
	 *
	 * @access public
	 * @return array A bidemensional array of details for comment weird chars.
	 * @throws Exception Throws an exception when a database occurred during getting details of item.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_get_details_comment_weird_chars() {
		global $wpdb;

		// Get the column names.
		// phpcs:disable -- ignore direct database access rule.
		$cols = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT column_name
				FROM information_schema.columns
				WHERE table_schema=%s AND table_name=%s',
				$wpdb->dbname,
				$wpdb->comments
			),
			ARRAY_A
		);

		// Add wildcards, since we are searching within text.
		$p1 = '%' . $wpdb->esc_like( 'â€œ' ) . '%';
		$p2 = '%' . $wpdb->esc_like( 'â€' ) . '%';
		$p3 = '%' . $wpdb->esc_like( 'â€™' ) . '%';
		$p4 = '%' . $wpdb->esc_like( 'â€˜' ) . '%';
		$p5 = '%' . $wpdb->esc_like( 'â€”' ) . '%';
		$p6 = '%' . $wpdb->esc_like( 'â€“' ) . '%';
		$p7 = '%' . $wpdb->esc_like( 'â€¢' ) . '%';
		$p8 = '%' . $wpdb->esc_like( 'â€¦' ) . '%';

		// Then get the results using this SQL query.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM $wpdb->comments
				WHERE ( comment_content LIKE %s
				OR comment_content LIKE %s
				OR comment_content LIKE %s
				OR comment_content LIKE %s
				OR comment_content LIKE %s
				OR comment_content LIKE %s
				OR comment_content LIKE %s
				OR comment_content LIKE %s
				)",
				$p1,
				$p2,
				$p3,
				$p4,
				$p5,
				$p6,
				$p7,
				$p8
			),
			ARRAY_A
		);
		// phpcs:enable
		if ( empty( $cols ) || empty( $rows ) ) {
			throw new Exception( 'Database error during getting details for comment weird chars.' );
		}

		// Build the array to return.
		$resulted[0] = $cols;
		$resulted[1] = $rows;
		return $resulted;
	}

	/**
	 * Gets details for comment agent.
	 *
	 * @access public
	 * @return array A bidemensional array of details for comment agent.
	 * @throws Exception Throws an exception when a database occurred during getting details of item.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_get_details_comment_agent() {
		global $wpdb;

		// Get columns names.
		// phpcs:disable -- ignore direct database access rule.
		$cols = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT column_name
				FROM information_schema.columns
				WHERE table_schema=%s AND table_name=%s',
				$wpdb->dbname,
				$wpdb->comments
			),
			ARRAY_A
		);

		// Get the rows, limit to 500, for performance.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT *
				FROM $wpdb->comments
				WHERE comment_agent != %s
				LIMIT 500",
				''
			),
			ARRAY_A
		);
		// phpcs:enable
		if ( empty( $cols ) || empty( $rows ) ) {
			throw new Exception( 'Database error during getting details for comment agent.' );
		}

		// Build the array to return.
		$resulted[0] = $cols;
		$resulted[1] = $rows;
		return $resulted;
	}

	/**
	 * Gets details for oembed caches.
	 *
	 * @access public
	 * @return array A bidemensional array of details for oembed caches.
	 * @throws Exception Throws an exception when a database occurred during getting details of item.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_get_details_oembed_caches() {
		global $wpdb;

		// Get columns names.
		// phpcs:disable -- ignore direct database access rule.
		$cols = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT column_name
				FROM information_schema.columns
				WHERE table_schema=%s AND table_name=%s',
				$wpdb->dbname,
				$wpdb->postmeta
			),
			ARRAY_A
		);

		// Get the rows, limit to 500, for performance.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT *
				FROM $wpdb->postmeta
				WHERE meta_key LIKE %s
				LIMIT 500",
				'%_oembed_%'
			),
			ARRAY_A
		);
		// phpcs:enable
		if ( empty( $cols ) || empty( $rows ) ) {
			throw new Exception( 'Database error during getting details for oembed caches.' );
		}

		// Build the array to return.
		$resulted[0] = $cols;
		$resulted[1] = $rows;
		return $resulted;
	}

	/**
	 * Gets details for links from links table.
	 *
	 * @access public
	 * @return array A bidemensional array of details for links from links table.
	 * @throws Exception Throws an exception when a database occurred during getting details of item.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_get_details_wp_links() {
		global $wpdb;

		// Get columns names.
		// phpcs:disable -- ignore direct database access rule.
		$cols = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT column_name
				FROM information_schema.columns
				WHERE table_schema=%s AND table_name=%s',
				$wpdb->dbname,
				$wpdb->links
			),
			ARRAY_A
		);

		// Get the rows, limit to 500, for performance.
		$rows = $wpdb->get_results( "SELECT * FROM $wpdb->links LIMIT 500", ARRAY_A );
		// phpcs:enable
		if ( empty( $cols ) || empty( $rows ) ) {
			throw new Exception( 'Database error during getting details for links entries.' );
		}

		// Build the array to return.
		$resulted[0] = $cols;
		$resulted[1] = $rows;
		return $resulted;
	}

	/**
	 * Gets details for database tables.
	 *
	 * @access public
	 * @return array A bidemensional array of details for database tables.
	 * @throws Exception Throws an exception when a database occurred during getting details of item.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_get_details_tables() {
		global $wpdb;

		// Build the columns names.
		$cols[0] = __( 'Table name', 'wpclpro' );
		$cols[1] = __( 'Table type', 'wpclpro' );
		$cols[2] = __( 'Rows', 'wpclpro' );
		$cols[3] = __( 'Table size', 'wpclpro' );

		// Get the rows, limit to 500, for performace.
		// phpcs:disable -- ignore direct database access rule.
		$rows = $wpdb->get_results(
			"SELECT table_name, engine, table_rows, data_length + index_length as data_length
                FROM information_schema.tables
                WHERE table_schema='" . $wpdb->dbname . "'
                LIMIT 500",
			ARRAY_A
		);
		// phpcs:enable

		foreach ( $rows as &$row ) {
			$row['data_length'] = Wpclpro_Utilities::wpclpro_format_filesize( $row['data_length'] );
		}

		if ( empty( $cols ) || empty( $rows ) ) {
			throw new Exception( 'Database error during getting details for database tables.' );
		}

		// Build the array to return.
		$resulted[0] = $cols;
		$resulted[1] = $rows;
		return $resulted;
	}

	/**
	 * Gets details for orphan database tables.
	 *
	 * @access public
	 * @return array A bidemensional array of details for orphan database tables.
	 * @throws Exception Throws an exception when a database occurred during getting details of item.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_get_details_orphan_tables() {
		global $wpdb;

		// Build the columns names.
		$cols[0] = __( 'Table name', 'wpclpro' );
		$cols[1] = __( 'Table type', 'wpclpro' );
		$cols[2] = __( 'Rows', 'wpclpro' );
		$cols[3] = __( 'Table size', 'wpclpro' );

		// Get the rows, limit to 500, for performace.
		// phpcs:disable -- ignore direct database access rule.
		$rows = $wpdb->get_results(
			"SELECT table_name, engine, table_rows, data_length + index_length as data_length
                FROM information_schema.tables
                WHERE table_schema='" . $wpdb->dbname . "'
                LIMIT 500",
			ARRAY_A
		);
		// phpcs:enable
		if ( empty( $cols ) || empty( $rows ) ) {
			throw new Exception( 'Database error during getting details for orphan tables.' );
		}

		$orphan_tables = $this->wpclpro_get_orphan_tables();

		foreach ( $rows as $index => $row ) {
			$row['data_length'] = Wpclpro_Utilities::wpclpro_format_filesize( $row['data_length'] );

			if ( strpos( $row['table_name'], $wpdb->prefix ) === 0 ) {
				// It table name starts with $wpdb->prefix.
				$no_prefixed_table_name = substr( $row['table_name'], strlen( $wpdb->prefix ) );
			} else {
				$no_prefixed_table_name = $row['table_name'];
			}

			if ( ! in_array( $no_prefixed_table_name, $orphan_tables, true ) ) {
				unset( $rows[ $index ] );
			}
		}

		// Build the array to return.
		$resulted[0] = $cols;
		$resulted[1] = $rows;
		return $resulted;
	}

	/**
	 * Gets details for orphan shortcodes.
	 *
	 * @access public
	 * @return array A bidemensional array of details for orphan shortcodes.
	 * @throws Exception Throws an exception when a database occurred during getting details of shortcode.
	 */
	public function wpclpro_get_details_orphan_shortcodes() {

		// Build the columns names.
		$cols[0] = __( 'Shortcode', 'wpclpro' );
		$cols[1] = __( 'Post/Page id', 'wpclpro' );
		$cols[2] = __( 'Where shortcode is used', 'wpclpro' );

		// Get the rows.
		$dao  = new Wpclpro_DAO();
		$rows = $dao->wpclpro_get_orphan_shortcodes();
		if ( empty( $cols ) || empty( $rows ) ) {
			throw new Exception( 'Database error during getting details for orphan shortcodes.' );
		}

		foreach ( $rows as &$shortcode ) {
			$shortcode['link'] =
				'<a href="'
				. admin_url(
					'post.php?post='
					. $shortcode['post_id']
					. '&action=edit'
				)
				. '" target="_blank">'
				. $shortcode['link']
				. '</a>';
		}

		// Build the array to return.
		$resulted[0] = $cols;
		$resulted[1] = $rows;
		return $resulted;
	}

	/**
	 * Gets details for orphan options.
	 *
	 * @access public
	 * @return array A bidemensional array of details for orphan options.
	 * @throws Exception Throws an exception when a database occurred during getting details of item.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_get_details_orphan_options() {
		global $wpdb;

		// Get the columns names.
		// phpcs:disable -- ignore direct database access rule.
		$cols = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT column_name
				FROM information_schema.columns
				WHERE table_schema=%s AND table_name=%s',
				$wpdb->dbname,
				$wpdb->options
				),
			ARRAY_A
			);
		
		// Get the rows, limit to 500, for performance.
		$orphan_options = parent::wpclpro_get_orphan_options();
		
		$options = array();
		foreach ($orphan_options as $item) {
			$options[] = $item['option_name'];
		}
		$list = implode('\', \'', $options);
		
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT *
				FROM $wpdb->options
				WHERE option_name
				IN ( '$list' )
				LIMIT 500"
				),
			ARRAY_A
			);
		// phpcs:enable
		if ( empty( $cols ) || empty( $rows ) ) {
			throw new Exception( 'Database error during getting details for orphan options.' );
		}

		// Build the array to return.
		$resulted[0] = $cols;
		$resulted[1] = $rows;
		return $resulted;
	}
}
