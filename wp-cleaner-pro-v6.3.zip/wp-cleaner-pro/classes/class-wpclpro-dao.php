<?php
/**
 * Holds the logic for database access related operations.
 *
 * @package    wp-cleaner-pro
 * @author     hevada <support@hevada.com>
 * @copyright  2017-2030 hevada <support@hevada.com>
 * @link       http://codecanyon.net/user/hevada
 * @version    6.3
 * @since      1.0
 */

/**
 * Class that contains the logic for database access related operations.
 */
class Wpclpro_DAO {

	/**
	 * Stores the class logger.
	 *
	 * @access private
	 * @var Logger
	 */
	private $logger;

	/**
	 * Constructor.
	 *
	 * @access public
	 * @return void
	 */
	public function __construct() {
		Logger::configure( WPCLPRO_PLUGIN_DIR . 'log4php/config.php' );
		$this->logger = Logger::getLogger( __CLASS__ );

		// Initialize file system and protect the backups directory.
		$this->wpclpro_prepare_filesystem();
	}

	/**
	 * Gets excluded term IDs (excluded from cleaning).
	 *
	 * @access protected
	 * @return array Excluded term IDs.
	 */
	protected function wpclpro_excluded_term_ids() {
		// Get default taxonomy term ids (if array is empty, initialize with empty one).
		$default_taxonomy_term_ids = $this->wpclpro_get_default_term_ids();

		// Get parent term ids (if array is empty, initialize with empty one).
		$parent_term_ids = $this->wpclpro_get_parent_termids();

		// Merge these two arrays: taxonomy terms ids with parent term ids.
		return array_merge( $default_taxonomy_term_ids, $parent_term_ids );
	}

	/**
	 * Gets all default taxonomy term IDs.
	 *
	 * @access private
	 * @return array The default taxonomy term IDs.
	 */
	private function wpclpro_get_default_term_ids() {
		$dfault_ids = array();
		$taxonomies = get_taxonomies();

		if ( $taxonomies ) {
			$taxonomy_keys = array_keys( $taxonomies );
			if ( $taxonomy_keys ) {
				foreach ( $taxonomy_keys as $key ) {
					$id = intval( get_option( 'default_' . $key ) );
					if ( $id > 0 ) {
						$dfault_ids[] = $id;
					}
				}
			}
		}
		return $dfault_ids;
	}

	/**
	 * Gets terms that have a parent term.
	 *
	 * @access private
	 * @return array The parent term IDs.
	 */
	private function wpclpro_get_parent_termids() {
		global $wpdb;
		$ids = array();

		// phpcs:disable -- ignore direct database access rule.
		$ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT taxonomy.parent FROM $wpdb->terms AS terms
				INNER JOIN $wpdb->term_taxonomy AS taxonomy
				ON terms.term_id = taxonomy.term_id
				WHERE taxonomy.parent > %d",
				0
			)
		);
		// phpcs:enable

		return $ids;
	}

	/**
	 * Gets the database size (data length + index length).
	 *
	 * @access public
	 * @return int The size of the database.
	 */
	public function wpclpro_get_db_size() {
		global $wpdb;
		$dbsize = 0;

		// Get information about each non-temporary table.
		// phpcs:disable -- ignore direct database access rule.
		$dbsize = $wpdb->get_var(
			$wpdb->prepare(
				'SELECT SUM(data_length + index_length)
				FROM information_schema.tables
				WHERE table_schema = %s',
				$wpdb->dbname
			)
		);
		// phpcs:enable

		return $dbsize;
	}

	/**
	 * Checks if the WordPress file system is initialized. If it's not, it will initialize it.
	 *
	 * @access public
	 * @return $wp_filesystem Returns the global WordPress file system.
	 * @global $wp_filesystem The WordPress file system.
	 */
	public function wpclpro_prepare_filesystem() {
		global $wp_filesystem;

		if ( is_null( $wp_filesystem ) ) {
			$url = wp_nonce_url( admin_url( 'tools.php?page=wpclpro' ), 'wpclpro' );

			// Get filesystem credentials needed for WP_Filesystem.
			$creds = request_filesystem_credentials( $url, '', false, false, null );

			if ( false === $creds ) {
				esc_html_e( 'Credentials are required to read WordPress files.', 'wpclpro' );
				exit();
			}

			// Get the upload directory.
			$wp_upload_dir = wp_upload_dir();

			// When credentials are obtained, check to make sure they work.
			if ( ! WP_Filesystem( $creds, $wp_upload_dir['basedir'] ) ) {
				// Request_filesystem_credentials a second time, but this time with the $error flag set.
				request_filesystem_credentials( $url, '', true, false, null );
				esc_html_e( 'Credentials are required to read WordPress files.', 'wpclpro' );
				exit();
			}
		}

		global $wp_filesystem;

		return $wp_filesystem;
	}

	/**
	 * Gets an array of orphan tables from the database (without the WP prefix).
	 *
	 * @access public
	 * @return array() Returns the array containing the orphan database tables (without the WP prefix).
	 * @global $wpdb The WordPress database.
	 */
	public function wpclpro_get_orphan_tables() {
		global $wpdb;

		// Get all tables names from the database, those that were created more than 3 months ago.
		// phpcs:disable -- ignore direct database access rule.
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT table_name, create_time
   				 FROM information_schema.tables
				 WHERE table_type = "BASE TABLE"
      			 AND table_rows = 0
      			 AND table_schema = %s
      			 AND create_time < (DATE_SUB(CURDATE(), INTERVAL 3 MONTH))',
				$wpdb->dbname
				),
			ARRAY_A
			);
		// phpcs:enable

		$db_tables = array();
		foreach ( $rows as $index => $row ) {
			// Extract only the table name, without the prefix.
			if ( strpos( $row['table_name'], $wpdb->prefix ) === 0 ) {
				$db_tables[ $index ] = substr( $row['table_name'], strlen( $wpdb->prefix ) );
			} else {
				$db_tables[ $index ] = $row['table_name'];
			}
		}

		// WordPress core tables are not orphan, so we will not consider them.
		$wp_tables = $wpdb->tables( 'all', false );

		// The possible orphan tables are the ones as difference between all database tables and WordPress tables.
		$orphan_tables = array_diff( $db_tables, $wp_tables );

		return $orphan_tables;
	}

	/**
	 * Gets an array of orphan shortcodes from the database (from posts and pages).
	 *
	 * @access public
	 * @return array() Returns the array of orphan shortcodes from the database (from posts and pages).
	 */
	public function wpclpro_get_orphan_shortcodes() {
		// Raise time limits.
		Wpclpro_Utilities::wpclpro_raise_time_limits();

		// Prepare filesystem.
		$filesystem = $this->wpclpro_prepare_filesystem();

		$args = array(
			// Type, status, pagination parameters.
			'post_type'      => 'any',
			'post_status'    => 'any',
			'posts_per_page' => -1,
		);
		// Find the orphan shortcodes in the posts and pages.
		$query   = new WP_Query( $args );
		$orphans = array();
		$matches = array();
		if ( $query->have_posts() ) {
			while ( $query->have_posts() ) {
				// Get the post and call the_content() which will already filter all registered shortcodes.
				$query->the_post();
				ob_start();
				the_content();
				// Get the parsed content where all registered shortcodes have been replaced.
				$output = ob_get_clean();

				// Checking for a shortcode pattern (wp-includes/shortcodes.php, do_shortcode method).
				preg_match_all( '@\[([^<>&/\[\]\x00-\x20=]++)@', $output, $matches );
				// If any match, add it to array of orphan shortcodes.
				if ( $matches[0] ) {
					$orphans[] = array(
						'shortcode' => $matches[1][0],
						'post_id'   => get_the_id(),
						'link'      => get_permalink(),
					);
				}
			}
			wp_reset_postdata();
		}

		// Now search each of these possible orphan shortcodes in the WP content folder,
		// to make sure that there isn't any inactive plugin or theme which is using it.
		$term = '';
		$path = WP_CONTENT_DIR;
		$dir  = new RecursiveDirectoryIterator( $path );

		foreach ( new RecursiveIteratorIterator( $dir ) as $subdir => $file ) {
			$filename  = $file->getFilename();
			$n         = strrpos( $filename, '.' );
			$extension = ( false === $n ) ? '' : substr( $filename, $n + 1 );

			if ( in_array( $extension, array( 'php', 'sql', 'txt', 'csv' ), true ) ) {
				$content = $filesystem->get_contents( $file->getPathname() );

				if ( $orphans ) {
					foreach ( $orphans as $k => $unused ) {
						$term = $unused['shortcode'];
						if ( strpos( $content, $term ) !== false ) {
							// Found, it means may be used by inactive theme/plugin.
							// Remove it from the list of orphans.
							unset( $orphans[ $k ] );
							break;
						}
					}
				}
			}
		}

		// Restore time limits.
		Wpclpro_Utilities::wpclpro_restore_time_limits();

		return $orphans;
	}

	/**
	 * Gets an array of orphan options from the table wp_options.
	 *
	 * @access public
	 * @return array() Returns the array containing the orphan options from the table wp_options.
	 * @global $wpdb The WordPress database.
	 */
	public function wpclpro_get_orphan_options() {
		global $wpdb;

		// Raise time limits.
		Wpclpro_Utilities::wpclpro_raise_time_limits();

		// Prepare filesystem.
		$filesystem = $this->wpclpro_prepare_filesystem();

		// Get all options from the database.
		// phpcs:disable -- ignore direct database access rule.
		$rows = $wpdb->get_results(
					"SELECT option_name
	   				 FROM $wpdb->options",
				ARRAY_A
			);
		// phpcs:enable

		// Default WordPress options, as found in wp-admin/includes/schema.php.
		$default_options = $this->wpclpro_get_default_options();

		$term = '';
		$path = WP_CONTENT_DIR;
		$dir  = new RecursiveDirectoryIterator( $path );

		// Now search each of these possible orphan options in the WP content folder,
		// to make sure that there isn't any plugin or theme which is using it.
		// If found, remove it from the list of orphans to be returned as result.
		foreach ( new RecursiveIteratorIterator( $dir ) as $subdir => $file ) {
			$filename  = $file->getFilename();
			$n         = strrpos( $filename, '.' );
			$extension = ( false === $n ) ? '' : substr( $filename, $n + 1 );

			if ( in_array( $extension, array( 'php', 'sql', 'txt', 'csv' ), true ) ) {
				$content = $filesystem->get_contents( $file->getPathname() );

				if ( $rows ) {
					foreach ( $rows as $index => $row ) {

						$term = $row['option_name'];

						// 1. Exclude theme mods from orphan options list.
						if ( Wpclpro_Utilities::wpclpro_starts_with( $term, 'theme_mods_' )
							|| Wpclpro_Utilities::wpclpro_starts_with( $term, 'mods_' ) ) {

								// Found, it means may be used, remove it from the list of orphans.
								unset( $rows[ $index ] );
								break;
						}

						// 2. Do not show as orphan if it is a default WordPress option.
						if ( in_array( $term, $default_options, true ) ) {
							unset( $rows[ $index ] );
							break;
						}

						// 3. Do not show as orphan if the entire word is found in plugins or themes folder.
						if ( strpos( $content, $term ) !== false ) {
							// Found, it means may be used, remove it from the list of orphans.
							unset( $rows[ $index ] );
							break;
						}

						// 4. Now search for the last group by _.
						$groups = explode( '_', $term );

						if ( count( $groups ) >= 1 ) {
							$term = end( $groups );
						}

						if ( strpos( $content, $term ) !== false ) {
							// Found, it means may be used, remove it from the list of orphans.
							unset( $rows[ $index ] );
							break;
						}

						// 5. Now search for the last group by -.
						$groups = explode( '-', $term );

						if ( count( $groups ) >= 1 ) {
							$term = end( $groups );
						}

						if ( strpos( $content, $term ) !== false ) {
							// Found, it means may be used, remove it from the list of orphans.
							unset( $rows[ $index ] );
							break;
						}
					}
				}
			}
		}

		// Restore time limits.
		Wpclpro_Utilities::wpclpro_restore_time_limits();

		return $rows;
	}

	/**
	 * Gets the array of default WordPress options.
	 *
	 * @access public
	 * @return array() Returns the array of default WordPress options as in
	 * wp-admin/includes/schema.php
	 * wp-admin/includes/options.php
	 * wp-includes/option.php
	 * wp-includes/wp-settings.php
	 * wp-includes/default-constants.php
	 */
	public function wpclpro_get_default_options() {
		$default_options = array(
			'_site_transient_',
			'_site_transient_theme_roots',
			'_site_transient_timeout_theme_roots',
			'_transient_doing_cron',
			'_transient_feed_',
			'_transient_mailserver_last_checked',
			'_transient_plugin_slugs',
			'_transient_plugins_delete_result_',
			'_transient_random_seed',
			'_transient_rewrite_rules',
			'_transient_timeout_dirsize_cache',
			'_transient_timeout_feed_',
			'_transient_timeout_plugin_slugs',
			'_transient_update_core',
			'_transient_update_plugins',
			'_transient_update_themes',
			'_transient_wporg_theme_feature_list',
			'active_plugins',
			'active_sitewide_plugins',
			'admin_email',
			'admin_email_lifespan',
			'advanced_edit',
			'akismet_available_servers',
			'akismet_connectivity_time',
			'akismet_discard_month',
			'akismet_spam_count',
			'auto_plugin_theme_update_emails',
			'auto_update_core_dev',
			'auto_update_core_major',
			'auto_update_core_minor',
			'avatar_default',
			'avatar_rating',
			'blacklist_keys',
			'blog_charset',
			'blog_public',
			'blogdescription',
			'blogname',
			'can_compress_scripts',
			'category_base',
			'category_children',
			'close_comments_days_old',
			'close_comments_for_old_posts',
			'comment_max_links',
			'comment_moderation',
			'comment_order',
			'comment_previously_approved',
			'comment_registration',
			'comment_whitelist',
			'comments_notify',
			'comments_per_page',
			'cron',
			'date_format',
			'db_version',
			'default_category',
			'default_comment_status',
			'default_comments_page',
			'default_email_category',
			'default_link_category',
			'default_ping_status',
			'default_pingback_flag',
			'default_post_edit_rows',
			'default_post_format',
			'default_role',
			'disallowed_keys',
			'dismissed_update_core',
			'doing_cron',
			'embed_autourls',
			'embed_size_h',
			'embed_size_w',
			'enable_app',
			'enable_xmlrpc',
			'fileupload_url',
			'finished_splitting_shared_terms',
			'global_terms_enabled',
			'gmt_offset',
			'gzipcompression',
			'hack_file',
			'home',
			'html_type',
			'image_default_align',
			'image_default_link_type',
			'image_default_size',
			'import-blogger',
			'initial_db_version',
			'kubrick_header_color',
			'kubrick_header_display',
			'kubrick_header_image',
			'large_size_h',
			'large_size_w',
			'link_manager_enabled',
			'links_recently_updated_append',
			'links_recently_updated_prepend',
			'links_recently_updated_time',
			'links_updated_date_format',
			'mailserver_login',
			'mailserver_pass',
			'mailserver_port',
			'mailserver_url',
			'medium_large_size_h',
			'medium_large_size_w',
			'medium_size_h',
			'medium_size_w',
			'moderation_keys',
			'moderation_notify',
			'ms_files_rewriting',
			'page_attachment_uris',
			'page_comments',
			'page_for_posts',
			'page_on_front',
			'page_uris',
			'permalink_structure',
			'ping_sites',
			'posts_per_page',
			'posts_per_rss',
			'recently_edited',
			'require_name_email',
			'rewrite_rules',
			'rss_excerpt_length',
			'rss_language',
			'rss_use_excerpt',
			'secret',
			'show_avatars',
			'show_comments_cookies_opt_in',
			'show_on_front',
			'sidebars_widgets',
			'site_admins',
			'site_icon',
			'site_name',
			'siteurl',
			'start_of_week',
			'sticky_posts',
			'stylesheet',
			'tag_base',
			'template',
			'thread_comments',
			'thread_comments_depth',
			'thumbnail_crop',
			'thumbnail_size_h',
			'thumbnail_size_w',
			'time_format',
			'timezone_string',
			'uninstall_plugins',
			'update_core',
			'upload_path',
			'upload_url_path',
			'uploads_use_yearmonth_folders',
			'use_balanceTags',
			'use_linksupdate',
			'use_smilies',
			'use_ssl',
			'use_trackback',
			'users_can_register',
			'valid_options',
			'what_to_show',
			'widget_akismet',
			'widget_archives',
			'widget_calendar',
			'widget_categories',
			'widget_links',
			'widget_meta',
			'widget_nav_menu',
			'widget_pages',
			'widget_recent-comments',
			'widget_recent-posts',
			'widget_recent_entries',
			'widget_rss',
			'widget_search',
			'widget_tag_cloud',
			'widget_text',
			'wordpress_api_key',
			'wp_attachment_pages_enabled',
			'wp_force_deactivated_plugins',
			'wp_page_for_privacy_policy',
			'xvalid_options',
		);

		return $default_options;
	}
}
