<?php
/**
 * Holds the logic for handling plugin log events in the custom log table of the plugin.
 *
 * @package    wp-cleaner-pro
 * @author     hevada <support@hevada.com>
 * @copyright  2017-2030 hevada <support@hevada.com>
 * @link       http://codecanyon.net/user/hevada
 * @version    6.3
 * @since      1.0
 */

/**
 * Class that contains the logic for handling plugin log events in the custom log table of the plugin.
 */
class Wpclpro_Logger_Appender extends LoggerAppender {

	/**
	 * Extends the log4php LoggerAppender class.
	 * Connects to the database, and prepares the insert query.
	 *
	 * @access protected
	 * @return void
	 * @throws PDOException If connect or prepare fails.
	 * @global wpdb $wpdb
	 */
	protected function establishConnection() {
		// Acquire database connection.
		global $wpdb;
		$this->db = $wpdb;
	}

	/**
	 * Appends a new event to the database.
	 *
	 * @access public
	 * @param LoggerLoggingEvent $event The log event to be saved in the plugin's table.
	 * @return void
	 * @global wpdb $wpdb
	 */
	public function append( LoggerLoggingEvent $event ) {

		// Build a custom table to save plugin's logs.
		global $wpdb;
		$logs_table = $wpdb->prefix . Wpclpro_Loader::LOGS_TABLE_NAME;

		// Extract and build the logging information from the logging event.
		$time      = gmdate( 'Y-m-d H:i:s', time() );
		$info      = $event->getLocationInformation();
		$classname = $info->getClassName();
		$line      = $info->getLineNumber();
		$level     = $event->getLevel()->toString();
		$message   = $event->getMessage();

		// And create an entry in the plugin's logs table for this log event.
		$row['time']      = $time;
		$row['classname'] = $classname;
		$row['line']      = $line;
		$row['level']     = $level;
		$row['message']   = $message;

		// Insert the log row in the logs table.
		// phpcs:disable -- ignore direct database access rule.
		$wpdb->insert( $logs_table, $row );
		// phpcs:enable
	}
}
