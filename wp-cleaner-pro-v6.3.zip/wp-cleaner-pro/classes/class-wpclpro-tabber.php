<?php
/**
 * Holds the logic for creating the tabs to be shown on the cleaner's admin form.
 *
 * @package    wp-cleaner-pro
 * @author     hevada <support@hevada.com>
 * @copyright  2017-2030 hevada <support@hevada.com>
 * @link       http://codecanyon.net/user/hevada
 * @version    6.3
 * @since      1.0
 */

/**
 * Class that contains the logic for creating the tabs to be shown on the cleaner's admin form.
 */
class Wpclpro_Tabber {

	/**
	 * Stores the tabs to be shown on cleaner's admin form.
	 *
	 * @access public
	 * @var array
	 */
	public $wpclpro_tabs = array();

	/**
	 * Constructor.
	 *
	 * @access public
	 * @return void
	 */
	public function __construct() {
	}

	/**
	 * Starts outputting the tabs to the front-end.
	 *
	 * @access public
	 * @return void
	 */
	public function wpclpro_tabs_start() {
	}

	/**
	 * Shows a file content in a tab with given tab title.
	 *
	 * @access private
	 * @param string $title The tab's title.
	 * @param string $filename The name of the file to be shown as tab content.
	 * @global array $wpclpro_tabs The list of tabs to be shown in the admin form.
	 * @return void
	 */
	public function wpclpro_tab( $title, $filename ) {

		global $wpclpro_tabs;

		// Build the current tab: title.
		$tab['title'] = $title;

		// Build the current tab: file name.
		$tab['filename'] = $filename;

		// And add the current tab to the global list of tabs to be shown in front-end.
		$wpclpro_tabs[] = $tab;
	}

	/**
	 * Processes and displays the tab content.
	 *
	 * @access public
	 * @global array $wpclpro_tabs The list of tabs to be shown in cleaner's admin form.
	 * @return void
	 */
	public function wpclpro_tabs_end() {
		global $wpclpro_tabs;

		// Calculate the current index.
		$index = 0;

		if ( isset( $_GET['tabindex'] ) && isset( $_GET[ Wpclpro_Loader::NONCE ] )
			&& wp_verify_nonce( filter_input_array( INPUT_GET, FILTER_SANITIZE_FULL_SPECIAL_CHARS )[ Wpclpro_Loader::NONCE ], Wpclpro_Loader::ACTION ) ) {
				$index = sanitize_text_field( wp_unslash( $_GET['tabindex'] ) );
		}

		// Start displaying the tabs.
		ob_start();
		?>
		<table class="wpclpro-tabs-table">
			<tr id="wpclpro-header-tabs">
			<?php
			$curindex = 0;
			foreach ( $wpclpro_tabs as $tab ) {
				if ( intval( $index ) === intval( $curindex ) ) {
					$class = 'wpclpro-tab-active';
				} else {
					$class = 'wpclpro-tab';
				}
				$url = wp_nonce_url( '?page=wpclpro&tabindex=' . $curindex, Wpclpro_Loader::ACTION, Wpclpro_Loader::NONCE );
				?>
				<td class="<?php echo esc_attr( $class ); ?>">
					<a href="<?php echo esc_attr( $url ); ?>">
						<span class="wpclpro-tab-title"><?php echo esc_attr( $tab['title'] ); ?></span>
					</a>
				</td>
					<?php
					++$curindex;
			}
			?>
			</tr>
			<tr>
				<td class="wpclpro-tab-content" colspan="<?php echo esc_attr( count( $wpclpro_tabs ) ); ?>">
				<?php include_once WPCLPRO_PLUGIN_DIR . 'views/' . $wpclpro_tabs[ $index ]['filename']; ?>
				</td>
			</tr>
		</table>
		<?php
		ob_end_flush();
	} // End of wpclpro_tabs_end method.
} // End of class.
