<?php
/**
 * Holds the logic to be done on submit of the cleaning form.
 *
 * @package wp-cleaner-pro
 * @author hevada <support@hevada.com>
 * @copyright 2017-2030 hevada <support@hevada.com>
 * @link http://codecanyon.net/user/hevada
 * @version 6.3
 * @since 1.0
 */

/**
 * Include the logger class from log4php package.
 */
require_once WPCLPRO_PLUGIN_DIR . '/log4php/Logger.php';

/**
 * Class that contains the logic to be done on submit of the cleaning form.
 */
class Wpclpro_Controller {

	/**
	 * Stores the Logger.
	 *
	 * @access private
	 * @var Logger
	 */
	private $logger;

	/**
	 * Constructor.
	 *
	 * @acces public
	 * @return void
	 */
	public function __construct() {
		Logger::configure( WPCLPRO_PLUGIN_DIR . 'log4php/config.php' );
		$this->logger = Logger::getLogger( __CLASS__ );
	}

	/**
	 * Logs as error the message given as parameter.
	 *
	 * @access public
	 * @param string $message The message to be logged.
	 * @return void
	 */
	public function wpclpro_log_error( $message ) {
		$this->logger->log( LoggerLevel::getLevelError(), $message );
	}

	/**
	 * Counts certain items which can be cleaned.
	 *
	 * @access public
	 * @param int $item The name of the item to count.
	 * @return int The number of counted item.
	 */
	public function wpclpro_count( $item ) {
		$dao = new Wpclpro_Counter_DAO();

		switch ( $item ) {
			case Wpclpro_Loader::TRASH_COMMENTS:
				return $dao->wpclpro_count_trash_comments();
			case Wpclpro_Loader::SPAM_COMMENTS:
				return $dao->wpclpro_count_spam_comments();
			case Wpclpro_Loader::WMODERATION:
				return $dao->wpclpro_count_wmoderation();
			case Wpclpro_Loader::ORPHAN_COMMENT_META:
				return $dao->wpclpro_count_orphan_comment_meta();
			case Wpclpro_Loader::DUPLICATED_COMMENT_META:
				return $dao->wpclpro_count_duplicated_comment_meta();
			case Wpclpro_Loader::PINGBACKS:
				return $dao->wpclpro_count_pingbacks();
			case Wpclpro_Loader::TRACKBACKS:
				return $dao->wpclpro_count_trackbacks();
			case Wpclpro_Loader::DRAFTS:
				return $dao->wpclpro_count_drafts();
			case Wpclpro_Loader::AUTODRAFTS:
				return $dao->wpclpro_count_auto_drafts();
			case Wpclpro_Loader::REVISIONS:
				return $dao->wpclpro_count_revisions();
			case Wpclpro_Loader::TRASH_POSTS:
				return $dao->wpclpro_count_trash_posts();
			case Wpclpro_Loader::ORPHAN_POST_META:
				return $dao->wpclpro_count_orphan_post_meta();
			case Wpclpro_Loader::OLD_SLUGS:
				return $dao->wpclpro_count_old_slugs();
			case Wpclpro_Loader::OLD_DATES:
				return $dao->wpclpro_count_old_dates();
			case Wpclpro_Loader::PLUGIN_OLD_LOGS:
				return $dao->wpclpro_count_plugin_old_logs();
			case Wpclpro_Loader::DUPLICATED_POST_META:
				return $dao->wpclpro_count_duplicated_post_meta();
			case Wpclpro_Loader::ORPHAN_TERM_RELATIONSHIPS:
				return $dao->wpclpro_count_orphan_term_relationships();
			case Wpclpro_Loader::UNUSED_TERMS:
				return $dao->wpclpro_count_unused_terms();
			case Wpclpro_Loader::DUPLICATED_TERM_META:
				return $dao->wpclpro_count_duplicated_term_meta();
			case Wpclpro_Loader::EXPIRED_TRANSIENTS:
				return $dao->wpclpro_count_expired_transients();
			case Wpclpro_Loader::ORPHAN_USER_META:
				return $dao->wpclpro_count_orphan_user_meta();
			case Wpclpro_Loader::DUPLICATED_USER_META:
				return $dao->wpclpro_count_duplicated_user_meta();
			case Wpclpro_Loader::SUBSCRIBERS_INVALID_EMAIL:
				return $dao->wpclpro_count_subscribers_invalid_email();
			case Wpclpro_Loader::POST_WEIRD_CHARS:
				return $dao->wpclpro_count_post_weird_chars();
			case Wpclpro_Loader::COMMENT_WEIRD_CHARS:
				return $dao->wpclpro_count_comment_weird_chars();
			case Wpclpro_Loader::COMMENT_AGENT:
				return $dao->wpclpro_count_comment_agent();
			case Wpclpro_Loader::OEMBED_CACHES:
				return $dao->wpclpro_count_oembed_caches();
			case Wpclpro_Loader::WP_LINKS:
				return $dao->wpclpro_count_wp_links();
			case Wpclpro_Loader::ORPHAN_TABLES:
				return $dao->wpclpro_count_orphan_tables();
			case Wpclpro_Loader::ORPHAN_SHORTCODES:
				return $dao->wpclpro_count_orphan_shortcodes();
			case Wpclpro_Loader::ORPHAN_OPTIONS:
				return $dao->wpclpro_count_orphan_options();
			case Wpclpro_Loader::TABLES:
				return $dao->wpclpro_count_tables();
			default:
				return 0;
		}
	}

	/**
	 * Gets from URL parameters the name of the item to show details for (in the Details tab of the cleaning form).
	 *
	 * @access public
	 * @return string The item to shows details for.
	 */
	public function wpclpro_get_item() {
		$name = '';

		// Get details for what item? Default is showing the tables of the database.
		if ( isset( $_GET[ Wpclpro_Loader::ITEM ] ) && isset( $_GET[ WPCLPRO_LOADER::NONCE ] )
			&& wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET[ WPCLPRO_LOADER::NONCE ] ) ), Wpclpro_Loader::ACTION ) ) {
				$name = sanitize_text_field( wp_unslash( $_GET[ Wpclpro_Loader::ITEM ] ) );
		} else {
			$name = Wpclpro_Loader::TABLES;
		}

		return $name;
	}

	/**
	 * Gets the text for an item given by name.
	 *
	 * @access public
	 * @param string $name The name of the item to show the text for.
	 * @return string The text describing the item.
	 */
	public function wpclpro_get_item_text( $name ) {

		// Get the details, depending for what item.
		switch ( $name ) {
			case Wpclpro_Loader::TRASH_COMMENTS:
				return __( 'Trash comments', 'wpclpro' );
			case Wpclpro_Loader::SPAM_COMMENTS:
				return __( 'Spam comments', 'wpclpro' );
			case Wpclpro_Loader::WMODERATION:
				return __( 'Waiting for moderation comments', 'wpclpro' );
			case Wpclpro_Loader::DUPLICATED_COMMENT_META:
				return __( 'Duplicated comment meta', 'wpclpro' );
			case Wpclpro_Loader::PINGBACKS:
				return __( 'Pingbacks', 'wpclpro' );
			case Wpclpro_Loader::TRACKBACKS:
				return __( 'Trackbacks', 'wpclpro' );
			case Wpclpro_Loader::COMMENT_WEIRD_CHARS:
				return __( 'Weird characters in comments', 'wpclpro' );
			case Wpclpro_Loader::COMMENT_AGENT:
				return __( 'Comment agent information', 'wpclpro' );
			case Wpclpro_Loader::ORPHAN_COMMENT_META:
				return __( 'Orphan comment meta', 'wpclpro' );
			case Wpclpro_Loader::DRAFTS:
				return __( 'Drafts', 'wpclpro' );
			case Wpclpro_Loader::AUTODRAFTS:
				return __( 'Auto-drafts', 'wpclpro' );
			case Wpclpro_Loader::REVISIONS:
				return __( 'Revisions', 'wpclpro' );
			case Wpclpro_Loader::TRASH_POSTS:
				return __( 'Trash posts', 'wpclpro' );
			case Wpclpro_Loader::DUPLICATED_POST_META:
				return __( 'Duplicated post meta', 'wpclpro' );
			case Wpclpro_Loader::POST_WEIRD_CHARS:
				return __( 'Weird characters in posts', 'wpclpro' );
			case Wpclpro_Loader::OEMBED_CACHES:
				return __( 'oEmbed caches from posts meta', 'wpclpro' );
			case Wpclpro_Loader::ORPHAN_POST_META:
				return __( 'Orphan post meta', 'wpclpro' );
			case Wpclpro_Loader::OLD_SLUGS:
				return __( 'Old slugs', 'wpclpro' );
			case Wpclpro_Loader::OLD_DATES:
				return __( 'Old dates', 'wpclpro' );
			case Wpclpro_Loader::PLUGIN_OLD_LOGS:
				return __( 'Plugin old logs', 'wpclpro' );
			case Wpclpro_Loader::UNUSED_TERMS:
				return __( 'Unused terms', 'wpclpro' );
			case Wpclpro_Loader::DUPLICATED_TERM_META:
				return __( 'Duplicated term meta', 'wpclpro' );
			case Wpclpro_Loader::ORPHAN_TERM_RELATIONSHIPS:
				return __( 'Orphan term relationships', 'wpclpro' );
			case Wpclpro_Loader::EXPIRED_TRANSIENTS:
				return __( 'Expired transients', 'wpclpro' );
			case Wpclpro_Loader::DUPLICATED_USER_META:
				return __( 'Duplicated user meta', 'wpclpro' );
			case Wpclpro_Loader::SUBSCRIBERS_INVALID_EMAIL:
				return __( 'Subscribers with invalid email', 'wpclpro' );
			case Wpclpro_Loader::ORPHAN_USER_META:
				return __( 'Orphan user meta', 'wpclpro' );
			case Wpclpro_Loader::WP_LINKS:
				return __( 'Links in wp_links table', 'wpclpro' );
			case Wpclpro_Loader::ORPHAN_TABLES:
				return __( 'Orphan tables', 'wpclpro' );
			case Wpclpro_Loader::ORPHAN_SHORTCODES:
				return __( 'Orphan shortcodes', 'wpclpro' );
			case Wpclpro_Loader::ORPHAN_OPTIONS:
				return __( 'Orphan options', 'wpclpro' );
			case Wpclpro_Loader::TABLES:
				return __( 'Tables in the WordPress database', 'wpclpro' );
			default:
				return __( 'Tables in the WordPress database', 'wpclpro' );
		}

		return $name;
	}

	/**
	 * Gets the details of an item from the database.
	 *
	 * @access public
	 * @param string $item The name of the item to show the details for.
	 * @return array Returns the details of that item.
	 */
	public function wpclpro_get_details( $item ) {
		$dao = new Wpclpro_Details_DAO();

		// Get the details, depending for what item.
		switch ( $item ) {
			case Wpclpro_Loader::TRASH_COMMENTS:
				return $dao->wpclpro_get_details_trash_comments();
			case Wpclpro_Loader::SPAM_COMMENTS:
				return $dao->wpclpro_get_details_spam_comments();
			case Wpclpro_Loader::WMODERATION:
				return $dao->wpclpro_get_details_wmoderation();
			case Wpclpro_Loader::ORPHAN_COMMENT_META:
				return $dao->wpclpro_get_details_orphan_comment_meta();
			case Wpclpro_Loader::DUPLICATED_COMMENT_META:
				return $dao->wpclpro_get_details_duplicated_comment_meta();
			case Wpclpro_Loader::PINGBACKS:
				return $dao->wpclpro_get_details_pingbacks();
			case Wpclpro_Loader::TRACKBACKS:
				return $dao->wpclpro_get_details_trackbacks();
			case Wpclpro_Loader::DRAFTS:
				return $dao->wpclpro_get_details_drafts();
			case Wpclpro_Loader::AUTODRAFTS:
				return $dao->wpclpro_get_details_auto_drafts();
			case Wpclpro_Loader::REVISIONS:
				return $dao->wpclpro_get_details_revisions();
			case Wpclpro_Loader::TRASH_POSTS:
				return $dao->wpclpro_get_details_trash_posts();
			case Wpclpro_Loader::ORPHAN_POST_META:
				return $dao->wpclpro_get_details_orphan_post_meta();
			case Wpclpro_Loader::OLD_SLUGS:
				return $dao->wpclpro_get_details_old_slugs();
			case Wpclpro_Loader::OLD_DATES:
				return $dao->wpclpro_get_details_old_dates();
			case Wpclpro_Loader::PLUGIN_OLD_LOGS:
				return $dao->wpclpro_get_details_plugin_old_logs();
			case Wpclpro_Loader::DUPLICATED_POST_META:
				return $dao->wpclpro_get_details_duplicated_post_meta();
			case Wpclpro_Loader::ORPHAN_TERM_RELATIONSHIPS:
				return $dao->wpclpro_get_details_orphan_term_relationships();
			case Wpclpro_Loader::UNUSED_TERMS:
				return $dao->wpclpro_get_details_unused_terms();
			case Wpclpro_Loader::DUPLICATED_TERM_META:
				return $dao->wpclpro_get_details_duplicated_term_meta();
			case Wpclpro_Loader::EXPIRED_TRANSIENTS:
				return $dao->wpclpro_get_details_expired_transients();
			case Wpclpro_Loader::ORPHAN_USER_META:
				return $dao->wpclpro_get_details_orphan_user_meta();
			case Wpclpro_Loader::DUPLICATED_USER_META:
				return $dao->wpclpro_get_details_duplicated_user_meta();
			case Wpclpro_Loader::SUBSCRIBERS_INVALID_EMAIL:
				return $dao->wpclpro_get_details_subscribers_invalid_email();
			case Wpclpro_Loader::POST_WEIRD_CHARS:
				return $dao->wpclpro_get_details_post_weird_chars();
			case Wpclpro_Loader::COMMENT_WEIRD_CHARS:
				return $dao->wpclpro_get_details_comment_weird_chars();
			case Wpclpro_Loader::COMMENT_AGENT:
				return $dao->wpclpro_get_details_comment_agent();
			case Wpclpro_Loader::OEMBED_CACHES:
				return $dao->wpclpro_get_details_oembed_caches();
			case Wpclpro_Loader::WP_LINKS:
				return $dao->wpclpro_get_details_wp_links();
			case Wpclpro_Loader::ORPHAN_TABLES:
				return $dao->wpclpro_get_details_orphan_tables();
			case Wpclpro_Loader::ORPHAN_SHORTCODES:
				return $dao->wpclpro_get_details_orphan_shortcodes();
			case Wpclpro_Loader::ORPHAN_OPTIONS:
				return $dao->wpclpro_get_details_orphan_options();
			case Wpclpro_Loader::TABLES:
				return $dao->wpclpro_get_details_tables();
			default:
				return $dao->wpclpro_get_details_tables();
		}
	}

	/**
	 * Displays a "details" icon, which can be clicked to view item details.
	 *
	 * If the count for that type of item is = 0, a lightgray icon is shown.
	 * If the count for that type of item is > 0, a blue clickable icon is shown. Clicking this item,
	 * you can view the details of this item.
	 * The method does not return anything, it just displays the details icon, which can be clickable or not,
	 * depending of the $count parameter.
	 *
	 * @access public
	 * @param string $title The title to show in the details link.
	 * @param string $item The name of the item to show details for.
	 * @return void
	 */
	public function wpclpro_show_details_icon( $title, $item ) {

		// Display a link without href, until there are items to show details for.
		echo '<a title="'
			. esc_attr__( 'View', 'wpclpro' )
			. ' '
				. esc_attr( $title )
			. '" id="wpclpro-details-link-' . esc_attr( $item ) . '">'
			. '<span class="dashicons dashicons-visibility wpclpro-lightgray"></span>'
			. '</a>';
	}

	/**
	 * Displays a recycle bin icon, which can be clicked to clean an item.
	 *
	 * If the count for that type of item is = 0, a lightgray icon is shown.
	 * If the count for that type of item is > 0, an orange clickable icon is shown. Clicking this item,
	 * it will clean that item. The method does not return anything, it just displays the recycle bin icon,
	 * which can be clickable or not, depending of the $count parameter.
	 *
	 * @access public
	 * @param string $title The title to show in the clean link.
	 * @param string $item The name of the item to show details for.
	 * @return void
	 */
	public function wpclpro_show_clean_icon( $title, $item ) {

		// Display a link without href, until there are items to clean.
		echo '<a title="'
			. esc_attr__( 'Clean', 'wpclpro' )
			. ' '
			. esc_attr( $title )
			. '" id="wpclpro-clean-link-' . esc_attr( $item ) . '">'
			. '<span class="dashicons dashicons-trash wpclpro-lightgray"></span>'
			. '</a>';
	}

	/**
	 * Displays a scheduled label, which shows that the cleaning of that item is scheduled.
	 *
	 * If the item is not scheduled, a gray label is shown.
	 * If the item is scheduled, a green label is shown, showing that that item is scheduled for cleaning.
	 * The method does not return anything, it just displays the scheduled label, for those scheduled items.
	 *
	 * @access public
	 * @param string $item The name of the item to show if it's scheduled or not.
	 * @param array  $items The array of all items scheduled for cleaning.
	 * @param string $display A flag indicating if the generated string has to be displayed on output or not.
	 * @return string The string output or void if the param display is true.
	 */
	public function wpclpro_get_scheduled_label( $item, $items, $display ) {
		$output = '';
		if ( ! empty( $items ) && in_array( $item, $items, true ) ) {
			$output = '<span title="'
					. esc_attr__( 'Scheduled for bulk cleaning.', 'wpclpro' )
					. '" class="wpclpro-scheduled">'
					. __( 'scheduled', 'wpclpro' )
					. '</span>';
		} else {
			$output = '<span title="'
					. esc_attr__( 'Not scheduled for bulk cleaning.', 'wpclpro' )
					. '" class="wpclpro-not-scheduled">'
					. __( 'not scheduled', 'wpclpro' )
					. '</span>';
		}
		if ( $display ) {
			$allowed_html = array(
				'span' => array(
					'class' => array(),
					'title' => array(),
				),
			);
			echo wp_kses( $output, $allowed_html );
		} else {
			return $output;
		}
	}

	/**
	 * Checks if the current user has access (if he has 'manage options' capability).
	 *
	 * @access public
	 * @return void
	 */
	public function wpclpro_check_access_capability() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'wpclpro' ) );
		}
	}

	/**
	 * Gets the size of the database.
	 *
	 * @access public
	 * @return int The size of the database at the current time.
	 */
	public function wpclpro_get_db_size() {
		$dao = new Wpclpro_DAO();
		return $dao->wpclpro_get_db_size();
	}

	/**
	 * Controls what happens on delete all logs action.
	 *
	 * @access public
	 * @return void
	 */
	public function wpclpro_action_delete_all_logs() {
		// Delete all logs.
		$log_dao = new Wpclpro_Logger_DAO();
		$log_dao->wpclpro_delete_all_logs();
	}

	/**
	 * Controls what happens on delete all backups action.
	 *
	 * @access private
	 * @return void
	 */
	public function wpclpro_action_delete_all_backups() {
		// Delete all backups.
		$backupper = new Wpclpro_Backupper_DAO();
		$backupper->wpclpro_delete_all_backups();
	}

	/**
	 * Controls what happens on schedule action.
	 *
	 * @access public
	 * @param array  $items The arrays of items to be scheduled for cleaning.
	 * @param string $frequency The frequency to use for cleaning the given items.
	 * @return True if event successfully scheduled. False or WP_Error on failure.
	 */
	public function wpclpro_action_schedule( $items, $frequency ) {
		// Save in the database the items to clean and the cleaning frequency.
		update_option( 'wpclpro_clean_frequency', $frequency, false );
		delete_option( 'wpclpro_clean_items' );
		update_option( 'wpclpro_clean_items', $items, false );

		// Schedule the cleaning; if another cleaning is scheduled, unschedule that first.
		if ( wp_next_scheduled( Wpclpro_Loader::SCHEDULED_HOOK_NAME ) ) {
			wp_clear_scheduled_hook( Wpclpro_Loader::SCHEDULED_HOOK_NAME );
		}
		return wp_schedule_event( time(), $frequency, Wpclpro_Loader::SCHEDULED_HOOK_NAME );
	}

	/**
	 * Controls what happens on delete backup action.
	 *
	 * @access public
	 * @param string $backup_name The name of the backup to delete.
	 * @return boolean $deleted Flag indicating if the delete was successful or not.
	 */
	public function wpclpro_action_delete_backup( $backup_name ) {
		// Delete the backup with that filename.
		$deleted = false;
		if ( ! empty( $backup_name ) ) {
			$backupper = new Wpclpro_Backupper_DAO();
			$deleted   = $backupper->wpclpro_delete_backup( $backup_name );
		}
		return $deleted;
	}

	/**
	 * Controlls what happens on create backup action.
	 *
	 * @access public
	 * @return string The name of the backup file that was created.
	 */
	public function wpclpro_action_create_backup() {
		// Create the backup file.
		$backupper = new Wpclpro_Backupper_DAO();
		$filename  = $backupper->wpclpro_create_db_backup();

		return $filename;
	}

	/**
	 * Controls what happens on clean action.
	 *
	 * @access public
	 * @param string $item The cleanable item to clean.
	 * @return void
	 */
	public function wpclpro_action_clean( $item ) {

		// Perform the clean of the cleanable item. If no items to process, just exit.
		if ( empty( $item ) ) {
			exit();
		}

		// Init the cleaning DAO.
		$dao = new Wpclpro_Cleaner_DAO();

		// And perform the cleaning.
		$dao->wpclpro_clean( $item );
	}

	/**
	 * Checks if any plugin log exists.
	 *
	 * @access public
	 * @return boolean True if any plugin log exists, false otherwise.
	 */
	public function wpclpro_logs_exist() {
		$dao = new Wpclpro_Logger_DAO();

		$logs_exist = ( $dao->wpclpro_count_logs() > 0 );
		return $logs_exist;
	}

	/**
	 * Optimizes database tables.
	 *
	 * @access public
	 * @return boolean True if the database was successfully optimized, false otherwise.
	 */
	public function wpclpro_optimize_tables() {
		$dao = new Wpclpro_Cleaner_DAO();
		return $dao->wpclpro_optimize_tables();
	}

	/**
	 * Resets cleaning counter.
	 *
	 * @access public
	 * @return boolean True if the counter was successfully reset, false otherwise.
	 */
	public function wpclpro_reset_counter() {
		$dao = new Wpclpro_Cleaner_DAO();
		return $dao->wpclpro_reset_counter();
	}

	/**
	 * Checks if database backups exist.
	 *
	 * @access public
	 * @return boolean True if database backups exist, false otherwise
	 */
	public function wpclpro_backups_exist() {
		$dao = new Wpclpro_Backupper_DAO();

		$backups_exist = ( $dao->wpclpro_count_backups() > 0 );
		return $backups_exist;
	}

	/**
	 * Starts the scheduled items cleaning.
	 *
	 * @access public
	 * @return void
	 */
	public function wpclpro_start_scheduled_items() {
		$items = get_option( 'wpclpro_clean_items' );

		// If no items to clean, just exit.
		if ( empty( $items ) ) {
			exit();
		}

		foreach ( $items as $item ) {
			$this->wpclpro_action_clean( $item );
		}
	}

	/**
	 * Gets all available database backups created previously.
	 *
	 * @access public
	 * @return array The list of all available backups created previously.
	 */
	public function wpclpro_get_backups() {
		$backupper = new Wpclpro_Backupper_DAO();
		return $backupper->wpclpro_get_backups();
	}

	/**
	 * Gets all available plugins logs.
	 *
	 * @access public
	 * @return array The array of all available plugin logs.
	 */
	public function wpclpro_get_logs() {
		$dao = new Wpclpro_Logger_DAO();
		return $dao->wpclpro_get_logs();
	}

	/**
	 * Controls what happens on unscheduling the scheduled cleaning.
	 *
	 * @access public
	 * @return boolean True if scheduling of cleaning was successfully, false otherwise.
	 */
	public function wpclpro_action_unschedule() {
		// Remove options from database.
		$this->wpclpro_delete_options();
		// Unschedule the cleaning of scheduled items.
		$unscheduled = wp_clear_scheduled_hook( Wpclpro_Loader::SCHEDULED_HOOK_NAME );
		return $unscheduled;
	}

	/**
	 * Deletes plugins options from wp_options table.
	 *
	 * @access public
	 * @return void
	 */
	public function wpclpro_delete_options() {
		delete_option( 'wpclpro_clean_frequency' );
		delete_option( 'wpclpro_clean_items' );
		delete_option( 'wpclpro_size_cleaned' );
	}

	/**
	 * Gets the size gained after cleaning, as difference between the size before cleaning and after cleaning.
	 *
	 * @access public
	 * @return string The compund string containing the size and the measure unit (MB).
	 */
	public function wpclpro_get_cleaned_space() {
		$cleaned_space = get_option( 'wpclpro_size_cleaned' );

		return Wpclpro_Utilities::wpclpro_format_filesize( $cleaned_space );
	}

	/**
	 * Gets the date when the next cleaning is scheduled.
	 *
	 * The date obtained is formatted in this format: d M Y H:i:s. For instance: 29 Nov 2017 21:15:14 (UTC+2).
	 *
	 * @access public
	 * @return string The date when the next cleaning will occur, the date when is scheduled.
	 */
	public function wpclpro_get_date_scheduled() {
		$event_time = wp_next_scheduled( Wpclpro_Loader::SCHEDULED_HOOK_NAME );
		return Wpclpro_Utilities::wpclpro_format_date( $event_time );
	}

	/**
	 * Format the details of a cleanable item, in a user-friendly table format.
	 *
	 * @access public
	 * @param array() $details The details of the cleanable item, in a multidimensional array format.
	 * @param boolean $strip Wether to strip or not the HTML tags in the shown content.
	 * @return string The formatted details of a cleanable item (in a user-friendly table format).
	 */
	public function wpclpro_format_details( $details, $strip ) {

		$column_names = $details[0];
		$items        = $details[1];

		$output = '';

		if ( isset( $column_names ) && isset( $items ) ) {

			$output .= '<table class="widefat wpclpro-table wpclpro-details-table order-column hover cell-border " id="wpclpro-table">';
			$output .= '<thead><tr><th>#</th>';

			foreach ( $column_names as $column_header ) {
				$output .= '<th>';

				if ( (array) $column_header !== $column_header ) {
					// Column header is not an array.
					$output .= $column_header;
				} else {
					// Column header is an array.
					$output .= implode( '</th><th>', $column_header );
				}

				$output .= '</th>';
			}

			$output .= '</tr></thead>';

			$output .= '<tbody>';
			foreach ( $items as $row ) {
				$output .= '<tr><td></td>';
				foreach ( $row as $cell ) {
					if ( $strip ) {
						$output .= '<td>' . wp_strip_all_tags( mb_strimwidth( $cell, 0, 100, '...' ) ) . '</td>';
					} else {
						$output .= '<td>' . mb_strimwidth( $cell, 0, 200, '...' ) . '</td>';
					}
				}
				$output .= '</tr>';
			}

			$output .= '</tbody>';

			$output .= '<tfoot><tr><th>#</th>';

			foreach ( $column_names as $column_header ) {
				$output .= '<th>';

				if ( (array) $column_header !== $column_header ) {
					// Column header is not an array.
					$output .= $column_header;
				} else {
					// Column header is an array.
					$output .= implode( '</th><th>', $column_header );
				}

				$output .= '</th>';
			}

			$output .= '</tr></tfoot>';
			$output .= '</table>';

		}

		return $output;
	}

	/**
	 * Format the backups list, in a user-friendly table format.
	 *
	 * @access public
	 * @param array() $backups the backups list.
	 * @return string The formatted backups list, in a user-friendly table format.
	 */
	public function wpclpro_format_backups( $backups ) {

		if ( ! is_null( $backups ) && ! empty( $backups ) ) {
			foreach ( $backups as &$backup ) {
				$name = $backup['name'];

				$backup['name'] = '<span class="icon dashicons dashicons-media-archive wpclpro-blue"></span>' . esc_html( $name );
				$backup['date'] = Wpclpro_Utilities::wpclpro_format_date( $backup['date'] );
				$backup['size'] = Wpclpro_Utilities::wpclpro_format_filesize( $backup['size'] );

				$backup['download']  = '<a href="' . esc_attr( $backup['url'] ) . '"';
				$backup['download'] .= 'title="' . __( 'Download', 'wpclpro' ) . '">';
				$backup['download'] .= '<span class="icon dashicons dashicons-download wpclpro-green dt-center"></span></a>';

				$backup['delete']  = '<a href="javascript: wpclpro_delete_backup(\'' . esc_attr( $name ) . '\');"';
				$backup['delete'] .= 'title="' . __( 'Delete', 'wpclpro' ) . '">';
				$backup['delete'] .= '<span class="icon dashicons dashicons-trash wpclpro-orange dt-center"></span>';
			}
		}

		return $backups;
	}

	/**
	 * Format the logs list, in a user-friendly table format.
	 *
	 * @access public
	 * @param array() $logs the logs list.
	 * @return string The formatted logs list, in a user-friendly table format.
	 */
	public function wpclpro_format_logs( $logs ) {

		foreach ( $logs as &$log ) {
			$log['time']      = Wpclpro_Utilities::wpclpro_format_string_date( $log['time'] );
			$log['classname'] = $log['classname'];
			$log['line']      = $log['line'];
			$level            = $log['level'];
			$log['level']     = '<span class="wpclpro-log-' . esc_attr( strtolower( $level ) ) . '">'
								. $log['level'] . '</span>';
			$log['message']   = '<span class="wpclpro-log-' . esc_attr( strtolower( $level ) ) . '">'
								. $log['message'] . '</span>';
		}
		return $logs;
	}
}
