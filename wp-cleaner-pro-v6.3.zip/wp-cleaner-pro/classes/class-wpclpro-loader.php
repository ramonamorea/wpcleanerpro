<?php
/**
 * Holds the constants and the logic for auto-loading classes.
 *
 * @package    wp-cleaner-pro
 * @author     hevada <support@hevada.com>
 * @copyright  2017-2030 hevada <support@hevada.com>
 * @link       http://codecanyon.net/user/hevada
 * @version    6.3
 * @since      1.0
 */

/**
 * Class that contains the constants and the logic for auto-loading classes.
 */
class Wpclpro_Loader {

	const NONCE = 'wpclpro-nonce';

	const SECURITY = 'wpclpro-security';

	const FOLDER = 'wp-cleaner-pro';

	const ITEMS = 'items';

	const ITEM = 'item';

	const ACTION = 'wpclpro-action';

	const ACTION_CLEAN = 'action-clean';

	const ACTION_SCHEDULE = 'action-schedule';

	const ACTION_UNSCHEDULE = 'action-unschedule';

	const ACTION_DELETE_BACKUP = 'action-delete-backup';

	const ACTION_DELETE_ALL_LOGS = 'action-delete-all-logs';

	const FREQUENCY = 'wpclpro-frequency';

	const BACKUP_NAME = 'wpclpro-backup-name';

	const TRASH_COMMENTS = 'trash_comments';

	const SPAM_COMMENTS = 'spam_comments';

	const WMODERATION = 'wmoderation_comments';

	const DUPLICATED_COMMENT_META = 'duplicated_comment_meta';

	const PINGBACKS = 'pingbacks';

	const TRACKBACKS = 'trackbacks';

	const COMMENT_WEIRD_CHARS = 'comment_weird_chars';

	const COMMENT_AGENT = 'comment_agent';

	const ORPHAN_COMMENT_META = 'orphan_comment_meta';

	const DRAFTS = 'drafts';

	const AUTODRAFTS = 'auto_drafts';

	const REVISIONS = 'revisions';

	const TRASH_POSTS = 'trash_posts';

	const DUPLICATED_POST_META = 'duplicated_post_meta';

	const POST_WEIRD_CHARS = 'post_weird_chars';

	const OEMBED_CACHES = 'oEmbed_caches';

	const ORPHAN_POST_META = 'orphan_post_meta';

	const OLD_SLUGS = 'old_slugs';

	const OLD_DATES = 'old_dates';

	const UNUSED_TERMS = 'unused_terms';

	const DUPLICATED_TERM_META = 'duplicated_term_meta';

	const ORPHAN_TERM_RELATIONSHIPS = 'orphan_term_relationships';

	const EXPIRED_TRANSIENTS = 'expired_transients';

	const DUPLICATED_USER_META = 'duplicated_user_meta';

	const SUBSCRIBERS_INVALID_EMAIL = 'subscribers_invalid_email';

	const ORPHAN_USER_META = 'orphan_user_meta';

	const WP_LINKS = 'wp_links';

	const ORPHAN_TABLES = 'orphan_tables';

	const PLUGIN_OLD_LOGS = 'plugin_old_logs';

	const ORPHAN_SHORTCODES = 'orphan_shortcodes';

	const ORPHAN_OPTIONS = 'orphan_options';

	const TABLES = 'Tables in the WordPress database';

	const SCHEDULED_HOOK_NAME = 'wpclpro_clean';

	const EXTENSION = '.php';

	const PREFIX = 'class-';

	const DB_STATUS = 'wpclpro_status';

	const DB_STATUS_CLEANING_READY = 'wpclpro_cleaning_ready';

	const TABLE_VERSION = 'wpclpro_table_version';

	const TABLE_VERSION_VALUE = '1.0';

	const LOGS_TABLE_NAME = 'wpclpro_logs';

	const YES = 'yes';

	const NO = 'no';

	const ERROR = 'error';

	const NOTICE = 'notice';

	/**
	 * The path of the file.
	 *
	 * @access private
	 * @var string The plugin path.
	 */
	private static $path = '';

	/**
	 * Plugin namespace.
	 *
	 * @access private
	 * @var string The plugin namespace.
	 */
	private static $namespace = '';

	/**
	 * Sets the plugin path.
	 *
	 * @access public
	 * @param string $path The plugin path.
	 */
	public static function wpclpro_set_path( $path ) {
		self::$path = $path;
	}

	/**
	 * Sets the plugin namespace.
	 *
	 * @access public
	 * @param string $custom_namespace The plugin namespace.
	 * @return void
	 */
	public static function wpclpro_set_namespace( $custom_namespace ) {
		self::$namespace = $custom_namespace;
	}

	/**
	 * Handles the logic to auto-load the class given as parameter.
	 *
	 * @access public
	 * @param string $class_name The class to auto-load.
	 * @return boolean True if the class was loaded, false, otherwise.
	 */
	public static function wpclpro_load( $class_name ) {

		$cls_found = false;
		$namespace = self::$namespace;

		// Check if the class belong to plugin namespace and load it.
		if ( substr( $class_name, 0, strlen( $namespace ) ) === $namespace ) {

			// Extract from class name the real file name.
			$file_name = self::PREFIX . str_replace( '_', '-', strtolower( $class_name ) ) . self::EXTENSION;

			// Get the real path to classes folder inside the plugin folder.
			$classes_dir = realpath( self::$path ) . '/classes/';

			// And deduct the real class path.
			$class_path = $classes_dir . $file_name;

			// The class was found, so include it.
			$cls_found = true;
			include_once $class_path;
		}

		return $cls_found;
	}
}
