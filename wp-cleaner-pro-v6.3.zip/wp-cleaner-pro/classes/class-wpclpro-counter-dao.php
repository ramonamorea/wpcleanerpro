<?php
/**
 * Holds the logic for counting items that can be cleaned.
 *
 * @package    wp-cleaner-pro
 * @author     hevada <support@hevada.com>
 * @copyright  2017-2030 hevada <support@hevada.com>
 * @link       http://codecanyon.net/user/hevada
 * @version    6.3
 * @since      1.0
 */

/**
 * Class that contains the logic for counting items that can be cleaned.
 */
class Wpclpro_Counter_DAO extends Wpclpro_DAO {

	/**
	 * Stores class logger.
	 *
	 * @access
	 * @var Logger
	 */
	private $logger;

	/**
	 * Constructor.
	 *
	 * @access public
	 * @return void
	 */
	public function __construct() {
		Logger::configure( WPCLPRO_PLUGIN_DIR . 'log4php/config.php' );
		$this->logger = Logger::getLogger( __CLASS__ );

		// Initialize the WordPress file system.
		parent::wpclpro_prepare_filesystem();
	}

	/**
	 * Counts trash comments.
	 *
	 * @access public
	 * @return int The number of trash commments.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_count_trash_comments() {
		global $wpdb;

		// phpcs:disable -- ignore direct database access rule.
		$count = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(comment_ID)
				FROM $wpdb->comments
				WHERE comment_approved = %s",
				'trash'
			)
		);
		// phpcs:enable
		return $count;
	}

	/**
	 * Counts spam comments.
	 *
	 * @access public
	 * @return int The number of spam comments.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_count_spam_comments() {
		global $wpdb;

		// phpcs:disable -- ignore direct database access rule.
		$count = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(comment_ID)
				FROM $wpdb->comments
				WHERE comment_approved = %s",
				'spam'
			)
		);
		// phpcs:enable
		return $count;
	}

	/**
	 * Counts the comments waiting for moderation.
	 *
	 * @access public
	 * @return int The number of comments waiting for moderation.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_count_wmoderation() {
		global $wpdb;

		// phpcs:disable -- ignore direct database access rule.
		$count = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(comment_ID)
				FROM $wpdb->comments
				WHERE comment_approved = %s",
				'0'
			)
		);
		// phpcs:enable
		return $count;
	}

	/**
	 * Counts orphan comment meta.
	 *
	 * @access public
	 * @return int The number of orphan comment meta.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_count_orphan_comment_meta() {
		global $wpdb;

		// phpcs:disable -- ignore direct database access rule.
		$count = $wpdb->get_var(
			"SELECT COUNT(meta_id)
			FROM $wpdb->commentmeta
			WHERE comment_id NOT IN
			(SELECT comment_id FROM $wpdb->comments)"
		);
		// phpcs:enable
		return $count;
	}

	/**
	 * Counts duplicated comment meta.
	 *
	 * @access public
	 * @return int The number of duplicated comment meta.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_count_duplicated_comment_meta() {
		global $wpdb;

		// phpcs:disable -- ignore direct database access rule.
		$column = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT COUNT(meta_id) AS total
				FROM $wpdb->commentmeta
				GROUP BY comment_id, meta_key, meta_value
				HAVING total > %d",
				1
			)
		);
		// phpcs:enable

		$count = 0;
		if ( is_array( $column ) ) {
			$count = array_sum( array_map( 'intval', $column ) );
		}

		return $count;
	}

	/**
	 * Counts pingbacks.
	 *
	 * @access public
	 * @return int The number of pingbacks.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_count_pingbacks() {
		global $wpdb;

		// phpcs:disable -- ignore direct database access rule.
		$count = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(comment_ID)
				FROM $wpdb->comments
				WHERE comment_type = %s",
				'pingback'
			)
		);
		// phpcs:enable
		return $count;
	}

	/**
	 * Counts trackbacks.
	 *
	 * @access public
	 * @return int The number of trackbacks.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_count_trackbacks() {
		global $wpdb;

		// phpcs:disable -- ignore direct database access rule.
		$count = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(comment_ID)
				FROM $wpdb->comments
				WHERE comment_type = %s",
				'trackback'
			)
		);
		// phpcs:enable
		return $count;
	}

	/**
	 * Counts drafts.
	 *
	 * @access public
	 * @return int The number of drafts.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_count_drafts() {
		global $wpdb;

		// phpcs:disable -- ignore direct database access rule.
		$count = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(ID)
				FROM $wpdb->posts
				WHERE post_status = %s",
				'draft'
			)
		);
		// phpcs:enable
		return $count;
	}

	/**
	 * Counts auto-drafts.
	 *
	 * @access public
	 * @return int The number of auto-drafts.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_count_auto_drafts() {
		global $wpdb;

		// phpcs:disable -- ignore direct database access rule.
		$count = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(ID)
				FROM $wpdb->posts
				WHERE post_status = %s",
				'auto-draft'
			)
		);
		// phpcs:enable
		return $count;
	}

	/**
	 * Counts revisions.
	 *
	 * @access public
	 * @return int The number of revisions.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_count_revisions() {
		global $wpdb;

		// phpcs:disable -- ignore direct database access rule.
		$count = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(ID)
				FROM $wpdb->posts
				WHERE post_type = %s",
				'revision'
			)
		);
		// phpcs:enable
		return $count;
	}

	/**
	 * Counts trash posts.
	 *
	 * @access public
	 * @return int The number of trash posts.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_count_trash_posts() {
		global $wpdb;

		// phpcs:disable -- ignore direct database access rule.
		$count = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(ID)
				FROM $wpdb->posts
				WHERE post_status = %s",
				'trash'
			)
		);
		// phpcs:enable

		return $count;
	}

	/**
	 * Counts orphan post meta
	 *
	 * @access public
	 * @return int The number of orphan post meta.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_count_orphan_post_meta() {
		global $wpdb;

		// phpcs:disable -- ignore direct database access rule.
		$count = $wpdb->get_var(
			"SELECT COUNT(meta_id)
			FROM $wpdb->postmeta pm
			LEFT JOIN $wpdb->posts posts ON posts.ID = pm.post_id
			WHERE posts.ID IS NULL"
		);
		// phpcs:enable
		return $count;
	}

	/**
	 * Counts old slugs.
	 *
	 * @access public
	 * @return int The number of old slugs.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_count_old_slugs() {
		global $wpdb;

		// Prepare and execute query.
		// phpcs:disable -- ignore direct database access rule.
		$count = $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(meta_id)
			FROM $wpdb->postmeta
			WHERE meta_key=%s", '_wp_old_slug' ));
		// phpcs:enable

		return $count;
	}

	/**
	 * Counts old dates.
	 *
	 * @access public
	 * @return int The number of old dates.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_count_old_dates() {
		global $wpdb;

		// Prepare and execute query.
		// phpcs:disable -- ignore direct database access rule.
		$count = $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(meta_id)
			FROM $wpdb->postmeta
			WHERE meta_key=%s", '_wp_old_date' ));
		// phpcs:enable

		return $count;
	}

	/**
	 * Counts duplicated post meta.
	 *
	 * @access public
	 * @return int The number of duplicated post meta.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_count_duplicated_post_meta() {
		global $wpdb;
		$count = 0;

		// And query the database to find the duplicated post meta.
		// phpcs:disable -- ignore direct database access rule.
		$column = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT COUNT(meta_id) AS total
				FROM $wpdb->postmeta
				GROUP BY post_id, meta_key, meta_value
				HAVING total > %d
				ORDER BY post_id",
				1
			)
		);
		// phpcs:enable

		if ( is_array( $column ) ) {
			$count = array_sum( array_map( 'intval', $column ) );
		}
		return $count;
	}

	/**
	 * Counts orphan term relationships.
	 *
	 * @access public
	 * @return int The number of orphan term relationships.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_count_orphan_term_relationships() {
		global $wpdb;

		// phpcs:disable -- ignore direct database access rule.
		$count = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(object_id)
				FROM $wpdb->term_relationships
				WHERE term_taxonomy_id=%d
				AND object_id NOT IN
				(SELECT id FROM $wpdb->posts)",
				1
			)
		);
		// phpcs:enable
		return $count;
	}

	/**
	 * Counts unused terms.
	 *
	 * @access public
	 * @return int The number of unused terms.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_count_unused_terms() {
		global $wpdb;

		// Get the ids excluded from cleaning.
		$excluded = implode( ',', $this->wpclpro_excluded_term_ids() );

		// Prepare and execute query.
		// phpcs:disable -- ignore direct database access rule.
		$count = $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(t.term_id)
			FROM $wpdb->terms AS t
			INNER JOIN $wpdb->term_taxonomy AS tt
			ON t.term_id = tt.term_id
			WHERE tt.count = %d AND t.term_id NOT IN ( $excluded )", 0 ));
		// phpcs:enable

		return $count;
	}

	/**
	 * Counts duplicated term meta.
	 *
	 * @access public
	 * @return int The number of duplicated term meta.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_count_duplicated_term_meta() {
		global $wpdb;
		$count = 0;

		// phpcs:disable -- ignore direct database access rule.
		$column = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT COUNT(meta_id) AS total
				FROM $wpdb->termmeta
				GROUP BY term_id, meta_key, meta_value
				HAVING total > %d",
				1
			)
		);
		// phpcs:enable

		if ( is_array( $column ) ) {
			$count = array_sum( array_map( 'intval', $column ) );
		}
		return $count;
	}

	/**
	 * Counts expired transients.
	 *
	 * @access public
	 * @return int The number of expired transients.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_count_expired_transients() {
		global $wpdb;
		$count = 0;

		// Get the time right now.
		$now = time();

		// phpcs:disable -- ignore direct database access rule.
		$count = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(option_name) AS TOTAL_EXPIRED
				FROM $wpdb->options
				WHERE option_name LIKE %s
				AND option_value < %d",
				'%_transient_timeout_%',
				$now
			)
		);
		// phpcs:enable
		return $count;
	}

	/**
	 * Counts orphan user meta.
	 *
	 * @access public
	 * @return int The number of orphan user meta.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_count_orphan_user_meta() {
		global $wpdb;

		// phpcs:disable -- ignore direct database access rule.
		$count = $wpdb->get_var(
			"SELECT COUNT(umeta_id)
			FROM $wpdb->usermeta
			WHERE user_id NOT IN
			(SELECT ID FROM $wpdb->users)"
		);
		// phpcs:enable
		return $count;
	}

	/**
	 * Counts duplicated user meta.
	 *
	 * @access public
	 * @return int The number of duplicated user meta.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_count_duplicated_user_meta() {
		global $wpdb;
		$count = 0;

		// And query the database to find duplciaetd user meta.
		// phpcs:disable -- ignore direct database access rule.
		$column = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT COUNT(umeta_id) AS total, meta_key
				FROM $wpdb->usermeta
				GROUP BY user_id, meta_key, meta_value
				HAVING total > %d",
				1
			)
		);
		// phpcs:enable
		if ( is_array( $column ) ) {
			$count = array_sum( array_map( 'intval', $column ) );
		}
		return $count;
	}

	/**
	 * Counts subscribers with invalid emails.
	 *
	 * @access public
	 * @return int The number of subscribers having invalid emails.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_count_subscribers_invalid_email() {
		global $wpdb;
		$count = 0;

		// Valid email regex courtesy of http://emailregex.com/.
		// phpcs:disable -- ignore direct database access rule.
		$count = $wpdb->get_var(
			"SELECT DISTINCT COUNT(ID)
			FROM $wpdb->users AS t1
			INNER JOIN $wpdb->usermeta AS t2
			ON t1.ID = t2.user_id
			WHERE meta_key = 'wp_capabilities'
			AND meta_value  LIKE '%subscriber%'
			AND t1.user_email NOT REGEXP '^[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$'"
		);
		// phpcs:enable
		return $count;
	}

	/**
	 * Counts weird chars in posts.
	 *
	 * @access public
	 * @return int The number of weird chars in posts.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_count_post_weird_chars() {
		global $wpdb;

		// Add wildcards, since we are searching within text.
		$p1 = '%' . $wpdb->esc_like( 'â€œ' ) . '%';
		$p2 = '%' . $wpdb->esc_like( 'â€' ) . '%';
		$p3 = '%' . $wpdb->esc_like( 'â€™' ) . '%';
		$p4 = '%' . $wpdb->esc_like( 'â€˜' ) . '%';
		$p5 = '%' . $wpdb->esc_like( 'â€”' ) . '%';
		$p6 = '%' . $wpdb->esc_like( 'â€“' ) . '%';
		$p7 = '%' . $wpdb->esc_like( 'â€¢' ) . '%';
		$p8 = '%' . $wpdb->esc_like( 'â€¦' ) . '%';

		// Prepare the SQL statement so the string input gets escaped for security and get results.
		// phpcs:disable -- ignore direct database access rule.
		$count = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(ID) FROM $wpdb->posts
				WHERE ( post_content LIKE %s
				OR post_content LIKE %s
				OR post_content LIKE %s
				OR post_content LIKE %s
				OR post_content LIKE %s
				OR post_content LIKE %s
				OR post_content LIKE %s
				OR post_content LIKE %s
				)",
				$p1,
				$p2,
				$p3,
				$p4,
				$p5,
				$p6,
				$p7,
				$p8
			)
		);
		// phpcs:enable
		return $count;
	}

	/**
	 * Counts weird chars in comments.
	 *
	 * @access public
	 * @return int The number of weird chars in comments.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_count_comment_weird_chars() {
		global $wpdb;

		// Add wildcards, since we are searching within text.
		$p1 = '%' . $wpdb->esc_like( 'â€œ' ) . '%';
		$p2 = '%' . $wpdb->esc_like( 'â€' ) . '%';
		$p3 = '%' . $wpdb->esc_like( 'â€™' ) . '%';
		$p4 = '%' . $wpdb->esc_like( 'â€˜' ) . '%';
		$p5 = '%' . $wpdb->esc_like( 'â€”' ) . '%';
		$p6 = '%' . $wpdb->esc_like( 'â€“' ) . '%';
		$p7 = '%' . $wpdb->esc_like( 'â€¢' ) . '%';
		$p8 = '%' . $wpdb->esc_like( 'â€¦' ) . '%';

		// Prepare the SQL statement so the string input gets escaped for security.
		// phpcs:disable -- ignore direct database access rule.
		$count = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(comment_ID) FROM $wpdb->comments
				WHERE ( comment_content LIKE %s
				OR comment_content LIKE %s
				OR comment_content LIKE %s
				OR comment_content LIKE %s
				OR comment_content LIKE %s
				OR comment_content LIKE %s
				OR comment_content LIKE %s
				OR comment_content LIKE %s
				)",
				$p1,
				$p2,
				$p3,
				$p4,
				$p5,
				$p6,
				$p7,
				$p8
			)
		);
		// phpcs:enable

		return $count;
	}

	/**
	 * Counts comment agent.
	 *
	 * @access public
	 * @return int The number of comment agent.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_count_comment_agent() {
		global $wpdb;
		// phpcs:disable -- ignore direct database access rule.
		$count = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(comment_ID)
				FROM $wpdb->comments
				WHERE comment_agent != %s",
				''
			)
		);
		// phpcs:enable
		return $count;
	}

	/**
	 * Counts oembed caches.
	 *
	 * @access public
	 * @return int The number of oembed caches.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_count_oembed_caches() {
		global $wpdb;
		// phpcs:disable -- ignore direct database access rule.
		$count = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(meta_id)
				FROM $wpdb->postmeta
				WHERE meta_key LIKE %s",
				'%_oembed_%'
			)
		);
		// phpcs:enable
		return $count;
	}

	/**
	 * Counts links in the links table.
	 *
	 * @access public
	 * @return int The number of links in links table.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_count_wp_links() {
		global $wpdb;
		// phpcs:disable -- ignore direct database access rule.
		$count = $wpdb->get_var( "SELECT COUNT(link_id) FROM $wpdb->links" );
		// phpcs:enable
		return $count;
	}

	/**
	 * Counts tables in WP database.
	 *
	 * @access public
	 * @return int The number of tables in WP database.
	 * @global wpdb $wpdb
	 */
	public function wpclpro_count_tables() {
		global $wpdb;
		// phpcs:disable -- ignore direct database access rule.
		$count = $wpdb->get_var(
			$wpdb->prepare(
				'SELECT COUNT(*)
				FROM information_schema.tables
				WHERE table_schema=%s',
				$wpdb->dbname
			)
		);
		// phpcs:enable
		return $count;
	}

	/**
	 * Counts orphan tables in WP database.
	 *
	 * @access public
	 * @return int The number of orphan tables in posts, pages in the WP database.
	 */
	public function wpclpro_count_orphan_tables() {

		$orphan_tables = $this->wpclpro_get_orphan_tables();

		if ( empty( $orphan_tables ) ) {
			return 0;
		}

		return count( $orphan_tables );
	}

	/**
	 * Counts plugin's old logs (which are older than 1 month).
	 *
	 * @access public
	 * @return int The number of plugin's old logs (which are over the limit of 100 logs).
	 * @global wpdb $wpdb
	 */
	public function wpclpro_count_plugin_old_logs() {

		global $wpdb;

		// Prepare and execute query.
		// phpcs:disable -- ignore direct database access rule.
		$logs_table = $wpdb->prefix . Wpclpro_Loader::LOGS_TABLE_NAME;
		$count = $wpdb->get_var(
						"SELECT COUNT(a.log_id) 
						 FROM " . $logs_table . "  a " .
						"WHERE a.time < (DATE_SUB(CURDATE(), INTERVAL 1 MONTH))" );
		// phpcs:enable

		return $count;
	}

	/**
	 * Counts orphan shortcodes in posts, pages in the WP database.
	 *
	 * @access public
	 * @return int The number of orphan shortcodes in posts, pages in the WP database.
	 */
	public function wpclpro_count_orphan_shortcodes() {

		$orphan_shortcodes = parent::wpclpro_get_orphan_shortcodes();

		if ( empty( $orphan_shortcodes ) ) {
			return 0;
		}
		return count( $orphan_shortcodes );
	}

	/**
	 * Counts orphan options in the WP database, in the wp_options table.
	 *
	 * @access public
	 * @return int The number of orphan options in the WP database.
	 */
	public function wpclpro_count_orphan_options() {

		$orphan_options = parent::wpclpro_get_orphan_options();

		if ( empty( $orphan_options ) ) {
			return 0;
		}
		return count( $orphan_options );
	}
}
