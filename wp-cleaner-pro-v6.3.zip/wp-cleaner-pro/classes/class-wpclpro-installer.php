<?php
/**
 * Holds the logic to install and uninstall the plugin.
 *
 * @package    wp-cleaner-pro
 * @author     hevada <support@hevada.com>
 * @copyright  2017-2030 hevada <support@hevada.com>
 * @link       http://codecanyon.net/user/hevada
 * @version    6.3
 * @since      1.0
 */

/**
 * Class that contains the logic to install and uninstall the plugin.
 */
class Wpclpro_Installer {

	/**
	 * Takes the neccessary steps for plugin's installation.
	 * The steps are:
	 * 1. create a custom table to save plugin logs
	 * 2. create a custom table version for easier database upgrades.
	 *
	 * The plugin, during its functionality, also creates five options in the wp_options table:
	 * 'wpclpro_db_key'
	 * 'wpclpro_clean_items'
	 * 'wpclpro_clean_frequency'
	 * 'wpclpro_size_cleaned'
	 * 'wpclpro_table_version'
	 *
	 * These options that the plugin creates, will be deleted on plugin uninstall.
	 *
	 * @access public
	 * @return void
	 * @global wpdb $wpdb The global WP database object.
	 */
	public function wpclpro_install() {
		global $wpdb;

		// Create the custom table where the plugin will save the logs.
		$logs_table = $wpdb->prefix . Wpclpro_Loader::LOGS_TABLE_NAME;

		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE $logs_table (
    		log_id bigint(20) UNSIGNED NOT NULL auto_increment,
    		time datetime NOT NULL,
    		classname tinytext NOT NULL,
    		line smallint(5) UNSIGNED NOT NULL,
    		level tinytext NOT NULL,
    		message text NOT NULL,
    		PRIMARY KEY  (log_id)
    	) $charset_collate;";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );

		// Save the version of logs table in the database, for easier database upgrades.
		update_option( 'wpclpro_table_version', Wpclpro_Loader::TABLE_VERSION_VALUE );
	}

	/**
	 * Takes the necessary steps for plugin's deactivation.
	 * The steps for deactivation are:
	 * 1. Unschedule any event that the plugin has scheduled.
	 * 2. (Then, the plugin will be deactivated by the system).
	 *
	 * @access public
	 * @return void
	 * @global wpdb $wpdb The global WP database object.
	 */
	public function wpclpro_deactivate() {

		// First, on deactivation, unschedule everything.
		$controller = new Wpclpro_Controller();
		$controller->wpclpro_action_unschedule();
	}

	/**
	 * Takes the necessary steps for plugin's unistallation.
	 * The steps are:
	 * 1. Unschedule any event that the plugin has scheduled and entries created in wp_options table.
	 * 2. Delete all the backups created by the plugin.
	 * 3. Delete from the the wp_options table the key used to protect the backups dir created by plugin.
	 * 4. Delete the custom table where the plugin saved the plugin logs.
	 * 5. Delete logging table version from the wp_options table from the database.
	 *
	 * @access public
	 * @return void
	 * @global wpdb $wpdb The global WP database object.
	 */
	public function wpclpro_uninstall() {

		// 1. First, unschedule everything (this also deletes options that plugin created in wp_options table):
		// * 'wpclpro_clean_items'
		// * 'wpclpro_clean_frequency'
		// * 'wpclpro_size_cleaned'
		$controller = new Wpclpro_Controller();
		$controller->wpclpro_action_unschedule();

		// 2. And delete all already created backups.
		$backupper = new Wpclpro_Backupper_DAO();
		$backupper->wpclpro_delete_all_backups();

		// 3. Also delete from the the wp_options table the key used to protect the backups dir created by plugin.
		delete_option( 'wpclpro_db_key' );

		// 4. Delete the custom table where the plugin saved the plugin logs.
		global $wpdb;
		$table_name = $wpdb->prefix . Wpclpro_Loader::LOGS_TABLE_NAME;
		// phpcs:disable -- ignore direct database access rule.
		$wpdb->query( $wpdb->prepare( 'DROP TABLE IF EXISTS ' . $table_name . ';' ) );
		// phpcs:enable

		// 5. And delete logging table version from the wp_options table from the database.
		delete_option( 'wpclpro_table_version' );
	}
}
