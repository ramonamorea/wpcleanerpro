<?php
/**
 * Holds the logic for cleaning the selected items from the database.
 *
 * @package    wp-cleaner-pro
 * @author     hevada <support@hevada.com>
 * @copyright  2017-2030 hevada <support@hevada.com>
 * @link       http://codecanyon.net/user/hevada
 * @version    6.3
 * @since      1.0
 */

/**
 * Class that contains the logic to clean selected database items.
 */
class Wpclpro_Cleaner_DAO extends Wpclpro_DAO {

	/**
	 * Stores the class logger.
	 *
	 * @access private
	 * @var Logger
	 */
	private $logger;

	/**
	 * Constructor.
	 *
	 * @access public
	 * @return void
	 */
	public function __construct() {
		// Initialize class logger.
		Logger::configure( WPCLPRO_PLUGIN_DIR . 'log4php/config.php' );
		$this->logger = Logger::getLogger( __CLASS__ );

		// Initialize file system.
		parent::wpclpro_prepare_filesystem();
	}

	/**
	 * Logs the cleaning of data.
	 *
	 * @access private
	 * @param string $clean A parameter indicating if a cleaning was successful or not.
	 * @param string $message The message to be saved in the logs table in the case when the cleaning was successful.
	 * @return void
	 * @throws Exception Throws an exception when a database occurs.
	 * @global wpdb $wpdb
	 */
	private function wpclpro_log( $clean, $message ) {
		// Log an error/success message, depending of the $clean parameter.
		global $wpdb;
		if ( false === $clean && '' !== trim( $wpdb->last_error ) ) {
			$this->logger->log( LoggerLevel::getLevelError(), $wpdb->last_error );
			throw new Exception(
				wp_kses(
					/* translators: %s: an error message */
					__(
						'Error: %s',
						'wpclpro'
					),
					$wpdb->last_error
				)
			);
		} else {
			$this->logger->log( LoggerLevel::getLevelInfo(), $message );
		}
	}

	/**
	 * Deletes trash comments.
	 *
	 * @access private
	 * @return void
	 * @global wpdb $wpdb
	 */
	private function wpclpro_delete_trash_comments() {
		global $wpdb;

		// Delete trash comments.
		// phpcs:disable -- ignore direct database access rule.
		$clean = $wpdb->query( $wpdb->prepare( "DELETE FROM $wpdb->comments WHERE comment_approved = %s", 'trash' ) );
		// phpcs:enable

		// Clean leftovers.
		$this->wpclpro_delete_orphan_comment_meta();

		// Log if the delete was successful or not.
		$this->wpclpro_log( $clean, 'The trash comments were successfully deleted.' );
	}

	/**
	 * Deletes spam comments.
	 *
	 * @access private
	 * @return void
	 * @global wpdb $wpdb
	 */
	private function wpclpro_delete_spam_comments() {
		global $wpdb;

		// Delete spam comments.
		// phpcs:disable -- ignore direct database access rule.
		$clean = $wpdb->query( $wpdb->prepare( "DELETE FROM $wpdb->comments WHERE comment_approved = %s", 'spam' ) );
		// phpcs:enable

		// Clean leftovers.
		$this->wpclpro_delete_orphan_comment_meta();

		// Log if the delete was successful or not.
		$this->wpclpro_log( $clean, 'The spam comments were successfully deleted.' );
	}

	/**
	 * Deletes waiting for moderation comments.
	 *
	 * @access private
	 * @return void
	 * @global wpdb $wpdb
	 */
	private function wpclpro_delete_wmoderation() {
		global $wpdb;

		// Delete waiting for moderation comments.
		// phpcs:disable -- ignore direct database access rule.
		$clean = $wpdb->query( $wpdb->prepare( "DELETE FROM $wpdb->comments WHERE comment_approved = %s", '0' ) );
		// phpcs:enable

		// Clean leftovers.
		$this->wpclpro_delete_orphan_comment_meta();

		// Log if the delete was successful or not.
		$this->wpclpro_log( $clean, 'The comments waiting for moderation were successfully deleted.' );
	}

	/**
	 * Deletes orphan comment meta.
	 *
	 * @access private
	 * @return void
	 * @global wpdb $wpdb
	 */
	private function wpclpro_delete_orphan_comment_meta() {
		global $wpdb;

		// Delete orphan comment meta.
		// phpcs:disable -- ignore direct database access rule.
		$clean = $wpdb->query(
			"DELETE FROM $wpdb->commentmeta
			WHERE comment_id
			NOT IN (SELECT comment_id FROM $wpdb->comments)"
		);
		// phpcs:enable

		// Log if the delete was successful or not.
		$this->wpclpro_log( $clean, 'The orphan comment meta were successfully deleted.' );
	}

	/**
	 * Deletes duplicated comment meta.
	 *
	 * @access private
	 * @return void
	 * @global wpdb $wpdb
	 */
	private function wpclpro_delete_duplicated_comment_meta() {
		global $wpdb;

		// Select all comment meta.
		$clean = false;
		// phpcs:disable -- ignore direct database access rule.
		$metas = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT GROUP_CONCAT(meta_id ORDER BY meta_id DESC) AS ids, comment_id, COUNT(*) AS total
				FROM $wpdb->commentmeta
				GROUP BY comment_id, meta_key, meta_value
				HAVING total > %d",
				1
			)
		);
		// phpcs:enable

		// Delete duplicated comment meta.
		if ( $metas ) {
			foreach ( $metas as $meta ) {
				$mids = array_map( 'intval', explode( ',', $meta->ids ) );
				array_pop( $mids );
				$array = implode( ',', $mids );

				// phpcs:disable -- ignore direct database access rule.
				$clean = $wpdb->query( $wpdb->prepare(
					"DELETE
					FROM $wpdb->commentmeta
					WHERE meta_id IN ( $array )
					AND comment_id = %d", intval( $meta->comment_id ) ) );
				// phpcs:enable
			}
		}

		// Clean leftovers.
		$this->wpclpro_delete_orphan_comment_meta();

		// Log if the delete was successful or not.
		$this->wpclpro_log( $clean, 'The duplicated comment meta were successfully deleted.' );
	}

	/**
	 * Deletes pingbacks.
	 *
	 * @access private
	 * @return void
	 * @global wpdb $wpdb
	 */
	private function wpclpro_delete_pingbacks() {
		global $wpdb;

		// Delete pingbacks.
		// phpcs:disable -- ignore direct database access rule.
		$clean = $wpdb->query( $wpdb->prepare( "DELETE FROM $wpdb->comments WHERE comment_type = %s", 'pingback' ) );
		// phpcs:enable

		// Clean leftovers.
		$this->wpclpro_delete_orphan_comment_meta();

		// Log if the delete was successful or not.
		$this->wpclpro_log( $clean, 'The pingbacks were successfully deleted.' );
	}

	/**
	 * Deletes trackbacks.
	 *
	 * @access private
	 * @return void
	 * @global wpdb $wpdb
	 */
	private function wpclpro_delete_trackbacks() {
		global $wpdb;

		// Delete trackbacks.
		// phpcs:disable -- ignore direct database access rule.
		$clean = $wpdb->query( $wpdb->prepare( "DELETE FROM $wpdb->comments WHERE comment_type = %s", 'trackback' ) );
		// phpcs:enable

		// Clean leftovers.
		$this->wpclpro_delete_orphan_comment_meta();

		// Log if the delete was successful or not.
		$this->wpclpro_log( $clean, 'The trackbacks were successfully deleted.' );
	}

	/**
	 * Deletes draft posts.
	 *
	 * @access private
	 * @return void
	 * @global wpdb $wpdb
	 */
	private function wpclpro_delete_drafts() {
		global $wpdb;

		// Delete drafts.
		// phpcs:disable -- ignore direct database access rule.
		$clean = $wpdb->query( $wpdb->prepare( "DELETE FROM $wpdb->posts WHERE post_status = %s", 'draft' ) );
		// phpcs:enable

		// Clean leftovers.
		$this->wpclpro_delete_orphan_post_meta();

		// Log if the delete was successful or not.
		$this->wpclpro_log( $clean, 'The drafts were successfully deleted.' );
	}

	/**
	 * Deletes auto-drafts.
	 *
	 * @access private
	 * @return void
	 * @global wpdb $wpdb
	 */
	private function wpclpro_delete_auto_drafts() {
		global $wpdb;

		// Delete auto-drafts.
		// phpcs:disable -- ignore direct database access rule.
		$clean = $wpdb->query( $wpdb->prepare( "DELETE FROM $wpdb->posts WHERE post_status = %s", 'auto-draft' ) );
		// phpcs:enable

		// Clean leftovers.
		$this->wpclpro_delete_orphan_post_meta();

		// Log if the delete was successful or not.
		$this->wpclpro_log( $clean, 'The autodrafts were successfully deleted.' );
	}

	/**
	 * Deletes revisions.
	 *
	 * @access private
	 * @return void
	 * @global wpdb $wpdb
	 */
	private function wpclpro_delete_revisions() {
		global $wpdb;

		// Delete revisions.
		// phpcs:disable -- ignore direct database access rule.
		$clean = $wpdb->query( $wpdb->prepare( "DELETE FROM $wpdb->posts WHERE post_type = %s", 'revision' ) );
		// phpcs:enable

		// Clean leftovers.
		$this->wpclpro_delete_orphan_post_meta();

		// Log if the delete was successful or not.
		$this->wpclpro_log( $clean, 'The revisions were successfully deleted.' );
	}

	/**
	 * Deletes trash posts.
	 *
	 * @access private
	 * @return void
	 * @global wpdb $wpdb
	 */
	private function wpclpro_delete_trash_posts() {
		global $wpdb;

		// Delete trash posts.
		// phpcs:disable -- ignore direct database access rule.
		$clean = $wpdb->query( $wpdb->prepare( "DELETE FROM $wpdb->posts WHERE post_status = %s", 'trash' ) );
		// phpcs:enable

		// Clean leftovers.
		$this->wpclpro_delete_orphan_post_meta();

		// Log if the delete was successful or not.
		$this->wpclpro_log( $clean, 'The trash posts were deleted.' );
	}

	/**
	 * Deletes orphan post meta.
	 *
	 * @access private
	 * @return void
	 * @global wpdb $wpdb
	 */
	private function wpclpro_delete_orphan_post_meta() {
		global $wpdb;

		// Delete orphan post meta.
		// phpcs:disable -- ignore direct database access rule.
		$clean = $wpdb->query(
			"DELETE pm
			FROM $wpdb->postmeta pm
			LEFT JOIN $wpdb->posts wp
			ON wp.ID = pm.post_id
			WHERE wp.ID IS NULL"
		);
		// phpcs:enable

		// Log if the delete was successful or not.
		$this->wpclpro_log( $clean, 'The orphan post meta were successfully deleted.' );
	}

	/**
	 * Deletes old slugs.
	 *
	 * @access private
	 * @return void
	 * @global wpdb $wpdb
	 */
	private function wpclpro_delete_old_slugs() {
		global $wpdb;

		// Delete old slugs.
		// phpcs:disable -- ignore direct database access rule.
		$clean = $wpdb->query(
			$wpdb->prepare(
				"DELETE
				FROM $wpdb->postmeta
				WHERE meta_key=%s",
				'_wp_old_slug'
				)
			);
		// phpcs:enable

		// Log if the delete was successful or not.
		$this->wpclpro_log( $clean, 'The old slugs were successfully deleted.' );
	}

	/**
	 * Deletes old dates.
	 *
	 * @access private
	 * @return void
	 * @global wpdb $wpdb
	 */
	private function wpclpro_delete_old_dates() {
		global $wpdb;

		// Delete old dates.
		// phpcs:disable -- ignore direct database access rule.
		$clean = $wpdb->query(
			$wpdb->prepare(
				"DELETE
				FROM $wpdb->postmeta
				WHERE meta_key=%s",
				'_wp_old_date'
				)
			);
		// phpcs:enable

		// Log if the delete was successful or not.
		$this->wpclpro_log( $clean, 'The old dates were successfully deleted.' );
	}

	/**
	 * Deletes plugin old logs (older than 1 month).
	 *
	 * @access private
	 * @return void
	 * @global wpdb $wpdb
	 */
	private function wpclpro_delete_plugin_old_logs() {
		global $wpdb;
		$logs_table = $wpdb->prefix . Wpclpro_Loader::LOGS_TABLE_NAME;

		// Delete plugin old logs.
		// phpcs:disable -- ignore direct database access rule.
		$clean = $wpdb->query(
				"DELETE
				FROM " . $logs_table . " 
				WHERE time < (DATE_SUB(CURDATE(), INTERVAL 1 MONTH))" 
		);
		// phpcs:enable

		// Log if the delete was successful or not.
		$this->wpclpro_log( $clean, 'The plugin old logs were successfully deleted.' );
	}

	/**
	 * Deletes duplicated post meta.
	 *
	 * @access private
	 * @return void
	 * @global wpdb $wpdb
	 */
	private function wpclpro_delete_duplicated_post_meta() {
		global $wpdb;

		// Delete duplicated post meta.
		$clean = false;
		// phpcs:disable -- ignore direct database access rule.
		$metas = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT GROUP_CONCAT(meta_id ORDER BY meta_id DESC) AS ids, post_id, COUNT(*) AS total
				FROM $wpdb->postmeta
				GROUP BY post_id, meta_key, meta_value
				HAVING total > %d",
				1
			)
		);
		// phpcs:enable

		if ( $metas ) {
			foreach ( $metas as $meta ) {
				$ids = array_map( 'intval', explode( ',', $meta->ids ) );
				array_pop( $ids );

				$array = implode( ',', $ids );

				// phpcs:disable -- ignore direct database access rule.
				$clean = $wpdb->query( $wpdb->prepare(
					"DELETE
					FROM $wpdb->postmeta
					WHERE meta_id IN ( $array )
					AND post_id = %d", intval( $meta->post_id ) ) );
				// phpcs:enable
			}
		}

		// Clean leftovers.
		$this->wpclpro_delete_orphan_post_meta();

		// Log if the delete was successful or not.
		$this->wpclpro_log( $clean, 'The duplicated post meta were successfully deleted.' );
	}

	/**
	 * Deletes orphan term relationships.
	 *
	 * @access private
	 * @return void
	 * @global wpdb $wpdb
	 */
	private function wpclpro_delete_orphan_term_relationships() {
		global $wpdb;

		// Delete orphan term relationships.
		// phpcs:disable -- ignore direct database access rule.
		$clean = $wpdb->query(
			$wpdb->prepare(
				"DELETE
				FROM $wpdb->term_relationships
				WHERE term_taxonomy_id= %d
				AND object_id NOT IN
				(SELECT id FROM $wpdb->posts)",
				1
			)
		);
		// phpcs:enable

		// Log if the delete was successful or not.
		$this->wpclpro_log( $clean, 'The orphan term relationships were successfully deleted.' );
	}

	/**
	 * Deletes unused terms.
	 *
	 * @access private
	 * @return void
	 * @global wpdb $wpdb
	 */
	private function wpclpro_delete_unused_terms() {
		// Delete unused terms.
		global $wpdb;
		$clean = false;

		// Excluded from delete ids.
		$exids = implode( ',', $this->wpclpro_excluded_term_ids() );

		// phpcs:disable -- ignore direct database access rule.
		$terms = $wpdb->get_results( $wpdb->prepare(
			"SELECT tt.term_taxonomy_id, t.term_id, tt.taxonomy FROM $wpdb->terms AS t
			INNER JOIN $wpdb->term_taxonomy AS tt ON t.term_id = tt.term_id
			WHERE tt.count = %d AND t.term_id
			NOT IN ( $exids )", 0 ) );
		// phpcs:enable

		if ( null !== $terms && ! empty( $terms ) ) {
			// Flag showing if invalid taxonomies exist.
			$inval = false;

			foreach ( $terms as $taxonomy ) {
				if ( taxonomy_exists( $taxonomy->taxonomy ) ) {
					$clean = wp_delete_term( intval( $taxonomy->term_id ), $taxonomy->taxonomy );
				} else {
					// phpcs:disable -- ignore direct database access rule.
					$clean = $wpdb->query(
						$wpdb->prepare(
							"DELETE
							FROM $wpdb->term_taxonomy
							WHERE term_taxonomy_id = %d",
							intval(
								$taxonomy->term_taxonomy_id
							)
						)
					);
					// phpcs:enable
					$inval = true;
				}
			}
			// Taxonomies which are invalid.
			if ( $inval ) {
				// phpcs:disable -- ignore direct database access rule.
				$clean = $wpdb->query(
					"DELETE
					FROM $wpdb->terms
					WHERE term_id
					NOT IN (SELECT term_id FROM $wpdb->term_taxonomy)"
				);
				// phpcs:enable
			}
		}

		// Clean leftovers.
		$this->wpclpro_delete_orphan_term_relationships();

		// Clean all leftovers if any.
		$dao   = new Wpclpro_Counter_DAO();
		$count = $dao->wpclpro_count_unused_terms();
		if ( '0' !== $count ) {
			$this->wpclpro_delete_unused_terms();
		}

		// Log if the delete was successful or not.
		$this->wpclpro_log( $clean, 'The unused terms were successfully deleted.' );
	}

	/**
	 * Deletes duplicated term meta.
	 *
	 * @access private
	 * @return void
	 * @global wpdb $wpdb
	 */
	private function wpclpro_delete_duplicated_term_meta() {
		// Find all term meta first.
		global $wpdb;
		$clean = false;

		// phpcs:disable -- ignore direct database access rule.
		$metas = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT GROUP_CONCAT(meta_id ORDER BY meta_id DESC) AS ids,
            	term_id, COUNT(*) AS total
            	FROM $wpdb->termmeta
            	GROUP BY term_id, meta_key, meta_value
            	HAVING total > %d",
				1
			)
		);
		// phpcs:enable

		// And then delete all duplicates from term meta.
		if ( $metas ) {
			foreach ( $metas as $meta ) {
				$ids = array_map( 'intval', explode( ',', $meta->ids ) );
				array_pop( $ids );
				$array = implode( ',', $ids );

				// phpcs:disable -- ignore direct database access rule.
				$clean = $wpdb->query( $wpdb->prepare(
					"DELETE
					FROM $wpdb->termmeta
					WHERE meta_id IN ( $array )
					AND term_id = %d", intval( $meta->term_id ) ) );
				// phpcs:enable
			}
		}

		// Clean leftovers.
		$this->wpclpro_delete_orphan_term_relationships();

		// Log if the delete was successful or not.
		$this->wpclpro_log( $clean, 'The duplicated term meta were successfully deleted.' );
	}

	/**
	 * Deletes expired transients.
	 *
	 * @access private
	 * @return void
	 * @global wpdb $wpdb
	 */
	private function wpclpro_delete_expired_transients() {
		global $wpdb;
		$now   = time();
		$clean = false;

		// Delete expired transients.
		// phpcs:disable -- ignore direct database access rule.
		$clean = $wpdb->query(
			$wpdb->prepare(
				"DELETE FROM $wpdb->options
				WHERE option_name LIKE %s
				AND option_value < %d",
				'%_transient_timeout_%',
				$now
			)
		);
		// phpcs:enable

		// Log if the delete was successful or not.
		$this->wpclpro_log( $clean, 'The expired transients were successfully deleted.' );
	}

	/**
	 * Deletes orphan user meta data.
	 *
	 * @access private
	 * @return void
	 * @global wpdb $wpdb
	 */
	private function wpclpro_delete_orphan_user_meta() {
		global $wpdb;
		$clean = false;

		// Find all user meta first.
		// phpcs:disable -- ignore direct database access rule.
		$metas = $wpdb->get_results(
			"SELECT user_id, meta_key
			FROM $wpdb->usermeta
			WHERE user_id NOT IN
    		(SELECT ID FROM $wpdb->users)"
		);
		// phpcs:enable

		// Then delete orphan user meta.
		if ( $metas ) {
			foreach ( $metas as $meta ) {
				$user_id = intval( $meta->user_id );

				// phpcs:disable -- ignore direct database access rule.
				$clean   = $wpdb->query(
					$wpdb->prepare(
						"DELETE
						FROM $wpdb->usermeta
						WHERE user_id = %d
						AND meta_key = %s",
						$user_id,
						$meta->meta_key
					)
				);
				// phpcs:enable
			}
		}

		// Log if the delete was successful or not.
		$this->wpclpro_log( $clean, 'The orphan user meta were successfuly deleted.' );
	}

	/**
	 * Deletes duplicated user meta.
	 *
	 * @access private
	 * @return void
	 * @global wpdb $wpdb
	 */
	private function wpclpro_delete_duplicated_user_meta() {
		global $wpdb;
		$clean = false;

		// Find all user meta first.
		// phpcs:disable -- ignore direct database access rule.
		$metas = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT GROUP_CONCAT(umeta_id ORDER BY umeta_id DESC) AS ids, user_id, COUNT(*) AS count
				FROM $wpdb->usermeta
				GROUP BY user_id, meta_key, meta_value
				HAVING count > %d",
				1
			)
		);
		// phpcs:enable

		// Then delete duplicated user meta.
		if ( $metas ) {
			foreach ( $metas as $meta ) {
				$ids = array_map( 'intval', explode( ',', $meta->ids ) );
				array_pop( $ids );
				$u_ids = implode( ',', $ids );

				// phpcs:disable -- ignore direct database access rule.
				$clean = $wpdb->query(
					$wpdb->prepare(
						"DELETE
						FROM $wpdb->usermeta
						WHERE umeta_id IN ( $u_ids)
    					AND user_id = %d", intval( $meta->user_id ) ) );
				// phpcs:enable
			}
		}

		// Clean leftovers.
		$this->wpclpro_delete_orphan_user_meta();

		// Log if the delete was successful or not.
		$this->wpclpro_log( $clean, 'The duplicated user meta were successfully deleted.' );
	}

	/**
	 * Deletes subscribers with invalid email.
	 *
	 * @access private
	 * @return void
	 * @global wpdb $wpdb
	 * */
	private function wpclpro_delete_subscribers_invalid_email() {
		global $wpdb;

		// Then, for each subscriber, delete the subscriber if their address is not valid.
		global $wpdb;
		$clean = false;
		// phpcs:disable -- ignore direct database access rule.
		$clean = $wpdb->query(
			"DELETE t1
			FROM $wpdb->users AS t1
			INNER JOIN $wpdb->usermeta AS t2
			ON t1.ID = t2.user_id
			WHERE meta_key = 'wp_capabilities'
			AND meta_value  LIKE '%subscriber%'
			AND t1.user_email NOT REGEXP '^[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$'"
			);
		// phpcs:enable

		// Clean leftovers.
		$this->wpclpro_delete_orphan_user_meta();

		// Log if the delete was successful or not.
		$this->wpclpro_log( $clean, 'The subscribers with invalid email were successfully deleted.' );
	}

	/**
	 * Deletes weird characters from posts.
	 *
	 * @access private
	 * @return void
	 * @global wpdb $wpdb
	 */
	private function wpclpro_delete_post_weird_chars() {
		$clean = true;
		global $wpdb;

		// Delete weird characters from posts.
		// phpcs:disable -- ignore direct database access rule.
		$clean = $wpdb->query(
			$wpdb->prepare(
				"UPDATE $wpdb->posts
				SET post_content = REPLACE(post_content, %s, %s)",
				'â€œ',
				'"'
			)
		);

		$clean = $wpdb->query(
			$wpdb->prepare(
				"UPDATE $wpdb->posts
				SET post_content = REPLACE(post_content, %s, %s)",
				'â€',
				'"'
			)
		);

		$clean = $wpdb->query(
			$wpdb->prepare(
				"UPDATE $wpdb->posts
				SET post_content = REPLACE(post_content, %s, %s)",
				'â€™',
				"'"
			)
		);

		$clean = $wpdb->query(
			$wpdb->prepare(
				"UPDATE $wpdb->posts
				SET post_content = REPLACE(post_content, %s, %s)",
				'â€˜',
				"'"
			)
		);

		$clean = $wpdb->query(
			$wpdb->prepare(
				"UPDATE $wpdb->posts
				SET post_content = REPLACE(post_content, %s, %s)",
				'â€”',
				'–'
			)
		);

		$clean = $wpdb->query(
			$wpdb->prepare(
				"UPDATE $wpdb->posts
				SET post_content = REPLACE(post_content, %s, %s)",
				'â€“',
				'—'
			)
		);

		$clean = $wpdb->query(
			$wpdb->prepare(
				"UPDATE $wpdb->posts
				SET post_content = REPLACE(post_content, %s, %s)",
				'â€¢',
				'-'
			)
		);

		$clean = $wpdb->query(
			$wpdb->prepare(
				"UPDATE $wpdb->posts
				SET post_content = REPLACE(post_content, %s, %s)",
				'â€¦',
				'…'
			)
		);
		// phpcs:enable

		// Clean leftovers.
		$this->wpclpro_delete_orphan_post_meta();

		// Log if the delete was successful or not.
		$this->wpclpro_log( $clean, 'The weird characters were deleted from posts.' );
	}

	/**
	 * Deletes weird characters from comments.
	 *
	 * @access private
	 * @return void
	 * @global wpdb $wpdb
	 */
	private function wpclpro_delete_comment_weird_chars() {
		$clean = true;
		global $wpdb;

		// Delete weird characters from comments.
		// phpcs:disable -- ignore direct database access rule.
		$clean = $wpdb->query(
			$wpdb->prepare(
				"UPDATE $wpdb->comments
				SET comment_content = REPLACE(comment_content, %s, %s)",
				'â€œ',
				'"'
			)
		);

		$clean = $wpdb->query(
			$wpdb->prepare(
				"UPDATE $wpdb->comments
				SET comment_content = REPLACE(comment_content, %s, %s)",
				'â€',
				'"'
			)
		);

		$clean = $wpdb->query(
			$wpdb->prepare(
				"UPDATE $wpdb->comments
				SET comment_content = REPLACE(comment_content, %s, %s)",
				'â€™',
				"'"
			)
		);

		$clean = $wpdb->query(
			$wpdb->prepare(
				"UPDATE $wpdb->comments
				SET comment_content = REPLACE(comment_content, %s, %s)",
				'â€˜',
				"'"
			)
		);

		$clean = $wpdb->query(
			$wpdb->prepare(
				"UPDATE $wpdb->comments
				SET comment_content = REPLACE(comment_content, %s, %s)",
				'â€”',
				'–'
			)
		);

		$clean = $wpdb->query(
			$wpdb->prepare(
				"UPDATE $wpdb->comments
				SET comment_content = REPLACE(comment_content, %s, %s)",
				'â€“',
				'—'
			)
		);

		$clean = $wpdb->query(
			$wpdb->prepare(
				"UPDATE $wpdb->comments
				SET comment_content = REPLACE(comment_content, %s, %s)",
				'â€¢',
				'-'
			)
		);

		$clean = $wpdb->query(
			$wpdb->prepare(
				"UPDATE $wpdb->comments
				SET comment_content = REPLACE(comment_content, %s, %s)",
				'â€¦',
				'…'
			)
		);
		// phpcs:enable

		// Clean leftovers.
		$this->wpclpro_delete_orphan_comment_meta();

		// Log if the delete was successful or not.
		$this->wpclpro_log( $clean, 'The weird characters were deleted from comments.' );
	}

	/**
	 * Deletes comment agent.
	 *
	 * @access private
	 * @return void
	 * @global wpdb $wpdb
	 */
	private function wpclpro_delete_comment_agent() {
		global $wpdb;

		// Delete comment agent.
		// phpcs:disable -- ignore direct database access rule.
		$clean = $wpdb->query( "UPDATE $wpdb->comments SET comment_agent = '' " );
		// phpcs:enable

		// Clean leftovers.
		$this->wpclpro_delete_orphan_comment_meta();

		// Log if the delete was successful or not.
		$this->wpclpro_log( $clean, 'The comment agent values were deleted from comments.' );
	}

	/**
	 * Deletes oembed caches.
	 *
	 * @access private
	 * @return void
	 * @global wpdb $wpdb
	 */
	private function wpclpro_delete_oembed_caches() {
		global $wpdb;
		$clean = false;

		// Find all oembed caches first.
		// phpcs:disable -- ignore direct database access rule.
		$caches = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT post_id, meta_key
				FROM $wpdb->postmeta
				WHERE meta_key LIKE %s",
				'%_oembed_%'
			)
		);
		// phpcs:enable

		// Then delete oembed caches one by one.
		if ( $caches ) {
			foreach ( $caches as $meta ) {
				$post_id = intval( $meta->post_id );
				if ( 0 === $post_id ) {
					// phpcs:disable -- ignore direct database access rule.
					$clean = $wpdb->query(
						$wpdb->prepare(
							"DELETE
							FROM $wpdb->postmeta
							WHERE post_id = %d
							AND meta_key = %s",
							$post_id,
							$meta->meta_key
						)
					);
					// phpcs:enable
				} else {
					$clean = delete_post_meta( $post_id, $meta->meta_key );
				}
			}
		}

		// Clean leftovers.
		$this->wpclpro_delete_orphan_post_meta();

		// Log if the delete was successful or not.
		$this->wpclpro_log( $clean, 'The oEmbed caches were deleted from posts meta.' );
	}

	/**
	 * Deletes links from table wp_links.
	 *
	 * @access private
	 * @return void
	 * @global wpdb $wpdb
	 */
	private function wpclpro_delete_wp_links() {
		global $wpdb;

		// Delete links from links table.
		// phpcs:disable -- ignore direct database access rule.
		$clean = $wpdb->query( "DELETE FROM $wpdb->links" );
		// phpcs:enable

		// Log if the delete was successful or not.
		$this->wpclpro_log( $clean, 'The links in WP_LINKS table were successfully deleted.' );
	}

	/**
	 * Deletes orphan tables.
	 *
	 * @access private
	 * @return void
	 * @global wpdb $wpdb
	 */
	private function wpclpro_delete_orphan_tables() {
		global $wpdb;

		// The list of all tables that are orphan. We will delete each orphan table, one by one.
		$orphan_tables = $this->wpclpro_get_orphan_tables();

		// If the list of orphan tables is empty, just exit.
		if ( empty( $orphan_tables ) ) {
			return;
		}

		foreach ( $orphan_tables as $orphan_table ) {
			// phpcs:disable -- ignore direct database access rule.
			$clean = $wpdb->query( 'DROP TABLE  IF EXISTS ' . $wpdb->prefix . $orphan_table);
			// Repeat the query, but without the wp prefix, because some plugins/themes create tables with other prefix.
			$clean = $wpdb->query( 'DROP TABLE  IF EXISTS ' . $orphan_table);
			// phpcs:enable
		}

		// Log if the delete was successful or not.
		$this->wpclpro_log( $clean, 'All orphan tables were deleted.' );
	}

	/**
	 * Deletes orphan shortcodes from posts/pages.
	 *
	 * @access private
	 * @return void
	 */
	private function wpclpro_delete_orphan_shortcodes() {

		// First get all orphan shortcodes.
		$orphans = parent::wpclpro_get_orphan_shortcodes();

		// If the list of orphan shortcodes is empty, just exit.
		if ( empty( $orphans ) ) {
			return;
		}

		foreach ( $orphans as $orphan ) {

			$post = get_post( $orphan['post_id'] );

			if ( $post ) {
				$content = $post->post_content;

				global $shortcode_tags;

				// Check for active shortcodes.
				$active_shortcodes = ( is_array( $shortcode_tags ) && ! empty( $shortcode_tags ) ) ? array_keys( $shortcode_tags ) : array();

				// Avoid "/" chars in content breaks preg_replace.
				$hack1   = md5( microtime( true ) );
				$content = str_replace( '[/', $hack1, $content );
				$hack2   = md5( microtime( true ) + 1 );
				$content = str_replace( '/', $hack2, $content );
				$content = str_replace( $hack1, '[/', $content );

				if ( ! empty( $active_shortcodes ) ) {
					// Be sure to keep active shortcodes.
					$keep_active = implode( '|', $active_shortcodes );
					$content     = preg_replace( "~(?:\[/?)(?!(?:$keep_active))[^/\]]+/?\]~s", '', $content );
				} else {
					// Strip all shortcodes.
					$content = preg_replace_callback( "\[[^\]]*\b" . $orphan['shortcode'] . "\b[^\]]*\]", 'strip_shortcode_tag', $content );
				}

				// Set "/" back to its place.
				$content = str_replace( $hack2, '/', $content );

				// And update the post with the filtered content.
				wp_update_post(
					array(
						'ID'           => $orphan['post_id'],
						'post_content' => $content,
					)
				);
			}
		}

		// Log if the delete was successful or not.
		$this->wpclpro_log( true, 'All orphan shortcodes were deleted.' );
	}

	/**
	 * Deletes orphan options.
	 *
	 * @access private
	 * @return void
	 */
	private function wpclpro_delete_orphan_options() {
		global $wpdb;
		$clean = false;

		// First get all orphan options.
		$orphans = parent::wpclpro_get_orphan_options();

		// If the list of orphan options is empty, just exit.
		if ( empty( $orphans ) ) {
			return;
		}

		foreach ( $orphans as $index => $orphan ) {

			$option_name = $orphan['option_name'];

			// Delete orphan options.
			// phpcs:disable -- ignore direct database access rule.
			$clean = $wpdb->query(
				$wpdb->prepare(
					"DELETE FROM $wpdb->options
					WHERE option_name = %s",
					$option_name
					)
				);
			// phpcs:enable

		}

		// Log if the delete was successful or not.
		$this->wpclpro_log( $clean, 'All orphan options were deleted.' );
	}

	/**
	 * Optimizes WordPress tables.
	 *
	 * @access public
	 * @return void
	 * @global wpdb $wpdb
	 */
	public function wpclpro_optimize_tables() {
		// Raise temporarily the time limits, because if database is big, optimizing takes longer.
		Wpclpro_Utilities::wpclpro_raise_time_limits();

		// Optimize tables.
		global $wpdb;
		$optimized = false;

		// phpcs:disable -- ignore direct database access rule.
		$wp_tables = $wpdb->get_results( 'SHOW TABLES' );
		// phpcs:enable

		if ( $wp_tables ) {
			foreach ( $wp_tables as $table ) {
				// phpcs:disable -- ignore direct database access rule.
				$optimized = $wpdb->query( 'OPTIMIZE TABLE $table' );
				// phpcs:enable
			}
		}

		// Restore the time limits to their original settings.
		Wpclpro_Utilities::wpclpro_restore_time_limits();

		// Log if optimizing was successful or not.
		$this->wpclpro_log( $optimized, 'The database was successfully optimized.' );
	}

	/**
	 * Resets cleaning counter.
	 *
	 * @access public
	 * @return void
	 * @global wpdb $wpdb
	 */
	public function wpclpro_reset_counter() {
		update_option( 'wpclpro_size_cleaned', 0, false );
	}

	/**
	 * Cleans from the database item given as parameters.
	 *
	 * @access public
	 * @param array $item The cleanable item to clean.
	 * @return void
	 */
	public function wpclpro_clean( $item ) {

		// Raise temporarily the time limits, because if database is big, the processing takes longer.
		Wpclpro_Utilities::wpclpro_raise_time_limits();

		// Continue proccess even if user aborts, for database backup consistency.
		ignore_user_abort( true );

		// Save the initial database size only if not saved already.
		$db_size_before = $this->wpclpro_get_db_size();

		// If nothing to clean, just exit.
		if ( empty( $item ) ) {
			return;
		}

		// Clean item depending which one is it.
		switch ( $item ) {
			case Wpclpro_Loader::TRASH_COMMENTS:
				$this->wpclpro_delete_trash_comments();
				break;
			case Wpclpro_Loader::SPAM_COMMENTS:
				$this->wpclpro_delete_spam_comments();
				break;
			case Wpclpro_Loader::WMODERATION:
				$this->wpclpro_delete_wmoderation();
				break;
			case Wpclpro_Loader::DUPLICATED_COMMENT_META:
				$this->wpclpro_delete_duplicated_comment_meta();
				break;
			case Wpclpro_Loader::PINGBACKS:
				$this->wpclpro_delete_pingbacks();
				break;
			case Wpclpro_Loader::TRACKBACKS:
				$this->wpclpro_delete_trackbacks();
				break;
			case Wpclpro_Loader::COMMENT_WEIRD_CHARS:
				$this->wpclpro_delete_comment_weird_chars();
				break;
			case Wpclpro_Loader::COMMENT_AGENT:
				$this->wpclpro_delete_comment_agent();
				break;
			case Wpclpro_Loader::ORPHAN_COMMENT_META:
				$this->wpclpro_delete_orphan_comment_meta();
				break;
			case Wpclpro_Loader::DRAFTS:
				$this->wpclpro_delete_drafts();
				break;
			case Wpclpro_Loader::AUTODRAFTS:
				$this->wpclpro_delete_auto_drafts();
				break;
			case Wpclpro_Loader::REVISIONS:
				$this->wpclpro_delete_revisions();
				break;
			case Wpclpro_Loader::TRASH_POSTS:
				$this->wpclpro_delete_trash_posts();
				break;
			case Wpclpro_Loader::DUPLICATED_POST_META:
				$this->wpclpro_delete_duplicated_post_meta();
				break;
			case Wpclpro_Loader::POST_WEIRD_CHARS:
				$this->wpclpro_delete_post_weird_chars();
				break;
			case Wpclpro_Loader::OEMBED_CACHES:
				$this->wpclpro_delete_oembed_caches();
				break;
			case Wpclpro_Loader::ORPHAN_POST_META:
				$this->wpclpro_delete_orphan_post_meta();
				break;
			case Wpclpro_Loader::OLD_SLUGS:
				$this->wpclpro_delete_old_slugs();
				break;
			case Wpclpro_Loader::OLD_DATES:
				$this->wpclpro_delete_old_dates();
				break;
			case Wpclpro_Loader::PLUGIN_OLD_LOGS:
				$this->wpclpro_delete_plugin_old_logs();
				break;
			case Wpclpro_Loader::UNUSED_TERMS:
				$this->wpclpro_delete_unused_terms();
				break;
			case Wpclpro_Loader::DUPLICATED_TERM_META:
				$this->wpclpro_delete_duplicated_term_meta();
				break;
			case Wpclpro_Loader::ORPHAN_TERM_RELATIONSHIPS:
				$this->wpclpro_delete_orphan_term_relationships();
				break;
			case Wpclpro_Loader::EXPIRED_TRANSIENTS:
				$this->wpclpro_delete_expired_transients();
				break;
			case Wpclpro_Loader::DUPLICATED_USER_META:
				$this->wpclpro_delete_duplicated_user_meta();
				break;
			case Wpclpro_Loader::SUBSCRIBERS_INVALID_EMAIL:
				$this->wpclpro_delete_subscribers_invalid_email();
				break;
			case Wpclpro_Loader::ORPHAN_USER_META:
				$this->wpclpro_delete_orphan_user_meta();
				break;
			case Wpclpro_Loader::WP_LINKS:
				$this->wpclpro_delete_wp_links();
				break;
			case Wpclpro_Loader::ORPHAN_TABLES:
				$this->wpclpro_delete_orphan_tables();
				break;
			case Wpclpro_Loader::ORPHAN_SHORTCODES:
				$this->wpclpro_delete_orphan_shortcodes();
				break;
			case Wpclpro_Loader::ORPHAN_OPTIONS:
				$this->wpclpro_delete_orphan_options();
				break;
			default:
				break;
		}

		// If any space cleaned up, save the database size at the end of cleaning.
		$db_size_now = $this->wpclpro_get_db_size();

		if ( $db_size_now < $db_size_before ) {
			$cleaned_now   = $db_size_before - $db_size_now;
			$total_cleaned = get_option( 'wpclpro_size_cleaned', 0 ) + $cleaned_now;
			update_option( 'wpclpro_size_cleaned', $total_cleaned, false );
		}

		// Restore the time limits to their original settings.
		Wpclpro_Utilities::wpclpro_restore_time_limits();
	}
}
