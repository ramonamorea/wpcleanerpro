<?php
/**
 * Holds utilities methods.
 *
 * @package    wp-cleaner-pro
 * @author     hevada <support@hevada.com>
 * @copyright  2017-2030 hevada <support@hevada.com>
 * @link       http://codecanyon.net/user/hevada
 * @version    6.3
 * @since      1.0
 */

/**
 * Class that contains utilities methods.
 */
class Wpclpro_Utilities {

	/**
	 * Stores class logger.
	 *
	 * @access
	 * @var Logger
	 */
	private $logger;

	/**
	 * Constructor.
	 *
	 * @acces public
	 * @return void
	 */
	public function __construct() {
		Logger::configure( WPCLPRO_PLUGIN_DIR . 'log4php/config.php' );
		$this->logger = Logger::getLogger( __CLASS__ );
	}

	/**
	 * Formats a file size from int to bytes, KB, MB, GB, TB.
	 *
	 * @access public
	 * @param int $size A size to be formatted from int to bytes, KB, MB, GB, TB.
	 * @return string Converted int size in string format.
	 */
	public static function wpclpro_format_filesize( $size ) {
		if ( $size / 1099511627776 > 1 ) {
			return number_format_i18n( $size / 1099511627776, 2 ) . ' ' . __( 'TB', 'wpclpro' );
		} elseif ( $size / 1073741824 > 1 ) {
			return number_format_i18n( $size / 1073741824, 2 ) . ' ' . __( 'GB', 'wpclpro' );
		} elseif ( $size / 1048576 > 1 ) {
			return number_format_i18n( $size / 1048576, 2 ) . ' ' . __( 'MB', 'wpclpro' );
		} elseif ( $size / 1024 > 1 ) {
			return number_format_i18n( $size / 1024, 2 ) . ' ' . __( 'KB', 'wpclpro' );
		} elseif ( $size > 1 ) {
			return number_format_i18n( $size, 0 ) . ' ' . __( 'bytes', 'wpclpro' );
		} else {
			return '0 ' . __( 'KB', 'wpclpro' );
		}
	}

	/**
	 * Formats a size given as string or as int.
	 *
	 * @access public
	 * @param string/int $size The size to be formatted to bytes, KB, MB, GB, TB.
	 * @return string A string representation of the size in this format: 14 Nov 2017 17:12:41 (UTC+2)
	 */
	public static function wpclpro_format_php_size( $size ) {
		if ( ! is_numeric( $size ) ) {
			if ( strpos( $size, 'M' ) !== false ) {
				$size = intval( $size ) * 1024 * 1024;
			} elseif ( strpos( $size, 'K' ) !== false ) {
				$size = intval( $size ) * 1024;
			} elseif ( strpos( $size, 'G' ) !== false ) {
				$size = intval( $size ) * 1024 * 1024 * 1024;
			}
		}
		return is_numeric( $size ) ? self::wpclpro_format_filesize( $size ) : $size;
	}

	/**
	 * Gets server's date and time.
	 *
	 * @access public
	 * @return string The date formatted in this format: "14 Nov 2017 17:12:41 (UTC+2)"
	 */
	public static function wpclpro_get_server_date_time() {
		$time = isset( $_SERVER['REQUEST_TIME'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_TIME'] ) ) : gmtdate( 'Y-m-d H:i:s' );
		return self::wpclpro_format_date( $time );
	}

	/**
	 * Get the available PHP memory limit.
	 *
	 * @access public
	 * @return string A string representation of the PHP memory limit in this format: "234MB" or "2GB".
	 */
	public static function wpclpro_get_php_memory_limit() {
		if ( ini_get( 'memory_limit' ) ) {
			$memory_limit = ini_get( 'memory_limit' );
		} else {
			$memory_limit = __( 'N/A', 'wpclpro' );
		}

		return self::wpclpro_format_php_size( $memory_limit );
	}

	/**
	 * Gets PHP maximum execution time.
	 *
	 * @access public
	 * @return string A string representation of the max execution time in this format: "30 seconds".
	 */
	public static function wpclpro_get_max_execution_time() {
		return ini_get( 'max_execution_time' ) . ' ' . __( 'seconds', 'wpclpro' );
	}

	/**
	 * Gets if the website is single-site or multi-site.
	 *
	 * @access public
	 * @return boolean True if the website is multi-site; false if it is single-site.
	 */
	public static function wpclpro_is_multisite() {
		$is_multisite = '';
		if ( function_exists( 'is_multisite' ) && is_multisite() ) {
			$is_multisite = __( 'yes', 'wpclpro' );
		} else {
			$is_multisite = __( 'no', 'wpclpro' );
		}

		return $is_multisite;
	}

	/**
	 * Gets maximum possible upload size.
	 *
	 * @access public
	 * @return string A human readable format of the maximimum upload size.
	 */
	public static function wpclpro_get_max_upload_size() {
		$max_upload_size = wp_max_upload_size();
		if ( ! $max_upload_size ) {
			$max_upload_size = 0;
		}

		return esc_html( size_format( $max_upload_size ) );
	}

	/**
	 * Gets the plugin version.
	 *
	 * @access public
	 * @return string The version of the plugin..
	 */
	public static function wpclpro_get_plugin_version() {
		$plugin_file    = WPCLPRO_PLUGIN_DIR . 'wpclpro-plugin.php';
		$plugin_data    = get_file_data( $plugin_file, array( 'Version' => 'Version' ), '' );
		$plugin_version = $plugin_data['Version'];

		return $plugin_version;
	}

	/**
	 * Gets the MySQL version.
	 *
	 * @access public
	 * @return string The version of MySQL.
	 */
	public static function wpclpro_get_mysql_version() {
		global $wpdb;
		// phpcs:disable -- ignore direct database access rule.
		return $wpdb->get_var( 'SELECT VERSION() AS version' );
		// phpcs:enable
	}

	/**
	 * Formats a date in this format: "14 Nov 2017 17:12:41 (UTC+2)".
	 *
	 * @access public
	 * @param DateTime $date The date to be formatted.
	 * @return string A string representation of the date parameter, in this format: "14 Nov 2017 17:12:41 (UTC+2)".
	 */
	public static function wpclpro_format_date( $date ) {
		// Calculate timezone.
		$gmt_offset = get_option( 'gmt_offset' );

		if ( $gmt_offset >= 0 ) {
			$gmt_offset = '+' . $gmt_offset;
		}
		$tz = sprintf( ' (UTC%s)', $gmt_offset );

		// And format the date according to timezone.
		$formatted_date = get_date_from_gmt( gmdate( 'Y-m-d G:i:s', $date ), 'd M Y H:i:s' );

		return $formatted_date . ' ' . $tz;
	}

	/**
	 * Formats a date given as String in this format: "14 Nov 2017 17:12:41 (UTC+2)".
	 *
	 * @access public
	 * @param String $string_date The date as String to be formatted.
	 * @return string A string representation of the date parameter, in this format: "14 Nov 2017 17:12:41 (UTC+2)".
	 */
	public static function wpclpro_format_string_date( $string_date ) {
		// Calculate timezone.
		$gmt_offset = get_option( 'gmt_offset' );

		if ( $gmt_offset >= 0 ) {
			$gmt_offset = '+' . $gmt_offset;
		}
		$tz = sprintf( ' (UTC%s)', $gmt_offset );

		// And format the date according to timezone.
		$formatted_date = get_date_from_gmt( $string_date, 'd M Y H:i:s' );

		return $formatted_date . ' ' . $tz;
	}

	/**
	 * Raise temporarily the time limits, because if database is big, the processing takes longer.
	 *
	 * @access public
	 * @return void Returns nothing.
	 */
	public static function wpclpro_raise_time_limits() {
		// @codingStandardsIgnoreStart -- ignore warnings, we need to try raising limits for the cleaning process.
		@ini_set( 'max_execution_time', '9000' );
		@ini_set( 'max_input_time', '9000' );
		@ini_set( 'memory_limit', '2048M' );
		@ini_set( 'mysql.connect_timeout', '9000' );
		@ini_set( 'default_socket_timeout', '9000' );
		// @codingStandardsIgnoreEnd
	}

	/**
	 * Restore the time limits to their original settings.
	 *
	 * @access public
	 * @return void Returns nothing.
	 */
	public static function wpclpro_restore_time_limits() {
		// @codingStandardsIgnoreStart -- ignore warnings, we need to try raising limits for the cleaning process.
		@ini_restore( 'max_execution_time' );
		@ini_restore( 'max_input_time' );
		@ini_restore( 'memory_limit' );
		@ini_restore( 'mysql.connect_timeout' );
		@ini_restore( 'default_socket_timeout' );
		// @codingStandardsIgnoreEnd
	}

	/**
	 * Gets a file extension from its filename.
	 *
	 * @access public
	 * @param String $filename The name of a file, for instance this_is_a_file.txt.
	 * @return String Returns the file extension from its filename.
	 */
	public static function wpclpro_get_file_extension( $filename ) {
		$n = strrpos( $filename, '.' );
		return ( false === $n ) ? '' : substr( $filename, $n + 1 );
	}

	/**
	 * Checks if a string starts with a substring.
	 *
	 * @access public
	 * @param String $text The string to check if it starts with the substring.
	 * @param String $subtext The substring to check if it is at the start of the string.
	 * @return String Returns true if the text starts with the subtext, false otherwise.
	 */
	public static function wpclpro_starts_with( $text, $subtext ) {
		if ( function_exists( 'mb_strpos' ) ) {
			return mb_strpos( $text, $subtext, 0, 'UTF-8' ) === 0;
		} elseif ( function_exists( 'iconv_strpos' ) ) {
			return iconv_strpos( $text, $subtext, 0, 'UTF-8' ) === 0;
		} else {
			return strpos( $text, $subtext ) === 0;
		}
	}
}
